
require("dotenv").config();

const express = require("express");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "20kb" }));

// Izinkan website lokal mengakses backend.
app.use((req, res, next) => {
    const origin = req.headers.origin;

    const allowedOrigins = [
        "http://127.0.0.1:5500",
        "http://localhost:5500"
    ];

    if (allowedOrigins.includes(origin)) {
        res.setHeader("Access-Control-Allow-Origin", origin);
    }

    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") {
        return res.sendStatus(204);
    }

    next();
});

const client = process.env.OPENAI_API_KEY
    ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
    : null;

const AZKADIA_INSTRUCTIONS = `
Kamu adalah Azkadia, asisten AI milik NutriCare AI.

IDENTITAS:
- Nama: Azkadia.
- Peran: Personal AI Assistant dengan keahlian khusus di bidang nutrisi.
- Kepribadian: ramah, hangat, cerdas, komunikatif, sabar, dan tidak menghakimi.
- Gunakan bahasa natural dan sesuaikan gaya bicara dengan pengguna.
- Jawab dalam bahasa yang digunakan pengguna.

KEAHLIAN UTAMA — NUTRISI:
- Kandungan gizi makanan.
- Protein, karbohidrat, lemak, vitamin, dan mineral.
- Gizi seimbang dan variasi makanan.
- Ide menu, resep, dan bekal.
- Membaca label informasi nilai gizi.
- Memahami bahan makanan dan cara pengolahannya.
- Kebiasaan makan sehat dan realistis.

ASISTEN UMUM:
- Jawab juga pertanyaan pendidikan, teknologi, bahasa, hiburan, kreativitas, dan obrolan sehari-hari.
- Jangan menolak pertanyaan hanya karena tidak berhubungan dengan nutrisi.
- Jangan memaksakan topik nutrisi ketika pengguna membicarakan hal lain.
- Jika pertanyaan kurang jelas, tanyakan satu hal yang paling diperlukan.

GAYA KOMUNIKASI:
- Berikan jawaban jelas, relevan, dan mudah dipahami.
- Sesuaikan panjang jawaban dengan kebutuhan.
- Jangan mengarang fakta, angka, kutipan, atau sumber.
- Jika tidak yakin, sampaikan ketidakpastian dengan jujur.
- Jangan berpura-pura memiliki pengalaman pribadi.

KEAMANAN:
- Jangan mendiagnosis penyakit atau menggantikan tenaga medis.
- Jangan menyarankan diet ekstrem atau pembatasan makan berlebihan.
- Jangan membuat pengguna merasa bersalah atas makanan yang dikonsumsi.
- Untuk kondisi medis khusus, arahkan ke tenaga kesehatan kompeten.
- Berikan informasi yang aman untuk topik berisiko.

TUJUAN:
Jadilah asisten yang berguna untuk berbagai kebutuhan sehari-hari, dengan nutrisi sebagai keahlian utama NutriCare AI.
`;

app.get("/api/health", (req, res) => {
    res.json({
        status: "ok",
        aiConfigured: Boolean(client)
    });
});

app.post("/api/chat", async (req, res) => {
    try {
        if (!client) {
            return res.status(503).json({
                error: "API key belum dikonfigurasi di file .env."
            });
        }

        const messages = req.body?.messages;

        if (!Array.isArray(messages) || messages.length === 0) {
            return res.status(400).json({
                error: "Riwayat percakapan tidak ditemukan."
            });
        }

        if (messages.length > 12) {
            return res.status(400).json({
                error: "Riwayat percakapan terlalu panjang."
            });
        }

        const validMessages = messages.every((item) =>
            item &&
            ["user", "assistant"].includes(item.role) &&
            typeof item.content === "string" &&
            item.content.trim().length > 0 &&
            item.content.length <= 4000
        );

        if (!validMessages) {
            return res.status(400).json({
                error: "Format pesan tidak valid."
            });
        }

        if (messages[messages.length - 1].role !== "user") {
            return res.status(400).json({
                error: "Pesan terakhir harus berasal dari pengguna."
            });
        }

        const response = await client.responses.create({
            model: "gpt-4.1-mini",
            instructions: AZKADIA_INSTRUCTIONS,
            input: messages.map((item) => ({
                role: item.role,
                content: item.content.trim()
            }))
        });

        const answer = response.output_text?.trim();

        if (!answer) {
            return res.status(502).json({
                error: "AI belum menghasilkan jawaban. Silakan coba lagi."
            });
        }

        res.json({ answer });

    } catch (error) {
        console.error("AI Chat error:", error.message);

        if (error.status === 429) {
            return res.status(429).json({
                error: "Batas penggunaan API tercapai. Periksa kuota dan billing API."
            });
        }

        res.status(500).json({
            error: "Maaf, AI sedang mengalami kendala. Silakan coba lagi."
        });
    }
});

app.listen(PORT, () => {
    console.log(`NutriCare AI backend berjalan di http://localhost:${PORT}`);
});
