
/* ==========================================
   NUTRICARE AI — THE SECRET GARDEN
   Centered mascot • Peekaboo • Greeting
========================================== */

(function () {
    const INTRO_KEY = "nutricare_intro_seen";
    const INTRO_DURATION = 12000;
    const MASCOT_SRC = "assets/images/nutricare-buddy-transparent.png";

    function initNutriCareIntro() {
        if (
            window.location.pathname.includes("/pages/") ||
            document.querySelector(".nc-intro")
        ) {
            return;
        }

        try {
            if (sessionStorage.getItem(INTRO_KEY)) return;
        } catch (_) {
            // Intro tetap dapat berjalan jika sessionStorage tidak tersedia.
        }

        const reducedMotion = window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        ).matches;

        const intro = document.createElement("section");
        intro.className = "nc-intro";
        intro.setAttribute("role", "dialog");
        intro.setAttribute("aria-label", "Selamat datang di taman NutriCare AI");

        intro.innerHTML = `
            <div class="nc-intro__glow" aria-hidden="true"></div>
            <div class="nc-intro__particles" aria-hidden="true"></div>

            <button class="nc-intro__skip" type="button">
                Lewati intro <span aria-hidden="true">→</span>
            </button>

            <main class="nc-intro__scene">
                <p class="nc-intro__eyebrow">A LITTLE WORLD OF CARE</p>

                <div class="nc-intro__garden" aria-label="Taman NutriCare">
                    <div class="nc-intro__halo nc-intro__halo--back"></div>
                    <div class="nc-intro__halo nc-intro__halo--middle"></div>
                    <div class="nc-intro__halo nc-intro__halo--front"></div>

                    <div class="nc-intro__arch"></div>

                    <div class="nc-intro__bush nc-intro__bush--left"></div>
                    <div class="nc-intro__bush nc-intro__bush--right"></div>
                    <div class="nc-intro__ground"></div>

                    <span class="nc-intro__leaf nc-intro__leaf--one"></span>
                    <span class="nc-intro__leaf nc-intro__leaf--two"></span>
                    <span class="nc-intro__leaf nc-intro__leaf--three"></span>
                    <span class="nc-intro__leaf nc-intro__leaf--four"></span>

                    <span class="nc-intro__sparkle nc-intro__sparkle--one">✦</span>
                    <span class="nc-intro__sparkle nc-intro__sparkle--two">✧</span>
                    <span class="nc-intro__sparkle nc-intro__sparkle--three">✦</span>

                    <div class="nc-intro__buddy-wrap">
                        <img
                            class="nc-intro__mascot"
                            src="${MASCOT_SRC}"
                            alt="NutriCare Buddy"
                        >
                    </div>

                    <p class="nc-intro__hello" aria-hidden="true">
                        Hai, kamu datang! <span>✿</span>
                    </p>
                </div>

                <div class="nc-intro__copy">
                    <p class="nc-intro__tagline">
                        YOUR LITTLE SPACE TO GROW
                    </p>

                    <h1 class="nc-intro__wordmark">
                        NutriCare <span>AI</span>
                    </h1>

                    <p class="nc-intro__message">
                        Kebiasaan kecil, perhatian penuh,
                        tumbuh dengan caramu sendiri.
                    </p>

                    <button class="nc-intro__enter" type="button">
                        Masuk ke taman <span aria-hidden="true">→</span>
                    </button>
                </div>
            </main>
        `;

        document.body.appendChild(intro);

        const mascot = intro.querySelector(".nc-intro__mascot");
        const particles = intro.querySelector(".nc-intro__particles");
        const skipButton = intro.querySelector(".nc-intro__skip");
        const enterButton = intro.querySelector(".nc-intro__enter");

        // Partikel kecil dengan posisi acak.
        for (let i = 0; i < 22; i++) {
            const particle = document.createElement("span");
            particle.className = "nc-intro__particle";

            particle.style.setProperty("--x", `${Math.random() * 100}%`);
            particle.style.setProperty("--size", `${3 + Math.random() * 5}px`);
            particle.style.setProperty("--duration", `${5 + Math.random() * 5}s`);
            particle.style.setProperty("--delay", `${Math.random() * -8}s`);
            particle.style.setProperty("--drift", `${-25 + Math.random() * 50}px`);

            particle.style.setProperty(
                "--color",
                ["#f0c3a7", "#a7d7a5", "#d9eacb"][i % 3]
            );

            particles.appendChild(particle);
        }

        mascot.addEventListener("error", function () {
            mascot.classList.add("is-missing");
            console.error("Maskot tidak ditemukan:", MASCOT_SRC);
        });

        let finished = false;
        let timer = null;
        let leaveTimer = null;
        let removeTimer = null;

        function finishIntro(enterDashboard) {
            if (finished) return;
            finished = true;

            window.clearTimeout(timer);

            try {
                sessionStorage.setItem(INTRO_KEY, "yes");
            } catch (_) {}

            document.removeEventListener("keydown", handleEscape);

            if (enterDashboard && !reducedMotion) {
                intro.classList.add("is-entering");

                leaveTimer = window.setTimeout(() => {
                    intro.classList.add("is-leaving");
                }, 650);

                removeTimer = window.setTimeout(() => {
                    intro.remove();
                }, 1450);
            } else {
                intro.classList.add("is-leaving");

                removeTimer = window.setTimeout(() => {
                    intro.remove();
                }, reducedMotion ? 20 : 700);
            }
        }

        function handleEscape(event) {
            if (event.key === "Escape") finishIntro(false);
        }

        skipButton.addEventListener("click", () => finishIntro(false));
        enterButton.addEventListener("click", () => finishIntro(true));
        document.addEventListener("keydown", handleEscape);

        if (reducedMotion) {
            intro.classList.add("is-reduced-motion");
        }

        timer = window.setTimeout(() => {
            finishIntro(false);
        }, INTRO_DURATION);

        // Mencegah variabel timer animasi tidak terpakai.
        void leaveTimer;
        void removeTimer;
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initNutriCareIntro, {
            once: true
        });
    } else {
        initNutriCareIntro();
    }
})();
