(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  const waterKey = "nutricare_dashboard_refresh_water";
  const habitKey = "nutricare_dashboard_refresh_habits";
  let toastTimer;

  function getSessionName() {
    try {
      const session = JSON.parse(sessionStorage.getItem("nutricare_demo_session") || "null");
      // Sesuaikan jika struktur objek sesi kamu menggunakan properti nama yang berbeda.
      return session?.name || session?.user?.name || session?.fullName || "Teman Sehat";
    } catch {
      return "Teman Sehat";
    }
  }

  function showToast(message) {
    const toast = $("#toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2400);
  }

  function loadWater() {
    const stored = Number(localStorage.getItem(waterKey));
    return Number.isFinite(stored) && stored >= 0 ? Math.min(stored, 8) : 4;
  }

  function updateWater(value) {
    const amount = Math.max(0, Math.min(8, value));
    localStorage.setItem(waterKey, String(amount));
    $("#water-value").textContent = amount;
    $("#water-progress").style.width = `${amount / 8 * 100}%`;
    updateDailyProgress();
  }

  function loadHabits() {
    try {
      const stored = JSON.parse(localStorage.getItem(habitKey) || "{}");
      $$("[data-habit]").forEach((checkbox) => {
        checkbox.checked = Boolean(stored[checkbox.dataset.habit]);
      });
    } catch {
      // Jika data rusak, checkbox tetap dapat digunakan dari keadaan awal.
    }
    updateHabitProgress();
  }

  function updateHabitProgress() {
    const checks = $$("[data-habit]");
    const count = checks.filter((item) => item.checked).length;
    const stored = {};
    checks.forEach((item) => stored[item.dataset.habit] = item.checked);
    localStorage.setItem(habitKey, JSON.stringify(stored));
    $("#habit-count").textContent = count;
    $("#habit-progress").style.width = `${count / checks.length * 100}%`;
    updateDailyProgress();
  }

  function updateDailyProgress() {
    const water = Number($("#water-value")?.textContent || 0);
    const habitsDone = $$("[data-habit]").filter((item) => item.checked).length;
    // Demo progres menggabungkan target air (tercapai saat 8 gelas) dan empat kebiasaan.
    const total = 5;
    const completed = habitsDone + (water >= 8 ? 1 : 0);
    const percent = Math.round(completed / total * 100);
    $("#daily-percent").textContent = `${percent}%`;
    $("#daily-ring").style.background = `conic-gradient(#6EB78A 0 ${percent}%, #E8F0DF ${percent}% 100%)`;
    $("#done-label").textContent = `${completed} target`;
    $("#left-label").textContent = `${total - completed} target`;
  }

  function init() {
    const name = getSessionName();
    $("#user-name").textContent = name;
    $("#welcome-name").textContent = name;
    const now = new Date();
    $("#today-label").textContent = new Intl.DateTimeFormat("id-ID", {
      weekday: "long", day: "numeric", month: "long"
    }).format(now);
    $("#footer-year").textContent = now.getFullYear();

    updateWater(loadWater());
    loadHabits();

    $$('[data-action="add-water"]').forEach((button) => {
      button.addEventListener("click", () => {
        const current = Number($("#water-value").textContent);
        if (current >= 8) {
          showToast("Target demo 8 gelas sudah tercapai. Tetap minum sesuai kebutuhanmu, ya!");
          return;
        }
        updateWater(current + 1);
        showToast("Tercatat! Satu gelas ditambahkan 💧");
      });
    });

    $$("[data-habit]").forEach((checkbox) => {
      checkbox.addEventListener("change", updateHabitProgress);
    });

    $$(".nav-link[data-nav]").forEach((link) => {
      link.addEventListener("click", () => {
        $$(".nav-link[data-nav]").forEach((item) => item.classList.remove("is-active"));
        link.classList.add("is-active");
        $("#sidebar").classList.remove("is-open");
      });
    });

    $("#mobile-menu")?.addEventListener("click", () => $("#sidebar").classList.toggle("is-open"));
    $("#profile-button")?.addEventListener("click", () => showToast("Area profil: hubungkan ke halaman profil yang sudah ada."));
    $("#date-button")?.addEventListener("click", () => showToast($("#today-label").textContent));
    $$('a[href^="#"]').forEach((link) => {
      link.addEventListener("click", (event) => {
        const id = link.getAttribute("href").slice(1);
        // Template ini memakai anchor untuk navigasi visual; tautkan ke halaman asli jika sudah tersedia.
        const target = document.getElementById(id);
        if (!target) {
          event.preventDefault();
          showToast(`Hubungkan "${link.textContent.trim()}" ke halaman fitur yang sudah ada.`);
        }
      });
    });
  }

  document.addEventListener("DOMContentLoaded", init);
})();
