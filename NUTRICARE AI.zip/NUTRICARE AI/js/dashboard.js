// ==========================================
// NutriCare AI - Dashboard System
// ==========================================


// ==========================================
// LOAD DASHBOARD
// ==========================================

function loadDashboard() {

    const profile = getProfile();

    // Nama
    updateDashboardName(profile);

    // Foto
    updateDashboardPhoto(profile);

    // Data profil
    updateProfileSummary(profile);

    // Health summary
    updateHealthSummary(profile);

}


// ==========================================
// UPDATE GREETING
// ==========================================

function updateDashboardName(profile) {

    const nameElement =
        document.getElementById("dashboardName");

    if (!nameElement) {
        return;
    }

    if (profile.name) {

        nameElement.textContent =
            profile.name;

    } else {

        nameElement.textContent =
            "Teman";

    }

}


// ==========================================
// UPDATE PROFILE PHOTO
// ==========================================

function updateDashboardPhoto(profile) {

    const photo =
        document.getElementById(
            "dashboardProfilePhoto"
        );

    const placeholder =
        document.getElementById(
            "dashboardPhotoPlaceholder"
        );


    if (!photo || !placeholder) {
        return;
    }


    if (profile.profilePhoto) {

        photo.src =
            profile.profilePhoto;

        photo.style.display =
            "block";

        placeholder.style.display =
            "none";

    } else {

        photo.src = "";

        photo.style.display =
            "none";

        placeholder.style.display =
            "flex";

    }

}


// ==========================================
// UPDATE PROFILE SUMMARY
// ==========================================

function updateProfileSummary(profile) {

    const age =
        document.getElementById("summaryAge");

    const gender =
        document.getElementById("summaryGender");

    const weight =
        document.getElementById("summaryWeight");

    const height =
        document.getElementById("summaryHeight");


    if (age) {

        age.textContent =
            profile.age
                ? `${profile.age} tahun`
                : "-";

    }


    if (gender) {

        if (profile.gender === "female") {

            gender.textContent =
                "Perempuan";

        } else if (profile.gender === "male") {

            gender.textContent =
                "Laki-laki";

        } else {

            gender.textContent =
                "-";

        }

    }


    if (weight) {

        weight.textContent =
            profile.weight
                ? `${profile.weight} kg`
                : "-";

    }


    if (height) {

        height.textContent =
            profile.height
                ? `${profile.height} cm`
                : "-";

    }

}


// ==========================================
// HEALTH SUMMARY
// ==========================================

function updateHealthSummary(profile) {

    const bmiElement =
        document.getElementById(
            "dashboardBMI"
        );

    const energyElement =
        document.getElementById(
            "dashboardEnergy"
        );

    const waterElement =
        document.getElementById(
            "dashboardWater"
        );


    // BMI

    if (
        bmiElement &&
        profile.weight &&
        profile.height
    ) {

        const heightMeter =
            Number(profile.height) / 100;

        const bmi =
            Number(profile.weight) /
            (
                heightMeter *
                heightMeter
            );

        bmiElement.textContent =
            bmi.toFixed(1);

    } else if (bmiElement) {

        bmiElement.textContent =
            "-";

    }


    // Estimasi energi

    if (
        energyElement &&
        profile.weight &&
        profile.height &&
        profile.age &&
        profile.gender
    ) {

        const bmr =
            calculateBMR(
                Number(profile.weight),
                Number(profile.height),
                Number(profile.age),
                profile.gender
            );

        const energy =
            calculateDailyEnergy(
                bmr,
                profile.activityLevel
            );

        energyElement.textContent =
            energy
                ? `${energy} kcal`
                : "-";

    } else if (energyElement) {

        energyElement.textContent =
            "-";

    }


    // Estimasi cairan

    if (
        waterElement &&
        profile.weight
    ) {

        const water =
            calculateWaterNeed(
                Number(profile.weight)
            );

        waterElement.textContent =
            water
                ? `${water} ml`
                : "-";

    } else if (waterElement) {

        waterElement.textContent =
            "-";

    }

}


// ==========================================
// OPEN PROFILE
// ==========================================

function openProfile() {

    window.location.href =
        "pages/profile.html";


}



// ==========================================
// INITIALIZE
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadDashboard();

    }
);

function openAnalysis() {
    window.location.href = "pages/analysis.html";
}

function openNutrition() {
    window.location.href = "pages/nutrition.html";
}

function openMealScanner() {
    window.location.href = "pages/meal-scanner.html";
}

function openAIChat() {
    window.location.href = "pages/ai-chat.html";
}

function openMealPlanner() {
    window.location.href = "pages/meal-planner.html";
}

function openWaterTracker() {
    window.location.href = "pages/water-tracker.html";
}

function openSleepTracker() {
    window.location.href = "pages/sleep-tracker.html";
}

function openActivityTracker() {
    window.location.href = "pages/activity-tracker.html";
}

function openHabitTracker() {
    window.location.href = "pages/habit-tracker.html";
}

function openNutrientTracker() {
    window.location.href = "pages/nutrient-tracker.html";
}

function openLabelScanner() {
    window.location.href = "pages/label-scanner.html";
}

function openPantry() {
    window.location.href = "pages/pantry.html";
}

function openShoppingList() {
    window.location.href = "pages/shopping-list.html";
}

function openInsights() {
    window.location.href = "pages/insights.html";
}

function openClaimChecker() {
    window.location.href = "pages/claim-checker.html";
}

function openMythFact() {
    window.location.href = "pages/myth-fact.html";
}

function openDailyCheckin() {
    window.location.href = "pages/daily-checkin.html";
}

function openEducation() {
    window.location.href = "pages/education.html";
}

function openAchievement() {
    window.location.href = "pages/achievement.html";
}

function openSmartReminder() {
    window.location.href = "pages/reminders.html";
}


const logoutButton = document.getElementById("logout-button");

if (logoutButton) {
  logoutButton.addEventListener("click", () => {
    sessionStorage.removeItem("nutricare_demo_session");
    window.location.replace("login.html");
  });
}
