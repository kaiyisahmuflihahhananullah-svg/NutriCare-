// ==========================================
// NutriCare AI - Health Calculations
// ==========================================


// ==========================================
// BMI
// ==========================================

function calculateBMI(weight, height) {

    if (!weight || !height) {
        return null;
    }

    const heightInMeter = height / 100;

    const bmi =
        weight /
        (heightInMeter * heightInMeter);

    return Number(bmi.toFixed(1));

}


// ==========================================
// BMI Status
// ==========================================

function getBMIStatus(bmi) {

    if (bmi === null) {
        return "Data belum lengkap";
    }

    if (bmi < 18.5) {
        return "Di bawah rentang rujukan";
    }

    if (bmi < 25) {
        return "Dalam rentang rujukan";
    }

    if (bmi < 30) {
        return "Di atas rentang rujukan";
    }

    return "Jauh di atas rentang rujukan";

}


// ==========================================
// BMR
// ==========================================

function calculateBMR(
    weight,
    height,
    age,
    gender
) {

    if (
        !weight ||
        !height ||
        !age ||
        !gender
    ) {
        return null;
    }

    let bmr;

    if (gender === "male") {

        bmr =
            (10 * weight) +
            (6.25 * height) -
            (5 * age) +
            5;

    } else {

        bmr =
            (10 * weight) +
            (6.25 * height) -
            (5 * age) -
            161;

    }

    return Math.round(bmr);

}


// ==========================================
// Activity Multiplier
// ==========================================

function getActivityMultiplier(
    activityLevel
) {

    const multipliers = {

        sedentary: 1.2,

        light: 1.375,

        moderate: 1.55,

        active: 1.725,

        veryActive: 1.9

    };

    return (
        multipliers[activityLevel] ||
        multipliers.sedentary
    );

}


// ==========================================
// Estimated Daily Energy
// ==========================================

function calculateDailyEnergy(
    bmr,
    activityLevel
) {

    if (!bmr) {
        return null;
    }

    const multiplier =
        getActivityMultiplier(
            activityLevel
        );

    return Math.round(
        bmr * multiplier
    );

}


// ==========================================
// Estimated Fluid Need
// ==========================================

function calculateWaterNeed(weight) {

    if (!weight) {
        return null;
    }

    // Prototype estimate.
    // Bukan pengganti rekomendasi tenaga kesehatan.

    const waterML =
        weight * 30;

    return Math.round(
        waterML
    );

}