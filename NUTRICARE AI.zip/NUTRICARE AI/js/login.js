
"use strict";

const USERS_KEY = "nutricare_demo_users";
const SESSION_KEY = "nutricare_demo_session";

// Ganti jika halaman dashboard utamamu bukan index.html.
const DASHBOARD_URL = "index.html";

const authForm = document.getElementById("auth-form");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const confirmInput = document.getElementById("confirm-password");

const nameGroup = document.getElementById("name-group");
const confirmGroup = document.getElementById("confirm-group");

const title = document.getElementById("form-title");
const eyebrow = document.getElementById("form-eyebrow");
const description = document.getElementById("form-description");

const submitButton = document.getElementById("submit-button");
const switchText = document.getElementById("switch-text");
const switchButton = document.getElementById("switch-button");
const notice = document.getElementById("notice");

let currentMode = "login";

function getUsers() {
  try {
    const saved = localStorage.getItem(USERS_KEY);
    const users = saved ? JSON.parse(saved) : [];

    return Array.isArray(users) ? users : [];
  } catch {
    showNotice(
      "Data demo tidak bisa dibaca. Periksa pengaturan browser.",
      "error"
    );

    return [];
  }
}

function saveUsers(users) {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    return true;
  } catch {
    showNotice(
      "Browser tidak bisa menyimpan akun demo.",
      "error"
    );

    return false;
  }
}

function showNotice(message, type = "error") {
  notice.textContent = message;
  notice.className = `notice ${type}`;
  notice.hidden = false;
}

function clearNotice() {
  notice.textContent = "";
  notice.hidden = true;
  notice.className = "notice";
}

function setMode(mode) {
  currentMode = mode;
  clearNotice();
  authForm.reset();

  const isRegister = mode === "register";

  nameGroup.hidden = !isRegister;
  confirmGroup.hidden = !isRegister;

  nameInput.required = isRegister;
  confirmInput.required = isRegister;

  passwordInput.autocomplete = isRegister
    ? "new-password"
    : "current-password";

  if (isRegister) {
    eyebrow.textContent = "LET'S GET STARTED";
    title.textContent = "Buat akun sehatmu!";
    description.textContent =
      "Mulai perjalanan sehatmu bersama NutriCare AI.";
    submitButton.innerHTML =
      'Buat Akun <span aria-hidden="true">→</span>';
    switchText.textContent = "Sudah punya akun?";
    switchButton.textContent = "Login";
  } else {
    eyebrow.textContent = "WELCOME BACK";
    title.textContent = "Senang bertemu lagi!";
    description.textContent =
      "Yuk, lanjutkan perjalanan sehatmu bersama NutriCare.";
    submitButton.innerHTML =
      'Login <span aria-hidden="true">→</span>';
    switchText.textContent = "Belum punya akun?";
    switchButton.textContent = "Buat akun";
  }
}

switchButton.addEventListener("click", () => {
  setMode(currentMode === "login" ? "register" : "login");
});

authForm.addEventListener("submit", (event) => {
  event.preventDefault();
  clearNotice();

  const email = emailInput.value.trim().toLowerCase();
  const password = passwordInput.value;
  const users = getUsers();

  if (!email || !password) {
    showNotice("Isi email dan password terlebih dahulu.");
    return;
  }

  if (password.length < 8) {
    showNotice("Password harus terdiri dari minimal 8 karakter.");
    return;
  }

  if (currentMode === "register") {
    const name = nameInput.value.trim();
    const confirmPassword = confirmInput.value;

    if (!name) {
      showNotice("Nama lengkap belum diisi.");
      return;
    }

    if (password !== confirmPassword) {
      showNotice("Konfirmasi password belum cocok.");
      return;
    }

    if (users.some((user) => user.email === email)) {
      showNotice(
        "Email ini sudah terdaftar. Silakan login."
      );
      return;
    }

    const newUser = {
      id: `demo-${Date.now()}`,
      name,
      email,
      password
    };

    users.push(newUser);

    if (!saveUsers(users)) return;

    showNotice(
      "Akun demo berhasil dibuat! Kamu bisa login sekarang.",
      "success"
    );

    setMode("login");
    emailInput.value = email;

    showNotice(
      "Akun berhasil dibuat. Silakan login dengan akunmu.",
      "success"
    );

    return;
  }

  const user = users.find(
    (item) =>
      item.email === email &&
      item.password === password
  );

  if (!user) {
    showNotice(
      "Email atau password tidak cocok. Coba lagi."
    );
    return;
  }

  try {
    sessionStorage.setItem(
      SESSION_KEY,
      JSON.stringify({
        id: user.id,
        name: user.name,
        email: user.email,
        loggedIn: true
      })
    );

    window.location.href = DASHBOARD_URL;
  } catch {
    showNotice(
      "Sesi login tidak dapat disimpan di browser."
    );
  }
});

// Jika sudah login pada tab ini, langsung menuju dashboard.
try {
  const session = JSON.parse(
    sessionStorage.getItem(SESSION_KEY) || "null"
  );

  if (session?.loggedIn) {
    window.location.replace(DASHBOARD_URL);
  }
} catch {
  sessionStorage.removeItem(SESSION_KEY);
}

setMode("login");
