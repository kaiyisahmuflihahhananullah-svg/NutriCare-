
/* ==========================================
   NutriCare AI - Nutrition Dashboard
   ========================================== */

const DASHBOARD_NUTRIENT_KEY = "nutricare_nutrient_tracker";

const dashboardFoodDatabase = {
    rice: {
        name: "Nasi putih",
        portion: "150 g",
        icon: "N"
    },
    egg: {
        name: "Telur",
        portion: "1 butir",
        icon: "T"
    },
    chicken: {
        name: "Ayam",
        portion: "100 g",
        icon: "A"
    },
    tempe: {
        name: "Tempe",
        portion: "50 g",
        icon: "T"
    },
    vegetables: {
        name: "Sayuran campur",
        portion: "100 g",
        icon: "S"
    },
    banana: {
        name: "Pisang",
        portion: "1 buah",
        icon: "P"
    },
    milk: {
        name: "Susu",
        portion: "200 ml",
        icon: "S"
    },
    yogurt: {
        name: "Yogurt",
        portion: "100 g",
        icon: "Y"
    }
};

const dashboardNutrients = {
    rice: { carbs: 42, protein: 4, fiber: 1 },
    egg: { carbs: 0.6, protein: 6, fiber: 0 },
    chicken: { carbs: 0, protein: 27, fiber: 0 },
    tempe: { carbs: 5, protein: 10, fiber: 2 },
    vegetables: { carbs: 8, protein: 2, fiber: 3 },
    banana: { carbs: 23, protein: 1, fiber: 3 },
    milk: { carbs: 10, protein: 6, fiber: 0 },
    yogurt: { carbs: 5, protein: 4, fiber: 0 }
};


// ==========================================
// HELPER
// ==========================================

function dashboardElement(id) {
    return document.getElementById(id);
}

function dashboardFormatNumber(value) {
    const number = Number(value) || 0;

    return Number.isInteger(number)
        ? String(number)
        : number.toFixed(1).replace(/\.0$/, "");
}

function getDashboardToday() {
    const now = new Date();

    return [
        now.getFullYear(),
        String(now.getMonth() + 1).padStart(2, "0"),
        String(now.getDate()).padStart(2, "0")
    ].join("-");
}


// ==========================================
// DATE
// ==========================================

function renderDashboardDate() {
    const dateElement = dashboardElement("todayDate");
    const yearElement = dashboardElement("currentYear");

    const now = new Date();

    if (dateElement) {
        dateElement.textContent = now.toLocaleDateString("id-ID", {
            weekday: "long",
            day: "numeric",
            month: "long",
            year: "numeric"
        });
    }

    if (yearElement) {
        yearElement.textContent = now.getFullYear();
    }
}


// ==========================================
// PROFILE
// ==========================================

function renderDashboardProfile() {
    let profile = {};

    if (typeof getProfile === "function") {
        profile = getProfile() || {};
    }

    const name = profile.name || profile.fullName || "NutriCare User";

    const nameElement = dashboardElement("profileName");
    const avatarElement = dashboardElement("profileAvatar");
    const greetingElement = dashboardElement("greetingTitle");

    if (nameElement) {
        nameElement.textContent = name;
    }

    if (avatarElement) {
        avatarElement.textContent = name.charAt(0).toUpperCase();
    }

    if (greetingElement) {
        const hour = new Date().getHours();

        let greeting = "Good evening";

        if (hour >= 4 && hour < 11) {
            greeting = "Good morning";
        } else if (hour >= 11 && hour < 15) {
            greeting = "Good afternoon";
        } else if (hour >= 15 && hour < 18) {
            greeting = "Good evening";
        } else {
            greeting = "Good night";
        }

        greetingElement.textContent = greeting + ", " + name + "!";
    }
}


// ==========================================
// NUTRITION DATA
// ==========================================

function getDashboardNutritionData() {
    try {
        const saved = localStorage.getItem(DASHBOARD_NUTRIENT_KEY);
        const today = getDashboardToday();

        if (!saved) {
            return { date: today, foods: [] };
        }

        const data = JSON.parse(saved);

        if (
            !data ||
            data.date !== today ||
            !Array.isArray(data.foods)
        ) {
            return { date: today, foods: [] };
        }

        return data;

    } catch (error) {
        console.error("Gagal membaca data nutrisi:", error);

        return {
            date: getDashboardToday(),
            foods: []
        };
    }
}


// ==========================================
// CALCULATE NUTRITION
// ==========================================

function calculateDashboardNutrition(data) {
    const totals = {
        foodCount: 0,
        carbs: 0,
        protein: 0,
        fiber: 0
    };

    data.foods.forEach(function(item) {
        const nutrients = dashboardNutrients[item.foodId];

        if (!nutrients) return;

        const servings = Math.max(0, Number(item.servings) || 0);

        totals.foodCount += servings;
        totals.carbs += nutrients.carbs * servings;
        totals.protein += nutrients.protein * servings;
        totals.fiber += nutrients.fiber * servings;
    });

    return totals;
}


// ==========================================
// NUTRITION SUMMARY
// ==========================================

function renderDashboardNutritionSummary() {
    const data = getDashboardNutritionData();
    const totals = calculateDashboardNutrition(data);

    const countElement = dashboardElement("foodCount");
    const messageElement = dashboardElement("foodCountMessage");

    if (countElement) {
        countElement.textContent = dashboardFormatNumber(totals.foodCount);
    }

    if (messageElement) {
        messageElement.textContent = totals.foodCount === 0
            ? "Belum ada makanan yang dicatat hari ini."
            : "Jumlah porsi makanan yang kamu catat hari ini.";
    }

    const fields = [
        { key: "carbs", id: "totalCarbs", bar: "carbsBar" },
        { key: "protein", id: "totalProtein", bar: "proteinBar" },
        { key: "fiber", id: "totalFiber", bar: "fiberBar" }
    ];

    fields.forEach(function(field) {
        const value = totals[field.key];

        const valueElement = dashboardElement(field.id);
        const barElement = dashboardElement(field.bar);

        if (valueElement) {
            valueElement.textContent = dashboardFormatNumber(value);
        }

        if (barElement) {
            barElement.style.width = Math.min(value, 100) + "%";
        }
    });
}


// ==========================================
// TODAY'S FOOD LIST
// ==========================================

function renderDashboardFoodList() {
    const container = dashboardElement("todayFoodList");

    if (!container) return;

    const data = getDashboardNutritionData();

    container.replaceChildren();

    if (data.foods.length === 0) {
        const empty = document.createElement("div");
        empty.className = "empty-state";

        const icon = document.createElement("span");
        icon.className = "empty-illustration";
        icon.textContent = "+";

        const copy = document.createElement("div");

        const title = document.createElement("strong");
        title.textContent = "Garden masih kosong!";

        const description = document.createElement("p");
        description.textContent =
            "Catat makananmu untuk melihat ringkasannya di sini.";

        const link = document.createElement("a");
        link.href = "nutrient-tracker.html";
        link.textContent = "Tambah makanan →";

        copy.append(title, description, link);
        empty.append(icon, copy);

        container.appendChild(empty);

        return;
    }

    data.foods.forEach(function(item) {
        const food = dashboardFoodDatabase[item.foodId];

        if (!food) return;

        const row = document.createElement("div");
        row.className = "food-row";

        const icon = document.createElement("span");
        icon.className = "food-emoji";
        icon.textContent = food.icon;

        const info = document.createElement("div");
        info.className = "food-info";

        const name = document.createElement("strong");
        name.textContent = food.name;

        const portion = document.createElement("small");
        portion.textContent = food.portion;

        info.append(name, portion);

        const serving = document.createElement("span");
        serving.className = "food-serving";
        serving.textContent =
            dashboardFormatNumber(item.servings) + " porsi";

        row.append(icon, info, serving);
        container.appendChild(row);
    });
}


// ==========================================
// MEAL PLANNER PREVIEW
// ==========================================

function renderDashboardMealPlan() {
    const container = dashboardElement("mealPlanPreview");

    if (!container) return;

    container.replaceChildren();

    let plan = null;

    if (typeof getSavedMealPlan === "function") {
        plan = getSavedMealPlan();
    } else if (
        typeof NutriStorage !== "undefined" &&
        typeof STORAGE_KEYS !== "undefined"
    ) {
        plan = NutriStorage.get(STORAGE_KEYS.MEALS, null);
    }

    if (!plan || typeof plan !== "object") {
        renderDashboardEmptyMealPlan(container);
        return;
    }

    const mealTypes = [
        { key: "breakfast", label: "Breakfast", icon: "B" },
        { key: "lunch", label: "Lunch", icon: "L" },
        { key: "dinner", label: "Dinner", icon: "D" },
        { key: "snack", label: "Snack", icon: "S" }
    ];

    let rendered = 0;

    mealTypes.forEach(function(meal) {
        const mealData = plan[meal.key];

        if (!mealData) return;

        let mealName = "";

        if (typeof mealData === "string") {
            mealName = mealData;
        } else if (typeof mealData === "object") {
            mealName =
                mealData.name ||
                mealData.menu ||
                mealData.food ||
                mealData.title ||
                "";
        }

        if (!mealName) return;

        const row = document.createElement("div");
        row.className = "meal-plan-row";

        const icon = document.createElement("span");
        icon.className = "meal-plan-icon";
        icon.textContent = meal.icon;

        const copy = document.createElement("div");
        copy.className = "meal-plan-copy";

        const title = document.createElement("strong");
        title.textContent = meal.label;

        const description = document.createElement("small");
        description.textContent = mealName;

        copy.append(title, description);
        row.append(icon, copy);

        container.appendChild(row);

        rendered++;
    });

    if (rendered === 0) {
        renderDashboardEmptyMealPlan(container);
    }
}


function renderDashboardEmptyMealPlan(container) {
    const empty = document.createElement("div");
    empty.className = "meal-plan-empty";

    const icon = document.createElement("span");
    icon.className = "meal-plan-icon";
    icon.textContent = "+";

    const copy = document.createElement("div");

    const title = document.createElement("strong");
    title.textContent = "Belum ada rencana menu";

    const description = document.createElement("p");
    description.textContent =
        "Buat rencana makanan melalui Meal Planner.";

    copy.append(title, description);
    empty.append(icon, copy);

    container.appendChild(empty);
}


// ==========================================
// MOBILE NAVIGATION
// ==========================================

function setupDashboardMobileMenu() {
    const sidebar = dashboardElement("sidebar");
    const toggle = dashboardElement("menuToggle");
    const overlay = dashboardElement("mobileOverlay");

    if (!sidebar || !toggle || !overlay) return;

    function closeMenu() {
        sidebar.classList.remove("open");
        overlay.classList.remove("show");
    }

    toggle.addEventListener("click", function() {
        sidebar.classList.toggle("open");
        overlay.classList.toggle("show");
    });

    overlay.addEventListener("click", closeMenu);

    sidebar.querySelectorAll(".nav-item").forEach(function(link) {
        link.addEventListener("click", closeMenu);
    });
}


// ==========================================
// REFRESH DASHBOARD
// ==========================================

function refreshNutritionDashboard() {
    renderDashboardDate();
    renderDashboardProfile();
    renderDashboardNutritionSummary();
    renderDashboardFoodList();
    renderDashboardMealPlan();
}


// ==========================================
// PAGE READY
// ==========================================

document.addEventListener("DOMContentLoaded", function() {
    refreshNutritionDashboard();
    setupDashboardMobileMenu();
});


// ==========================================
// UPDATE WHEN RETURNING TO TAB
// ==========================================

window.addEventListener("focus", function() {
    refreshNutritionDashboard();
});
