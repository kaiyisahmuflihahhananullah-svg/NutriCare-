// ==========================================
// NutriCare AI - Central Storage System
// ==========================================

const NutriStorage = {

    save(key, data) {
        localStorage.setItem(
            key,
            JSON.stringify(data)
        );
    },

    get(key, defaultValue = null) {
        const data = localStorage.getItem(key);

        if (!data) {
            return defaultValue;
        }

        try {
            return JSON.parse(data);
        } catch (error) {
            console.error(
                `Gagal membaca data: ${key}`,
                error
            );

            return defaultValue;
        }
    },

    remove(key) {
        localStorage.removeItem(key);
    },

    clear() {
        localStorage.clear();
    }
};


// ==========================================
// Storage Keys
// ==========================================

const STORAGE_KEYS = {

    USER: "nutricare_user",

    PROFILE: "nutricare_profile",

    HEALTH: "nutricare_health",

    NUTRITION: "nutricare_nutrition",

    NUTRIENT_TRACKER: "nutricare_nutrient_tracker",

    LABEL_SCANS: "nutricare_label_scans",

    WATER: "nutricare_water",

    SLEEP: "nutricare_sleep",

    ACTIVITY: "nutricare_activity",

    HABITS: "nutricare_habits",

    MEALS: "nutricare_meals",

    PANTRY: "nutricare_pantry",

    SHOPPING: "nutricare_shopping",

    CHECKINS: "nutricare_checkins",

    INSIGHTS: "nutricare_insights",

    CLAIM_CHECKS: "nutricare_claim_checks",

    MYTH_FACT: "nutricare_myth_fact",

    ACHIEVEMENTS: "nutricare_achievements",

    EDUCATION: "nutricare_education",

    SETTINGS: "nutricare_settings"

    

};