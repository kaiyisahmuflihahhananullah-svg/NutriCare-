// ==========================================
// NutriCare AI - Health Claim Checker
// ==========================================

const CLAIM_CHECK_STORAGE_KEY =
    "nutricare_claim_checks";


// ==========================================
// DATABASE KLAIM CONTOH
// ==========================================

const healthClaims = [

    {
        keywords: [
            "protein",
            "otot",
            "pertumbuhan"
        ],

        title:
            "Protein dibutuhkan tubuh untuk berbagai fungsi penting.",

        status:
            "Didukung",

        statusClass:
            "supported",

        explanation:
            "Protein merupakan salah satu zat gizi yang dibutuhkan tubuh untuk pertumbuhan, pemeliharaan, dan berbagai proses tubuh.",

        tip:
            "Utamakan variasi sumber protein dari makanan yang tersedia dan sesuai dengan kebutuhanmu."
    },


    {
        keywords: [
            "sayur",
            "buah",
            "serat"
        ],

        title:
            "Sayur dan buah merupakan sumber berbagai zat gizi dan serat.",

        status:
            "Didukung",

        statusClass:
            "supported",

        explanation:
            "Sayur dan buah dapat memberikan serat serta berbagai vitamin, mineral, dan komponen pangan lainnya.",

        tip:
            "Usahakan memilih variasi warna dan jenis sayur maupun buah."
    },


    {
        keywords: [
            "air",
            "minum",
            "cairan",
            "dehidrasi"
        ],

        title:
            "Cairan penting untuk membantu menjaga fungsi tubuh.",

        status:
            "Didukung",

        statusClass:
            "supported",

        explanation:
            "Tubuh membutuhkan cairan untuk berbagai fungsi normal. Kebutuhan setiap orang dapat berbeda.",

        tip:
            "Minum secara teratur dan perhatikan kondisi tubuh serta aktivitasmu."
    },


    {
        keywords: [
            "tidur",
            "istirahat"
        ],

        title:
            "Tidur dan istirahat merupakan bagian penting dari kesehatan.",

        status:
            "Didukung",

        statusClass:
            "supported",

        explanation:
            "Tidur membantu proses pemulihan dan mendukung berbagai fungsi tubuh.",

        tip:
            "Usahakan memiliki jadwal tidur dan bangun yang cukup teratur."
    },


    {
        keywords: [
            "sarapan"
        ],

        title:
            "Sarapan dapat menjadi salah satu kesempatan untuk memenuhi kebutuhan gizi.",

        status:
            "Perlu diperhatikan",

        statusClass:
            "caution",

        explanation:
            "Kebutuhan dan pola makan setiap orang berbeda. Tidak tepat jika satu aturan sarapan dianggap wajib untuk semua orang.",

        tip:
            "Perhatikan pola makan secara keseluruhan dan pilih makanan yang beragam."
    },


    {
        keywords: [
            "gula",
            "minuman manis"
        ],

        title:
            "Mengonsumsi makanan dan minuman tinggi gula secara berlebihan perlu diperhatikan.",

        status:
            "Perlu diperhatikan",

        statusClass:
            "caution",

        explanation:
            "Jumlah dan frekuensi konsumsi penting untuk diperhatikan. Label nutrisi dapat membantu memahami kandungan suatu produk.",

        tip:
            "Bandingkan informasi pada label dan perhatikan variasi makanan serta minuman yang dikonsumsi."
    },


    {
        keywords: [
            "vitamin",
            "suplemen"
        ],

        title:
            "Suplemen vitamin tidak selalu dibutuhkan oleh semua orang.",

        status:
            "Perlu diperhatikan",

        statusClass:
            "caution",

        explanation:
            "Kebutuhan zat gizi setiap orang berbeda. Suplemen tidak seharusnya dianggap sebagai pengganti pola makan yang beragam.",

        tip:
            "Jika memiliki kebutuhan khusus, konsultasikan dengan tenaga kesehatan yang sesuai."
    },


    {
        keywords: [
            "detox",
            "detoks"
        ],

        title:
            "Istilah 'detox' pada produk kesehatan perlu diperiksa secara kritis.",

        status:
            "Perlu diperhatikan",

        statusClass:
            "caution",

        explanation:
            "Klaim 'detox' dapat memiliki arti yang berbeda-beda dan tidak otomatis berarti suatu produk memiliki manfaat kesehatan tertentu.",

        tip:
            "Periksa bahan, informasi gizi, dan sumber informasi sebelum mempercayai klaim produk."
    }

];


// ==========================================
// SIMPAN RIWAYAT
// ==========================================

function saveClaimCheck(claimText, result) {

    const history =
        NutriStorage.get(
            CLAIM_CHECK_STORAGE_KEY,
            []
        );


    history.unshift({

        id:
            Date.now(),

        claim:
            claimText,

        status:
            result.status,

        title:
            result.title,

        date:
            new Date().toISOString()

    });


    NutriStorage.save(
        CLAIM_CHECK_STORAGE_KEY,
        history.slice(0, 10)
    );

}


// ==========================================
// CARI KLAIM
// ==========================================

function findMatchingClaim(text) {

    const normalizedText =
        text.toLowerCase();


    for (
        let i = 0;
        i < healthClaims.length;
        i++
    ) {

        const claim =
            healthClaims[i];


        const matched =
            claim.keywords.some(
                function(keyword) {

                    return normalizedText.includes(
                        keyword
                    );

                }
            );


        if (matched) {

            return claim;

        }

    }


    return null;

}


// ==========================================
// CEK KLAIM
// ==========================================

function checkHealthClaim() {

    const input =
        document.getElementById(
            "claimInput"
        );


    const result =
        document.getElementById(
            "claimResult"
        );


    if (!input || !result) {
        return;
    }


    const claimText =
        input.value.trim();


    if (!claimText) {

        alert(
            "Masukkan klaim kesehatan terlebih dahulu."
        );

        input.focus();

        return;
    }


    const matchedClaim =
        findMatchingClaim(
            claimText
        );


    // ======================================
    // TIDAK DITEMUKAN
    // ======================================

    if (!matchedClaim) {

        result.innerHTML = `

            <div class="claim-result-card">

                <div class="claim-result-icon">
                    🔎
                </div>

                <span class="claim-status unknown">
                    Belum dapat diverifikasi
                </span>

                <h2>
                    Klaim perlu diperiksa lebih lanjut
                </h2>

                <p>
                    NutriCare belum menemukan
                    informasi yang cukup sesuai
                    dengan klaim yang kamu masukkan.
                </p>

                <div class="claim-tip">

                    💡
                    Hindari langsung mempercayai
                    klaim kesehatan. Periksa sumber,
                    konteks, dan informasi pendukungnya.

                </div>

            </div>

        `;

        result.style.display =
            "block";


        saveClaimCheck(
            claimText,
            {
                status:
                    "Belum dapat diverifikasi",

                title:
                    "Klaim perlu diperiksa lebih lanjut"
            }
        );


        return;
    }


    // ======================================
    // DITEMUKAN
    // ======================================

    result.innerHTML = `

        <div class="claim-result-card">

            <div class="claim-result-icon">
                ${
                    matchedClaim.statusClass ===
                    "supported"
                        ? "✓"
                        : "⚠️"
                }
            </div>

            <span
                class="claim-status
                ${matchedClaim.statusClass}"
            >
                ${matchedClaim.status}
            </span>

            <h2>
                ${matchedClaim.title}
            </h2>

            <div class="claim-detail">

                <h3>
                    📚 Penjelasan
                </h3>

                <p>
                    ${matchedClaim.explanation}
                </p>

            </div>

            <div class="claim-tip">

                💡
                <strong>Catatan:</strong>
                ${matchedClaim.tip}

            </div>

        </div>

    `;


    result.style.display =
        "block";


    saveClaimCheck(
        claimText,
        matchedClaim
    );

}


// ==========================================
// HAPUS INPUT
// ==========================================

function clearClaimInput() {

    const input =
        document.getElementById(
            "claimInput"
        );


    const result =
        document.getElementById(
            "claimResult"
        );


    if (input) {

        input.value = "";

    }


    if (result) {

        result.style.display =
            "none";

        result.innerHTML = "";

    }

}


// ==========================================
// CONTOH KLAIM
// ==========================================

function useClaimExample(text) {

    const input =
        document.getElementById(
            "claimInput"
        );


    if (!input) {
        return;
    }


    input.value =
        text;


    input.focus();

}


// ==========================================
// RESET RIWAYAT
// ==========================================

function resetClaimHistory() {

    const confirmed =
        confirm(
            "Hapus seluruh riwayat pemeriksaan klaim?"
        );


    if (!confirmed) {
        return;
    }


    NutriStorage.remove(
        CLAIM_CHECK_STORAGE_KEY
    );


    alert(
        "Riwayat pemeriksaan berhasil dihapus."
    );

}


// ==========================================
// SAAT HALAMAN DIBUKA
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        const input =
            document.getElementById(
                "claimInput"
            );


        if (input) {

            input.addEventListener(
                "keydown",
                function(event) {

                    if (
                        event.key === "Enter" &&
                        !event.shiftKey
                    ) {

                        event.preventDefault();

                        checkHealthClaim();

                    }

                }
            );

        }

    }
);