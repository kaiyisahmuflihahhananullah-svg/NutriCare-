// ==========================================
// NutriCare AI - Achievement System
// ==========================================

const ACHIEVEMENT_STORAGE_KEY =
    "nutricare_achievements";


const achievementList = [

    {
        id: "first-habit",
        icon: "🌱",
        title: "Langkah Pertama",
        description:
            "Menyelesaikan satu kebiasaan sehat.",
        type: "habit"
    },

    {
        id: "hydration",
        icon: "💧",
        title: "Tetap Terhidrasi",
        description:
            "Mencatat konsumsi air.",
        type: "water"
    },

    {
        id: "first-education",
        icon: "📚",
        title: "Suka Belajar",
        description:
            "Membaca satu materi edukasi.",
        type: "education"
    },

    {
        id: "food-explorer",
        icon: "🍽️",
        title: "Food Explorer",
        description:
            "Menambahkan makanan ke Nutrient Tracker.",
        type: "food"
    },

    {
        id: "pantry-starter",
        icon: "🧺",
        title: "Pantry Starter",
        description:
            "Menambahkan bahan makanan ke Pantry.",
        type: "pantry"
    },

    {
        id: "smart-shopper",
        icon: "🛒",
        title: "Smart Shopper",
        description:
            "Menambahkan item ke Shopping List.",
        type: "shopping"
    },

    {
        id: "self-check",
        icon: "🌤️",
        title: "Kenali Dirimu",
        description:
            "Menyelesaikan Daily Check-in.",
        type: "checkin"
    },

    {
        id: "consistent",
        icon: "🏅",
        title: "Konsisten",
        description:
            "Menyelesaikan minimal lima kebiasaan.",
        type: "habit-five"
    }

];


// ==========================================
// AMBIL DATA ACHIEVEMENT
// ==========================================

function getAchievementData() {

    return NutriStorage.get(
        ACHIEVEMENT_STORAGE_KEY,
        []
    );

}


// ==========================================
// SIMPAN DATA
// ==========================================

function saveAchievementData(data) {

    NutriStorage.save(
        ACHIEVEMENT_STORAGE_KEY,
        data
    );

}


// ==========================================
// UNLOCK
// ==========================================

function unlockAchievement(id) {

    const unlocked =
        getAchievementData();


    if (unlocked.includes(id)) {
        return false;
    }


    unlocked.push(id);

    saveAchievementData(
        unlocked
    );


    const achievement =
        achievementList.find(
            function(item) {
                return item.id === id;
            }
        );


    if (achievement) {

        showAchievementNotification(
            achievement
        );

    }


    return true;

}


// ==========================================
// NOTIFIKASI
// ==========================================

function showAchievementNotification(
    achievement
) {

    const existing =
        document.getElementById(
            "achievementToast"
        );


    if (existing) {
        existing.remove();
    }


    const toast =
        document.createElement(
            "div"
        );


    toast.id =
        "achievementToast";


    toast.innerHTML = `

        <div class="achievement-toast-icon">
            ${achievement.icon}
        </div>

        <div>

            <strong>
                Achievement terbuka!
            </strong>

            <p>
                ${achievement.title}
            </p>

        </div>

    `;


    document.body.appendChild(
        toast
    );


    setTimeout(
        function() {

            toast.classList.add(
                "show"
            );

        },
        50
    );


    setTimeout(
        function() {

            toast.classList.remove(
                "show"
            );

            setTimeout(
                function() {

                    toast.remove();

                },
                300
            );

        },
        3000
    );

}


// ==========================================
// CEK ACHIEVEMENT
// ==========================================

function checkAchievements() {

    const unlocked =
        getAchievementData();


    // ------------------------------
    // HABIT
    // ------------------------------

    const habitData =
        NutriStorage.get(
            "nutricare_habits",
            null
        );


    if (habitData) {

        const history =
            habitData.history || {};


        let completedCount = 0;


        Object.values(history)
            .forEach(
                function(day) {

                    if (
                        Array.isArray(day)
                    ) {

                        completedCount +=
                            day.length;

                    }

                }
            );


        if (
            completedCount >= 1 &&
            !unlocked.includes(
                "first-habit"
            )
        ) {

            unlockAchievement(
                "first-habit"
            );

        }


        if (
            completedCount >= 5 &&
            !unlocked.includes(
                "consistent"
            )
        ) {

            unlockAchievement(
                "consistent"
            );

        }

    }


    // ------------------------------
    // WATER
    // ------------------------------

    const waterData =
        NutriStorage.get(
            "nutricare_water",
            null
        );


    if (
        waterData &&
        waterData.consumed > 0
    ) {

        unlockAchievement(
            "hydration"
        );

    }


    // ------------------------------
    // EDUCATION
    // ------------------------------

    const educationData =
        NutriStorage.get(
            "nutricare_education",
            []
        );


    if (
        Array.isArray(
            educationData
        ) &&
        educationData.length > 0
    ) {

        unlockAchievement(
            "first-education"
        );

    }


    // ------------------------------
    // FOOD
    // ------------------------------

    const nutrientData =
        NutriStorage.get(
            "nutricare_nutrient_tracker",
            []
        );


    if (
        Array.isArray(
            nutrientData
        ) &&
        nutrientData.length > 0
    ) {

        unlockAchievement(
            "food-explorer"
        );

    }


    // ------------------------------
    // PANTRY
    // ------------------------------

    const pantryData =
        NutriStorage.get(
            "nutricare_pantry",
            []
        );


    if (
        Array.isArray(
            pantryData
        ) &&
        pantryData.length > 0
    ) {

        unlockAchievement(
            "pantry-starter"
        );

    }


    // ------------------------------
    // SHOPPING
    // ------------------------------

    const shoppingData =
        NutriStorage.get(
            "nutricare_shopping",
            []
        );


    if (
        Array.isArray(
            shoppingData
        ) &&
        shoppingData.length > 0
    ) {

        unlockAchievement(
            "smart-shopper"
        );

    }


    // ------------------------------
    // CHECK-IN
    // ------------------------------

    const checkinData =
        NutriStorage.get(
            "nutricare_checkins",
            {}
        );


    if (
        checkinData &&
        Object.keys(
            checkinData
        ).length > 0
    ) {

        unlockAchievement(
            "self-check"
        );

    }

}


// ==========================================
// RENDER ACHIEVEMENT
// ==========================================

function renderAchievements() {

    const container =
        document.getElementById(
            "achievementGrid"
        );


    if (!container) {
        return;
    }


    const unlocked =
        getAchievementData();


    container.innerHTML =
        achievementList.map(
            function(achievement) {

                const isUnlocked =
                    unlocked.includes(
                        achievement.id
                    );


                return `

                    <article
                        class="
                            achievement-card
                            ${isUnlocked ? "unlocked" : "locked"}
                        "
                    >

                        <div
                            class="achievement-icon"
                        >

                            ${
                                isUnlocked
                                    ? achievement.icon
                                    : "🔒"
                            }

                        </div>


                        <div
                            class="achievement-content"
                        >

                            <span
                                class="achievement-status"
                            >

                                ${
                                    isUnlocked
                                        ? "✓ Terbuka"
                                        : "Belum terbuka"
                                }

                            </span>


                            <h3>
                                ${achievement.title}
                            </h3>


                            <p>
                                ${achievement.description}
                            </p>

                        </div>

                    </article>

                `;

            }
        ).join("");


    const countElement =
        document.getElementById(
            "achievementCount"
        );


    if (countElement) {

        countElement.textContent =
            `${unlocked.length} / ${achievementList.length}`;

    }


    const progressBar =
        document.getElementById(
            "achievementProgress"
        );


    if (progressBar) {

        const percentage =
            achievementList.length > 0
                ? Math.round(
                    (
                        unlocked.length /
                        achievementList.length
                    ) * 100
                )
                : 0;


        progressBar.style.width =
            percentage + "%";

    }

}


// ==========================================
// RESET
// ==========================================

function resetAchievements() {

    const confirmed =
        confirm(
            "Hapus semua achievement yang sudah terbuka?"
        );


    if (!confirmed) {
        return;
    }


    NutriStorage.remove(
        ACHIEVEMENT_STORAGE_KEY
    );


    renderAchievements();

}


// ==========================================
// INIT
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        checkAchievements();

        renderAchievements();

    }
);