// ==========================================
// NutriCare AI - Sleep Tracker
// ==========================================

const SLEEP_STORAGE_KEY = "nutricare_sleep";


// ==========================================
// Ambil data tidur hari ini
// ==========================================

function getTodaySleepData() {

    const today =
        new Date().toISOString().split("T")[0];

    const saved =
        NutriStorage.get(
            SLEEP_STORAGE_KEY,
            null
        );

    if (!saved || saved.date !== today) {

        return {
            date: today,
            sleepTime: "",
            wakeTime: "",
            duration: 0
        };

    }

    return saved;
}


// ==========================================
// Hitung durasi tidur
// ==========================================

function calculateSleepDuration(
    sleepTime,
    wakeTime
) {

    if (!sleepTime || !wakeTime) {
        return 0;
    }

    const sleep =
        new Date(
            `2000-01-01T${sleepTime}`
        );

    let wake =
        new Date(
            `2000-01-01T${wakeTime}`
        );


    // Jika bangun berada di hari berikutnya
    if (wake <= sleep) {

        wake.setDate(
            wake.getDate() + 1
        );

    }


    const difference =
        wake - sleep;

    return Math.round(
        difference / 3600000 * 10
    ) / 10;

}


// ==========================================
// Simpan data tidur
// ==========================================

function saveSleepData() {

    const sleepTime =
        document.getElementById(
            "sleepTime"
        ).value;

    const wakeTime =
        document.getElementById(
            "wakeTime"
        ).value;


    if (!sleepTime || !wakeTime) {

        alert(
            "Isi jam tidur dan jam bangun terlebih dahulu."
        );

        return;

    }


    const duration =
        calculateSleepDuration(
            sleepTime,
            wakeTime
        );


    const data = {

        date:
            new Date()
                .toISOString()
                .split("T")[0],

        sleepTime:
            sleepTime,

        wakeTime:
            wakeTime,

        duration:
            duration

    };


    NutriStorage.save(
        SLEEP_STORAGE_KEY,
        data
    );


    renderSleepTracker();

    alert(
        "Data tidur berhasil disimpan."
    );

}


// ==========================================
// Tampilkan data
// ==========================================

function renderSleepTracker() {

    const data =
        getTodaySleepData();


    const sleepInput =
        document.getElementById(
            "sleepTime"
        );

    const wakeInput =
        document.getElementById(
            "wakeTime"
        );

    const durationElement =
        document.getElementById(
            "sleepDuration"
        );


    if (sleepInput) {

        sleepInput.value =
            data.sleepTime;

    }


    if (wakeInput) {

        wakeInput.value =
            data.wakeTime;

    }


    if (durationElement) {

        if (data.duration > 0) {

            durationElement.textContent =
                data.duration + " jam";

        } else {

            durationElement.textContent =
                "Belum ada data";

        }

    }

}


// ==========================================
// Reset data
// ==========================================

function resetSleepData() {

    const today =
        new Date()
            .toISOString()
            .split("T")[0];


    NutriStorage.save(
        SLEEP_STORAGE_KEY,
        {
            date: today,
            sleepTime: "",
            wakeTime: "",
            duration: 0
        }
    );


    renderSleepTracker();

}


// ==========================================
// Jalankan saat halaman dibuka
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderSleepTracker();

    }
);