// ==========================================
// NutriCare AI - Pantry
// ==========================================

const PANTRY_STORAGE_KEY = "nutricare_pantry";


// ==========================================
// DATA DEFAULT
// ==========================================

const defaultPantryItems = [];


// ==========================================
// AMBIL DATA PANTRY
// ==========================================

function getPantryData() {

    const saved = NutriStorage.get(
        PANTRY_STORAGE_KEY,
        null
    );

    if (!saved) {
        return defaultPantryItems;
    }

    return saved;
}


// ==========================================
// SIMPAN DATA PANTRY
// ==========================================

function savePantryData(data) {

    NutriStorage.save(
        PANTRY_STORAGE_KEY,
        data
    );
}


// ==========================================
// TAMBAH ITEM
// ==========================================

function addPantryItem() {

    const nameInput =
        document.getElementById("pantryName");

    const quantityInput =
        document.getElementById("pantryQuantity");

    const unitInput =
        document.getElementById("pantryUnit");

    const categoryInput =
        document.getElementById("pantryCategory");


    if (!nameInput || !quantityInput) return;


    const name =
        nameInput.value.trim();

    const quantity =
        Number(quantityInput.value);

    const unit =
        unitInput.value;

    const category =
        categoryInput.value;


    if (!name) {

        alert(
            "Masukkan nama bahan makanan terlebih dahulu."
        );

        return;
    }


    if (!quantity || quantity <= 0) {

        alert(
            "Masukkan jumlah stok yang valid."
        );

        return;
    }


    const data =
        getPantryData();


    data.push({

        id:
            Date.now(),

        name:
            name,

        quantity:
            quantity,

        unit:
            unit,

        category:
            category,

        createdAt:
            new Date().toISOString()

    });


    savePantryData(data);


    nameInput.value = "";

    quantityInput.value = "";


    renderPantry();


    alert(
        "Bahan berhasil ditambahkan ke Pantry."
    );
}


// ==========================================
// HAPUS ITEM
// ==========================================

function deletePantryItem(id) {

    const confirmed =
        confirm(
            "Hapus bahan ini dari Pantry?"
        );


    if (!confirmed) return;


    let data =
        getPantryData();


    data =
        data.filter(
            function(item) {

                return item.id !== id;

            }
        );


    savePantryData(data);

    renderPantry();
}


// ==========================================
// UBAH JUMLAH STOK
// ==========================================

function changePantryQuantity(
    id,
    amount
) {

    const data =
        getPantryData();


    const item =
        data.find(
            function(item) {

                return item.id === id;

            }
        );


    if (!item) return;


    item.quantity += amount;


    if (item.quantity <= 0) {

        const confirmed =
            confirm(
                "Stok sudah habis. Hapus bahan ini?"
            );


        if (confirmed) {

            const filtered =
                data.filter(
                    function(item) {

                        return item.id !== id;

                    }
                );


            savePantryData(filtered);

            renderPantry();

            return;

        }


        item.quantity = 1;
    }


    savePantryData(data);

    renderPantry();
}


// ==========================================
// STATUS STOK
// ==========================================

function getStockStatus(quantity) {

    if (quantity <= 1) {

        return {
            label: "Hampir habis",
            className: "low-stock"
        };

    }


    if (quantity <= 3) {

        return {
            label: "Perlu diperhatikan",
            className: "medium-stock"
        };

    }


    return {
        label: "Tersedia",
        className: "good-stock"
    };
}


// ==========================================
// RENDER PANTRY
// ==========================================

function renderPantry() {

    const container =
        document.getElementById(
            "pantryList"
        );


    const totalElement =
        document.getElementById(
            "pantryTotal"
        );


    const lowElement =
        document.getElementById(
            "pantryLow"
        );


    if (!container) return;


    const data =
        getPantryData();


    if (totalElement) {

        totalElement.textContent =
            data.length;
    }


    const lowStock =
        data.filter(
            function(item) {

                return item.quantity <= 1;

            }
        );


    if (lowElement) {

        lowElement.textContent =
            lowStock.length;
    }


    if (data.length === 0) {

        container.innerHTML = `

            <div class="pantry-empty">

                <div class="pantry-empty-icon">
                    🧺
                </div>

                <h3>
                    Pantry masih kosong
                </h3>

                <p>
                    Tambahkan bahan makanan yang
                    tersedia di rumah.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        data.map(
            function(item) {

                const status =
                    getStockStatus(
                        item.quantity
                    );


                return `

                    <div class="pantry-item">

                        <div class="pantry-food-icon">
                            ${getPantryIcon(item.category)}
                        </div>


                        <div class="pantry-food-info">

                            <h3>
                                ${item.name}
                            </h3>

                            <p>
                                ${item.category}
                            </p>


                            <span
                                class="stock-badge ${status.className}"
                            >
                                ${status.label}
                            </span>

                        </div>


                        <div class="pantry-controls">

                            <button
                                onclick="changePantryQuantity(${item.id}, -1)"
                            >
                                −
                            </button>


                            <div class="pantry-quantity">

                                <strong>
                                    ${item.quantity}
                                </strong>

                                <span>
                                    ${item.unit}
                                </span>

                            </div>


                            <button
                                onclick="changePantryQuantity(${item.id}, 1)"
                            >
                                +
                            </button>

                        </div>


                        <button
                            class="pantry-delete"
                            onclick="deletePantryItem(${item.id})"
                        >
                            🗑️
                        </button>

                    </div>

                `;

            }
        ).join("");
}


// ==========================================
// ICON KATEGORI
// ==========================================

function getPantryIcon(category) {

    const icons = {

        "Karbohidrat": "🍚",

        "Protein": "🥚",

        "Sayur": "🥦",

        "Buah": "🍎",

        "Susu & Olahan": "🥛",

        "Bumbu": "🧂",

        "Lainnya": "🧺"

    };


    return icons[category] || "🧺";
}


// ==========================================
// FILTER KATEGORI
// ==========================================

function filterPantry() {

    const filter =
        document.getElementById(
            "pantryFilter"
        );


    const container =
        document.getElementById(
            "pantryList"
        );


    if (!filter || !container) return;


    const selectedCategory =
        filter.value;


    const data =
        getPantryData();


    let filteredData =
        data;


    if (selectedCategory) {

        filteredData =
            data.filter(
                function(item) {

                    return item.category ===
                        selectedCategory;

                }
            );
    }


    if (filteredData.length === 0) {

        container.innerHTML = `

            <div class="pantry-empty">

                <div class="pantry-empty-icon">
                    🔎
                </div>

                <h3>
                    Tidak ada bahan
                </h3>

                <p>
                    Belum ada bahan dalam kategori ini.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        filteredData.map(
            function(item) {

                const status =
                    getStockStatus(
                        item.quantity
                    );


                return `

                    <div class="pantry-item">

                        <div class="pantry-food-icon">
                            ${getPantryIcon(item.category)}
                        </div>


                        <div class="pantry-food-info">

                            <h3>
                                ${item.name}
                            </h3>

                            <p>
                                ${item.category}
                            </p>

                            <span
                                class="stock-badge ${status.className}"
                            >
                                ${status.label}
                            </span>

                        </div>


                        <div class="pantry-controls">

                            <button
                                onclick="changePantryQuantity(${item.id}, -1)"
                            >
                                −
                            </button>

                            <div class="pantry-quantity">

                                <strong>
                                    ${item.quantity}
                                </strong>

                                <span>
                                    ${item.unit}
                                </span>

                            </div>

                            <button
                                onclick="changePantryQuantity(${item.id}, 1)"
                            >
                                +
                            </button>

                        </div>


                        <button
                            class="pantry-delete"
                            onclick="deletePantryItem(${item.id})"
                        >
                            🗑️
                        </button>

                    </div>

                `;

            }
        ).join("");
}


// ==========================================
// RESET PANTRY
// ==========================================

function resetPantry() {

    const confirmed =
        confirm(
            "Hapus semua bahan dari Pantry?"
        );


    if (!confirmed) return;


    NutriStorage.remove(
        PANTRY_STORAGE_KEY
    );


    renderPantry();
}


// ==========================================
// SAAT HALAMAN DIBUKA
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderPantry();

    }
);