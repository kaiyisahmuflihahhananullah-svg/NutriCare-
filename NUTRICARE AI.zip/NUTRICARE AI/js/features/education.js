// ==========================================
// NutriCare AI - Education
// ==========================================

const EDUCATION_STORAGE_KEY = "nutricare_education";


// ==========================================
// DATA MATERI
// ==========================================

const educationMaterials = [

    {
        id: "balanced-meal",
        icon: "🍽️",
        title: "Mengenal Pola Makan Seimbang",
        category: "Nutrisi",
        description:
            "Memahami pentingnya variasi makanan dan keseimbangan dalam pola makan sehari-hari.",
        content: `
            <h3>Apa itu pola makan seimbang?</h3>

            <p>
                Pola makan seimbang adalah kebiasaan memilih
                beragam makanan agar tubuh mendapatkan berbagai
                zat gizi yang dibutuhkan.
            </p>

            <h3>Kenapa variasi makanan penting?</h3>

            <p>
                Setiap jenis makanan memiliki kandungan zat gizi
                yang berbeda. Karena itu, mengonsumsi beragam
                sumber makanan membantu memenuhi kebutuhan tubuh
                dengan lebih baik.
            </p>

            <ul>
                <li>Pilih sumber karbohidrat yang beragam.</li>
                <li>Sertakan sumber protein.</li>
                <li>Tambahkan sayur dan buah.</li>
                <li>Perhatikan kebutuhan cairan.</li>
            </ul>

            <div class="education-tip">
                💡 Tidak perlu membuat pola makan yang sempurna.
                Yang penting adalah membangun kebiasaan yang
                beragam dan seimbang secara bertahap.
            </div>
        `
    },


    {
        id: "hydration",
        icon: "💧",
        title: "Kenapa Tubuh Membutuhkan Cairan?",
        category: "Hidrasi",
        description:
            "Pelajari peran cairan dalam membantu berbagai fungsi tubuh.",
        content: `
            <h3>Peran cairan bagi tubuh</h3>

            <p>
                Cairan membantu tubuh menjalankan berbagai proses
                penting, termasuk membantu mengatur suhu tubuh
                dan mendukung fungsi normal tubuh.
            </p>

            <h3>Kapan perlu lebih memperhatikan cairan?</h3>

            <ul>
                <li>Saat cuaca terasa panas.</li>
                <li>Saat melakukan aktivitas fisik.</li>
                <li>Saat banyak berkeringat.</li>
                <li>Saat tubuh membutuhkan penggantian cairan.</li>
            </ul>

            <div class="education-tip">
                💡 Biasakan minum secara teratur sepanjang hari,
                bukan hanya ketika sudah merasa sangat haus.
            </div>
        `
    },


    {
        id: "sleep",
        icon: "😴",
        title: "Tidur dan Pemulihan",
        category: "Istirahat",
        description:
            "Memahami mengapa tidur yang cukup dan teratur penting untuk keseharian.",
        content: `
            <h3>Mengapa tidur penting?</h3>

            <p>
                Tidur memberikan kesempatan bagi tubuh dan pikiran
                untuk beristirahat serta melakukan proses pemulihan.
            </p>

            <h3>Kebiasaan tidur yang dapat membantu</h3>

            <ul>
                <li>Usahakan waktu tidur dan bangun cukup teratur.</li>
                <li>Buat suasana kamar nyaman untuk beristirahat.</li>
                <li>Kurangi aktivitas yang terlalu merangsang sebelum tidur.</li>
                <li>Berikan waktu tubuh untuk bersiap sebelum tidur.</li>
            </ul>

            <div class="education-tip">
                💡 Kualitas tidur tidak hanya dipengaruhi oleh
                lamanya tidur, tetapi juga oleh kebiasaan dan
                kondisi sebelum tidur.
            </div>
        `
    },


    {
        id: "activity",
        icon: "🏃",
        title: "Aktivitas Fisik Sehari-hari",
        category: "Aktivitas",
        description:
            "Kenali manfaat aktivitas fisik dan cara memasukkannya ke rutinitas.",
        content: `
            <h3>Apa manfaat aktivitas fisik?</h3>

            <p>
                Aktivitas fisik membantu menjaga kebugaran,
                mendukung kesehatan tubuh, dan dapat menjadi
                bagian dari rutinitas harian yang menyenangkan.
            </p>

            <h3>Contoh aktivitas</h3>

            <ul>
                <li>Berjalan kaki.</li>
                <li>Bersepeda.</li>
                <li>Melakukan olahraga yang disukai.</li>
                <li>Aktivitas rumah tangga.</li>
                <li>Melakukan peregangan atau bergerak setelah duduk lama.</li>
            </ul>

            <div class="education-tip">
                💡 Pilih aktivitas yang nyaman dan sesuai kemampuan.
                Aktivitas fisik tidak harus selalu berupa olahraga
                yang berat.
            </div>
        `
    },


    {
        id: "food-label",
        icon: "🧾",
        title: "Cara Membaca Label Makanan",
        category: "Label Makanan",
        description:
            "Kenali informasi penting yang biasanya terdapat pada kemasan makanan.",
        content: `
            <h3>Apa yang bisa dilihat pada label?</h3>

            <ul>
                <li>Ukuran sajian.</li>
                <li>Energi.</li>
                <li>Protein.</li>
                <li>Karbohidrat.</li>
                <li>Gula.</li>
                <li>Serat.</li>
                <li>Natrium.</li>
                <li>Daftar bahan.</li>
            </ul>

            <h3>Perhatikan ukuran sajian</h3>

            <p>
                Angka pada informasi gizi biasanya berkaitan dengan
                ukuran sajian yang tercantum pada kemasan. Karena itu,
                perhatikan ukuran sajian ketika membaca informasi gizi.
            </p>

            <div class="education-tip">
                💡 Gunakan informasi label sebagai alat untuk
                memahami produk, bukan sebagai satu-satunya dasar
                untuk menentukan pola makan.
            </div>
        `
    },


    {
        id: "food-variety",
        icon: "🥦",
        title: "Kenapa Perlu Makan Beragam?",
        category: "Nutrisi",
        description:
            "Pelajari alasan variasi makanan penting dalam kebiasaan makan.",
        content: `
            <h3>Setiap makanan punya karakteristik berbeda</h3>

            <p>
                Tidak semua makanan memiliki kandungan zat gizi
                yang sama. Mengombinasikan berbagai jenis makanan
                membantu memberikan variasi zat gizi.
            </p>

            <h3>Contoh variasi</h3>

            <ul>
                <li>Ganti-ganti sumber protein.</li>
                <li>Pilih berbagai jenis sayuran.</li>
                <li>Tambahkan buah dengan warna yang beragam.</li>
                <li>Gunakan berbagai sumber karbohidrat.</li>
            </ul>

            <div class="education-tip">
                💡 Variasi makanan juga bisa membuat waktu makan
                terasa lebih menarik dan tidak monoton.
            </div>
        `
    },


    {
        id: "healthy-habits",
        icon: "🌱",
        title: "Membangun Kebiasaan Sehat",
        category: "Kebiasaan",
        description:
            "Cara membangun kebiasaan sehat secara bertahap dan realistis.",
        content: `
            <h3>Mulai dari kebiasaan kecil</h3>

            <p>
                Perubahan kebiasaan tidak harus dilakukan sekaligus.
                Memulai dari langkah kecil dapat membuat perubahan
                terasa lebih mudah dilakukan secara konsisten.
            </p>

            <h3>Contoh kebiasaan</h3>

            <ul>
                <li>Minum secara teratur.</li>
                <li>Menambahkan variasi makanan.</li>
                <li>Menjaga jadwal tidur.</li>
                <li>Bergerak secara rutin.</li>
                <li>Meluangkan waktu untuk istirahat.</li>
            </ul>

            <div class="education-tip">
                💡 Fokus pada perkembangan kebiasaanmu sendiri,
                bukan membandingkannya dengan orang lain.
            </div>
        `
    },


    {
        id: "meal-planning",
        icon: "🗓️",
        title: "Mengenal Meal Planning",
        category: "Perencanaan",
        description:
            "Cara sederhana merencanakan pilihan makanan agar lebih terorganisir.",
        content: `
            <h3>Apa itu meal planning?</h3>

            <p>
                Meal planning adalah kegiatan merencanakan pilihan
                makanan untuk beberapa waktu ke depan agar kebutuhan
                makanan di rumah lebih mudah diatur.
            </p>

            <h3>Manfaatnya</h3>

            <ul>
                <li>Membantu menentukan bahan yang perlu tersedia.</li>
                <li>Membuat pilihan makanan lebih terorganisir.</li>
                <li>Membantu mengurangi kebingungan saat menentukan makanan.</li>
                <li>Memudahkan pembuatan daftar belanja.</li>
            </ul>

            <div class="education-tip">
                💡 Rencana makanan boleh fleksibel dan disesuaikan
                dengan bahan yang tersedia di rumah.
            </div>
        `
    }

];


// ==========================================
// STORAGE PROGRESS
// ==========================================

function getEducationProgress() {

    return NutriStorage.get(
        EDUCATION_STORAGE_KEY,
        []
    );

}


function saveEducationProgress(progress) {

    NutriStorage.save(
        EDUCATION_STORAGE_KEY,
        progress
    );

}


// ==========================================
// TANDAI SUDAH DIBACA
// ==========================================

function markEducationAsRead(id) {

    const progress =
        getEducationProgress();


    if (!progress.includes(id)) {

        progress.push(id);

        saveEducationProgress(
            progress
        );

    }


    updateEducationProgress();


    renderEducationMaterials(
        getCurrentEducationFilter(),
        getCurrentEducationSearch()
    );

}


// ==========================================
// PROGRESS
// ==========================================

function updateEducationProgress() {

    const progress =
        getEducationProgress();


    const total =
        educationMaterials.length;


    const completed =
        progress.length;


    let percentage = 0;


    if (total > 0) {

        percentage =
            Math.round(
                (completed / total) * 100
            );

    }


    const progressText =
        document.getElementById(
            "educationProgressText"
        );


    const progressBar =
        document.getElementById(
            "educationProgressBar"
        );


    if (progressText) {

        progressText.textContent =
            `${completed} dari ${total} materi dibaca`;

    }


    if (progressBar) {

        progressBar.style.width =
            percentage + "%";

    }

}


// ==========================================
// FILTER & SEARCH
// ==========================================

let currentEducationFilter = "Semua";

let currentEducationSearch = "";


function getCurrentEducationFilter() {

    return currentEducationFilter;

}


function getCurrentEducationSearch() {

    return currentEducationSearch;

}


function filterEducation(category) {

    currentEducationFilter =
        category;


    document
        .querySelectorAll(
            ".category-button"
        )
        .forEach(
            function(button) {

                button.classList.remove(
                    "active"
                );

            }
        );


    const selectedButton =
        document.querySelector(
            `.category-button[data-category="${category}"]`
        );


    if (selectedButton) {

        selectedButton.classList.add(
            "active"
        );

    }


    renderEducationMaterials(
        category,
        currentEducationSearch
    );

}


function searchEducation(value) {

    currentEducationSearch =
        value
            .toLowerCase()
            .trim();


    renderEducationMaterials(
        currentEducationFilter,
        currentEducationSearch
    );

}


// ==========================================
// RENDER MATERI
// ==========================================

function renderEducationMaterials(
    category = "Semua",
    search = ""
) {

    const container =
        document.getElementById(
            "educationGrid"
        );


    if (!container) {
        return;
    }


    const progress =
        getEducationProgress();


    const filtered =
        educationMaterials.filter(
            function(material) {

                const matchCategory =
                    category === "Semua" ||
                    material.category === category;


                const searchText =
                    (
                        material.title +
                        " " +
                        material.description +
                        " " +
                        material.category
                    ).toLowerCase();


                const matchSearch =
                    !search ||
                    searchText.includes(search);


                return (
                    matchCategory &&
                    matchSearch
                );

            }
        );


    if (filtered.length === 0) {

        container.innerHTML = `

            <div class="education-empty">

                <div class="empty-icon">
                    🔎
                </div>

                <h3>
                    Materi tidak ditemukan
                </h3>

                <p>
                    Coba gunakan kata pencarian
                    atau kategori lain.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        filtered.map(
            function(material) {

                const isRead =
                    progress.includes(
                        material.id
                    );


                return `

                    <article
                        class="education-card ${isRead ? "read" : ""}"
                    >

                        <div class="education-icon">
                            ${material.icon}
                        </div>


                        <div class="education-card-content">

                            <span class="education-category">
                                ${material.category}
                            </span>


                            <h3>
                                ${material.title}
                            </h3>


                            <p>
                                ${material.description}
                            </p>


                            <div
                                class="education-card-footer"
                            >

                                ${
                                    isRead
                                        ? `
                                            <span
                                                class="read-status"
                                            >
                                                ✓ Sudah dibaca
                                            </span>
                                        `
                                        : `
                                            <span
                                                class="unread-status"
                                            >
                                                Belum dibaca
                                            </span>
                                        `
                                }


                                <button
                                    class="read-button"
                                    onclick="openEducationMaterial('${material.id}')"
                                >
                                    📖 Baca Materi
                                </button>

                            </div>

                        </div>

                    </article>

                `;

            }
        ).join("");

}


// ==========================================
// BUKA MATERI
// ==========================================

function openEducationMaterial(id) {

    const material =
        educationMaterials.find(
            function(item) {

                return item.id === id;

            }
        );


    if (!material) {
        return;
    }


    const modal =
        document.getElementById(
            "educationModal"
        );


    const title =
        document.getElementById(
            "educationModalTitle"
        );


    const category =
        document.getElementById(
            "educationModalCategory"
        );


    const content =
        document.getElementById(
            "educationModalContent"
        );


    if (!modal) {
        return;
    }


    if (title) {

        title.textContent =
            material.title;

    }


    if (category) {

        category.textContent =
            material.category;

    }


    if (content) {

        content.innerHTML =
            material.content;

    }


    modal.classList.add(
        "show"
    );


    markEducationAsRead(
        id
    );

}


// ==========================================
// TUTUP MODAL
// ==========================================

function closeEducationModal() {

    const modal =
        document.getElementById(
            "educationModal"
        );


    if (modal) {

        modal.classList.remove(
            "show"
        );

    }

}


// ==========================================
// RESET PROGRESS
// ==========================================

function resetEducationProgress() {

    const confirmed =
        confirm(
            "Hapus semua progress materi yang sudah dibaca?"
        );


    if (!confirmed) {
        return;
    }


    NutriStorage.remove(
        EDUCATION_STORAGE_KEY
    );


    updateEducationProgress();


    renderEducationMaterials(
        currentEducationFilter,
        currentEducationSearch
    );

}


// ==========================================
// INIT
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderEducationMaterials();

        updateEducationProgress();

    }
);