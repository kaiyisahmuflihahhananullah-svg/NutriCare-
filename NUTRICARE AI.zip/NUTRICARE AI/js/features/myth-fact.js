// ==========================================
// NutriCare AI - Myth & Fact
// ==========================================

const MYTH_FACT_STORAGE_KEY =
    "nutricare_myth_fact";


// ==========================================
// DATA MITOS & FAKTA
// ==========================================

const mythFactData = [

    {
        category: "Nutrisi",

        myth:
            "Karbohidrat harus dihindari agar tubuh tetap sehat.",

        fact:
            "Karbohidrat merupakan salah satu sumber energi bagi tubuh. Yang penting adalah memilih makanan yang beragam dan sesuai kebutuhan.",

        explanation:
            "Karbohidrat dapat ditemukan dalam berbagai makanan seperti nasi, kentang, jagung, roti, dan sumber lainnya. Kebutuhan setiap orang dapat berbeda."
    },


    {
        category: "Minuman",

        myth:
            "Semua orang harus minum air dengan jumlah yang sama setiap hari.",

        fact:
            "Kebutuhan cairan dapat berbeda antara satu orang dengan orang lainnya.",

        explanation:
            "Kebutuhan cairan dapat dipengaruhi oleh aktivitas, kondisi lingkungan, makanan yang dikonsumsi, dan kondisi tubuh."
    },


    {
        category: "Buah & Sayur",

        myth:
            "Buah tidak sehat karena mengandung gula.",

        fact:
            "Buah dapat menjadi bagian dari pola makan yang beragam dan menyediakan berbagai zat gizi serta serat.",

        explanation:
            "Buah mengandung gula alami bersama dengan air, serat, vitamin, mineral, dan komponen pangan lainnya."
    },


    {
        category: "Protein",

        myth:
            "Protein hanya bisa didapatkan dari daging.",

        fact:
            "Protein dapat berasal dari berbagai sumber makanan.",

        explanation:
            "Selain daging, sumber protein dapat berasal dari ikan, telur, susu dan olahannya, kacang-kacangan, tahu, tempe, dan makanan lainnya."
    },


    {
        category: "Sarapan",

        myth:
            "Semua orang wajib sarapan pada waktu yang sama.",

        fact:
            "Pola makan setiap orang dapat berbeda dan kebutuhan makan tidak selalu sama.",

        explanation:
            "Sarapan dapat menjadi salah satu kesempatan untuk mendapatkan energi dan zat gizi, tetapi kebutuhan dan pola makan seseorang dapat berbeda."
    },


    {
        category: "Tidur",

        myth:
            "Tidur hanya berguna ketika tubuh sedang lelah.",

        fact:
            "Tidur merupakan bagian penting dari proses pemulihan dan kesehatan tubuh.",

        explanation:
            "Tidur berperan dalam berbagai proses tubuh dan membantu mendukung fungsi fisik maupun kognitif."
    },


    {
        category: "Aktivitas",

        myth:
            "Aktivitas fisik harus selalu berat agar bermanfaat.",

        fact:
            "Aktivitas fisik dapat dilakukan dalam berbagai bentuk dan tingkat intensitas.",

        explanation:
            "Aktivitas yang sesuai kemampuan dan dilakukan secara rutin dapat menjadi bagian dari gaya hidup sehat."
    },


    {
        category: "Suplemen",

        myth:
            "Semakin banyak vitamin yang dikonsumsi, semakin sehat tubuh.",

        fact:
            "Kebutuhan vitamin setiap orang berbeda dan lebih banyak tidak selalu berarti lebih baik.",

        explanation:
            "Pola makan yang beragam membantu memenuhi kebutuhan berbagai zat gizi. Penggunaan suplemen sebaiknya disesuaikan dengan kebutuhan."
    },


    {
        category: "Makanan",

        myth:
            "Makanan sehat harus selalu mahal.",

        fact:
            "Pilihan makanan yang beragam dan bergizi dapat disesuaikan dengan bahan makanan yang tersedia dan anggaran.",

        explanation:
            "Banyak bahan makanan sederhana dapat menjadi bagian dari pola makan yang beragam."
    },


    {
        category: "Label Makanan",

        myth:
            "Tulisan 'sehat' pada kemasan berarti produk tersebut pasti cocok untuk semua orang.",

        fact:
            "Klaim pada kemasan perlu dibaca bersama informasi lain seperti komposisi dan informasi nilai gizi.",

        explanation:
            "Satu klaim pada kemasan tidak selalu memberikan gambaran lengkap mengenai suatu produk."
    }

];


// ==========================================
// STATE
// ==========================================

let currentMythIndex = 0;

let selectedCategory = "Semua";


// ==========================================
// DATA TERFILTER
// ==========================================

function getFilteredMythFacts() {

    if (
        selectedCategory === "Semua"
    ) {

        return mythFactData;

    }


    return mythFactData.filter(
        function(item) {

            return (
                item.category ===
                selectedCategory
            );

        }
    );

}


// ==========================================
// SIMPAN PROGRESS
// ==========================================

function saveMythFactProgress() {

    NutriStorage.save(
        MYTH_FACT_STORAGE_KEY,
        {

            currentIndex:
                currentMythIndex,

            category:
                selectedCategory

        }
    );

}


// ==========================================
// LOAD PROGRESS
// ==========================================

function loadMythFactProgress() {

    const saved =
        NutriStorage.get(
            MYTH_FACT_STORAGE_KEY,
            null
        );


    if (!saved) {
        return;
    }


    if (
        typeof saved.currentIndex ===
        "number"
    ) {

        currentMythIndex =
            saved.currentIndex;

    }


    if (
        saved.category
    ) {

        selectedCategory =
            saved.category;

    }

}


// ==========================================
// TAMPILKAN KATEGORI
// ==========================================

function renderMythCategories() {

    const container =
        document.getElementById(
            "mythCategories"
        );


    if (!container) {
        return;
    }


    const categories = [
        "Semua",
        ...new Set(
            mythFactData.map(
                function(item) {
                    return item.category;
                }
            )
        )
    ];


    container.innerHTML =
        categories.map(
            function(category) {

                const active =
                    category ===
                    selectedCategory
                        ? "active"
                        : "";


                return `

                    <button
                        type="button"
                        class="category-button ${active}"
                        onclick="selectMythCategory('${category}')"
                    >
                        ${category}
                    </button>

                `;

            }
        ).join("");

}


// ==========================================
// PILIH KATEGORI
// ==========================================

function selectMythCategory(
    category
) {

    selectedCategory =
        category;


    currentMythIndex =
        0;


    saveMythFactProgress();


    renderMythCategories();

    renderMythFact();

}


// ==========================================
// RENDER KARTU
// ==========================================

function renderMythFact() {

    const mythElement =
        document.getElementById(
            "mythText"
        );


    const factElement =
        document.getElementById(
            "factText"
        );


    const explanationElement =
        document.getElementById(
            "factExplanation"
        );


    const categoryElement =
        document.getElementById(
            "currentCategory"
        );


    const counterElement =
        document.getElementById(
            "mythCounter"
        );


    const data =
        getFilteredMythFacts();


    if (
        data.length === 0
    ) {

        return;

    }


    if (
        currentMythIndex >=
        data.length
    ) {

        currentMythIndex =
            0;

    }


    if (
        currentMythIndex < 0
    ) {

        currentMythIndex =
            data.length - 1;

    }


    const current =
        data[currentMythIndex];


    if (mythElement) {

        mythElement.textContent =
            current.myth;

    }


    if (factElement) {

        factElement.textContent =
            current.fact;

    }


    if (explanationElement) {

        explanationElement.textContent =
            current.explanation;

    }


    if (categoryElement) {

        categoryElement.textContent =
            current.category;

    }


    if (counterElement) {

        counterElement.textContent =
            (
                currentMythIndex + 1
            ) +
            " / " +
            data.length;

    }


    saveMythFactProgress();

}


// ==========================================
// NEXT
// ==========================================

function nextMythFact() {

    const data =
        getFilteredMythFacts();


    if (
        data.length === 0
    ) {
        return;
    }


    currentMythIndex++;


    if (
        currentMythIndex >=
        data.length
    ) {

        currentMythIndex =
            0;

    }


    renderMythFact();

}


// ==========================================
// PREVIOUS
// ==========================================

function previousMythFact() {

    const data =
        getFilteredMythFacts();


    if (
        data.length === 0
    ) {
        return;
    }


    currentMythIndex--;


    if (
        currentMythIndex < 0
    ) {

        currentMythIndex =
            data.length - 1;

    }


    renderMythFact();

}


// ==========================================
// ACAK
// ==========================================

function randomMythFact() {

    const data =
        getFilteredMythFacts();


    if (
        data.length <= 1
    ) {

        return;

    }


    let randomIndex;


    do {

        randomIndex =
            Math.floor(
                Math.random() *
                data.length
            );

    } while (
        randomIndex ===
        currentMythIndex
    );


    currentMythIndex =
        randomIndex;


    renderMythFact();

}


// ==========================================
// RESET PROGRESS
// ==========================================

function resetMythFact() {

    const confirmed =
        confirm(
            "Reset posisi Myth & Fact?"
        );


    if (!confirmed) {
        return;
    }


    currentMythIndex =
        0;


    selectedCategory =
        "Semua";


    saveMythFactProgress();


    renderMythCategories();

    renderMythFact();

}


// ==========================================
// INIT
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadMythFactProgress();

        renderMythCategories();

        renderMythFact();

    }
);