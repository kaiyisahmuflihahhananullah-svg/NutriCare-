// ==========================================
// NutriCare AI - Health Analysis System
// ==========================================


// ==========================================
// GET HEALTH ANALYSIS
// ==========================================

function getHealthAnalysis() {

    const profile = getProfile();

    const result = {

        hasProfileData: false,

        bmi: null,

        energy: null,

        water: null,

        age: profile.age || null,

        weight: profile.weight || null,

        height: profile.height || null,

        activityLevel:
            profile.activityLevel || null,

        healthGoal:
            profile.healthGoal || ""

    };


    // ==========================================
    // CHECK PROFILE DATA
    // ==========================================

    if (
        profile.weight &&
        profile.height
    ) {

        result.hasProfileData = true;

    }


    // ==========================================
    // BMI
    // ==========================================

    if (
        profile.weight &&
        profile.height
    ) {

        result.bmi =
            calculateBMI(
                Number(profile.weight),
                Number(profile.height)
            );

    }


    // ==========================================
    // ENERGY
    // ==========================================

    if (
        profile.weight &&
        profile.height &&
        profile.age &&
        profile.gender
    ) {

        const bmr =
            calculateBMR(
                Number(profile.weight),
                Number(profile.height),
                Number(profile.age),
                profile.gender
            );


        result.energy =
            calculateDailyEnergy(
                bmr,
                profile.activityLevel
            );

    }


    // ==========================================
    // WATER
    // ==========================================

    if (profile.weight) {

        result.water =
            calculateWaterNeed(
                Number(profile.weight)
            );

    }


    return result;

}


// ==========================================
// GET BMI DESCRIPTION
// ==========================================

function getBMIExplanation(bmi) {

    if (bmi === null) {

        return "Data berat dan tinggi belum lengkap.";

    }


    if (bmi < 18.5) {

        return "Nilai BMI berada di bawah rentang rujukan BMI dewasa.";

    }


    if (bmi < 25) {

        return "Nilai BMI berada dalam rentang rujukan BMI dewasa.";

    }


    if (bmi < 30) {

        return "Nilai BMI berada di atas rentang rujukan BMI dewasa.";

    }


    return "Nilai BMI berada jauh di atas rentang rujukan BMI dewasa.";

}


// ==========================================
// GET PERSONAL INSIGHT
// ==========================================

function generateHealthInsight(analysis) {

    const insights = [];


    if (!analysis.hasProfileData) {

        insights.push(
            "Lengkapi data berat dan tinggi badan agar analisis dapat dibuat."
        );

        return insights;

    }


    if (analysis.bmi !== null) {

        insights.push(
            "Data BMI telah dihitung berdasarkan berat dan tinggi badan yang tersimpan."
        );

    }


    if (analysis.energy !== null) {

        insights.push(
            "Estimasi energi menggunakan data usia, jenis kelamin, berat, tinggi, dan tingkat aktivitas."
        );

    }


    if (analysis.water !== null) {

        insights.push(
            "Estimasi cairan dibuat sebagai perkiraan awal dan bukan pengganti saran tenaga kesehatan."
        );

    }


    if (analysis.healthGoal) {

        insights.push(
            `Tujuan kesehatan yang dipilih: ${formatHealthGoal(analysis.healthGoal)}.`
        );

    }


    return insights;

}


// ==========================================
// FORMAT HEALTH GOAL
// ==========================================

function formatHealthGoal(goal) {

    const goals = {

        healthy:
            "Menjaga kesehatan",

        "weight-management":
            "Mengelola berat badan",

        muscle:
            "Mendukung pertumbuhan otot",

        energy:
            "Meningkatkan energi",

        balanced:
            "Membangun pola hidup seimbang"

    };


    return goals[goal] || goal;

}