// ==========================================
// NutriCare AI - NutriCare Insight
// ==========================================

const INSIGHT_STORAGE_KEY = "nutricare_insights";


// ==========================================
// TANGGAL HARI INI
// ==========================================

function getInsightToday() {

    return new Date()
        .toISOString()
        .split("T")[0];

}


// ==========================================
// AMBIL DATA AIR
// ==========================================

function getInsightWaterData() {

    const data =
        NutriStorage.get(
            "nutricare_water",
            null
        );


    if (!data) {

        return {
            consumed: 0
        };

    }


    return data;

}


// ==========================================
// TARGET AIR ESTIMASI
// ==========================================

function getInsightWaterTarget() {

    const profile =
        getProfile();


    if (
        profile &&
        profile.weight
    ) {

        return Math.round(
            Number(profile.weight) * 30
        );

    }


    return 2000;

}


// ==========================================
// DATA TIDUR
// ==========================================

function getInsightSleepData() {

    const data =
        NutriStorage.get(
            "nutricare_sleep",
            null
        );


    if (!data) {
        return null;
    }


    return data;

}


// ==========================================
// DATA HABIT
// ==========================================

function getInsightHabitData() {

    const data =
        NutriStorage.get(
            "nutricare_habits",
            null
        );


    if (!data) {

        return {
            habits: [],
            history: {}
        };

    }


    return data;

}


// ==========================================
// DATA MEAL
// ==========================================

function getInsightMealData() {

    const data =
        NutriStorage.get(
            "nutricare_meals",
            null
        );


    return data;

}


// ==========================================
// DATA PANTRY
// ==========================================

function getInsightPantryData() {

    const data =
        NutriStorage.get(
            "nutricare_pantry",
            []
        );


    if (!Array.isArray(data)) {
        return [];
    }


    return data;

}


// ==========================================
// DATA SHOPPING
// ==========================================

function getInsightShoppingData() {

    const data =
        NutriStorage.get(
            "nutricare_shopping",
            []
        );


    if (!Array.isArray(data)) {
        return [];
    }


    return data;

}


// ==========================================
// HITUNG KELENGKAPAN PROFIL
// ==========================================

function getProfileCompletion() {

    const profile =
        getProfile();


    if (!profile) {

        return {
            completed: 0,
            total: 6,
            percentage: 0
        };

    }


    const fields = [

        profile.name,

        profile.age,

        profile.gender,

        profile.weight,

        profile.height,

        profile.healthGoal

    ];


    const completed =
        fields.filter(function(value) {

            return (
                value !== null &&
                value !== undefined &&
                value !== ""
            );

        }).length;


    const total =
        fields.length;


    return {

        completed: completed,

        total: total,

        percentage:
            Math.round(
                (completed / total) * 100
            )

    };

}


// ==========================================
// PROGRESS AIR
// ==========================================

function getWaterInsight() {

    const data =
        getInsightWaterData();


    const target =
        getInsightWaterTarget();


    const consumed =
        Number(data.consumed) || 0;


    let percentage =
        Math.round(
            (consumed / target) * 100
        );


    if (percentage > 100) {
        percentage = 100;
    }


    return {

        consumed: consumed,

        target: target,

        percentage: percentage

    };

}


// ==========================================
// PROGRESS HABIT
// ==========================================

function getHabitInsight() {

    const data =
        getInsightHabitData();


    const today =
        getInsightToday();


    const habits =
        Array.isArray(data.habits)
            ? data.habits
            : [];


    const history =
        data.history || {};


    const completed =
        Array.isArray(history[today])
            ? history[today]
            : [];


    const total =
        habits.length;


    let percentage = 0;


    if (total > 0) {

        percentage =
            Math.round(
                (completed.length / total) * 100
            );

    }


    return {

        completed:
            completed.length,

        total:
            total,

        percentage:
            percentage

    };

}


// ==========================================
// INSIGHT PERSONAL
// ==========================================

function generateNutriCareInsights() {

    const profile =
        getProfile();


    const water =
        getWaterInsight();


    const sleep =
        getInsightSleepData();


    const habits =
        getHabitInsight();


    const profileCompletion =
        getProfileCompletion();


    const pantry =
        getInsightPantryData();


    const shopping =
        getInsightShoppingData();


    const insights = [];


    // ======================================
    // PROFIL
    // ======================================

    if (
        profileCompletion.percentage < 100
    ) {

        insights.push({

            icon: "👤",

            title:
                "Lengkapi profilmu",

            description:
                "Data profil yang lebih lengkap membantu NutriCare memberikan informasi yang lebih sesuai dengan kebutuhanmu.",

            type: "profile"

        });

    } else {

        insights.push({

            icon: "✨",

            title:
                "Profil sudah lengkap",

            description:
                "Data profil utama sudah terisi. Kamu bisa terus memperbarui data jika ada perubahan.",

            type: "positive"

        });

    }


    // ======================================
    // AIR
    // ======================================

    if (water.consumed === 0) {

        insights.push({

            icon: "💧",

            title:
                "Belum ada catatan cairan hari ini",

            description:
                "Kalau kamu sudah minum, catat jumlahnya di Water Tracker agar progress harianmu ikut diperbarui.",

            type: "water"

        });

    } else if (
        water.percentage < 50
    ) {

        insights.push({

            icon: "💧",

            title:
                "Progress cairan masih berjalan",

            description:
                "Saat ini tercatat " +
                water.consumed +
                " ml dari target estimasi aplikasi " +
                water.target +
                " ml.",

            type: "water"

        });

    } else {

        insights.push({

            icon: "💧",

            title:
                "Progress cairan cukup baik",

            description:
                "Kamu sudah mencatat " +
                water.consumed +
                " ml hari ini. Tetap minum secara teratur sesuai kebutuhan tubuh.",

            type: "positive"

        });

    }


    // ======================================
    // TIDUR
    // ======================================

    if (sleep && sleep.duration) {

        const duration =
            Number(sleep.duration);


        if (duration > 0) {

            insights.push({

                icon: "😴",

                title:
                    "Catatan tidur hari ini tersedia",

                description:
                    "Durasi tidur yang tercatat adalah " +
                    formatInsightDuration(duration) +
                    ". Menjaga jadwal tidur yang cukup dan teratur dapat membantu pemulihan tubuh.",

                type: "sleep"

            });

        }

    } else {

        insights.push({

            icon: "😴",

            title:
                "Belum ada catatan tidur",

            description:
                "Catat waktu tidur dan bangun di Sleep Tracker agar NutriCare bisa membantu melihat pola istirahatmu.",

            type: "sleep"

        });

    }


    // ======================================
    // HABIT
    // ======================================

    if (habits.total === 0) {

        insights.push({

            icon: "🌱",

            title:
                "Mulai membangun kebiasaan",

            description:
                "Gunakan Habit & Progress untuk mencatat kebiasaan sehat yang ingin kamu pantau.",

            type: "habit"

        });

    } else if (
        habits.percentage === 100
    ) {

        insights.push({

            icon: "🌟",

            title:
                "Semua kebiasaan hari ini selesai",

            description:
                "Kamu sudah menyelesaikan semua kebiasaan yang tercatat hari ini. Pertahankan konsistensinya.",

            type: "positive"

        });

    } else {

        insights.push({

            icon: "🌱",

            title:
                "Progress kebiasaan",

            description:
                habits.completed +
                " dari " +
                habits.total +
                " kebiasaan hari ini sudah selesai.",

            type: "habit"

        });

    }


    // ======================================
    // PANTRY
    // ======================================

    const lowStock =
        pantry.filter(function(item) {

            return Number(item.quantity) <= 1;

        });


    if (lowStock.length > 0) {

        insights.push({

            icon: "🧺",

            title:
                "Ada stok Pantry yang hampir habis",

            description:
                lowStock.length +
                " bahan memiliki stok yang perlu diperhatikan. Kamu bisa memeriksanya di Pantry atau memasukkannya ke Shopping List.",

            type: "pantry"

        });

    }


    // ======================================
    // SHOPPING
    // ======================================

    const remainingShopping =
        shopping.filter(function(item) {

            return !item.purchased;

        });


    if (
        remainingShopping.length > 0
    ) {

        insights.push({

            icon: "🛒",

            title:
                "Masih ada daftar belanja",

            description:
                remainingShopping.length +
                " item masih tercatat sebagai belum dibeli di Shopping List.",

            type: "shopping"

        });

    }


    return insights.slice(0, 6);

}


// ==========================================
// FORMAT DURASI TIDUR
// ==========================================

function formatInsightDuration(minutes) {

    const totalMinutes =
        Number(minutes);


    if (!totalMinutes || totalMinutes <= 0) {

        return "belum tersedia";

    }


    const hours =
        Math.floor(
            totalMinutes / 60
        );


    const remainingMinutes =
        totalMinutes % 60;


    if (remainingMinutes === 0) {

        return hours + " jam";

    }


    return (
        hours +
        " jam " +
        remainingMinutes +
        " menit"
    );

}


// ==========================================
// SIMPAN INSIGHT
// ==========================================

function saveNutriCareInsights(insights) {

    NutriStorage.save(
        INSIGHT_STORAGE_KEY,
        {

            date:
                getInsightToday(),

            insights:
                insights

        }
    );

}


// ==========================================
// RENDER INSIGHT
// ==========================================

function renderNutriCareInsights() {

    const container =
        document.getElementById(
            "insightList"
        );


    if (!container) {
        return;
    }


    const insights =
        generateNutriCareInsights();


    saveNutriCareInsights(
        insights
    );


    if (insights.length === 0) {

        container.innerHTML = `

            <div class="insight-empty">

                <div class="insight-empty-icon">
                    🌿
                </div>

                <h3>
                    Belum ada insight
                </h3>

                <p>
                    Tambahkan beberapa data
                    di fitur NutriCare agar
                    insight personal dapat
                    ditampilkan.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        insights.map(function(insight) {

            return `

                <article
                    class="insight-card"
                >

                    <div
                        class="insight-icon"
                    >
                        ${insight.icon}
                    </div>


                    <div
                        class="insight-content"
                    >

                        <h3>
                            ${insight.title}
                        </h3>

                        <p>
                            ${insight.description}
                        </p>

                    </div>

                </article>

            `;

        }).join("");

}


// ==========================================
// RENDER RINGKASAN
// ==========================================

function renderInsightSummary() {

    const profile =
        getProfileCompletion();


    const water =
        getWaterInsight();


    const habits =
        getHabitInsight();


    const profileElement =
        document.getElementById(
            "insightProfile"
        );


    const waterElement =
        document.getElementById(
            "insightWater"
        );


    const habitElement =
        document.getElementById(
            "insightHabit"
        );


    if (profileElement) {

        profileElement.textContent =
            profile.percentage + "%";

    }


    if (waterElement) {

        waterElement.textContent =
            water.percentage + "%";

    }


    if (habitElement) {

        habitElement.textContent =
            habits.percentage + "%";

    }

}


// ==========================================
// REFRESH
// ==========================================

function refreshNutriCareInsights() {

    renderInsightSummary();

    renderNutriCareInsights();

}


// ==========================================
// SAAT HALAMAN DIBUKA
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        refreshNutriCareInsights();

    }
);