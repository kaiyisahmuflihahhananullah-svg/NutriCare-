// ==========================================
// NutriCare AI - Water Tracker
// ==========================================

const WATER_STORAGE_KEY = "nutricare_water";


// ==========================================
// Ambil data hari ini
// ==========================================

function getTodayWaterData() {

    const today =
        new Date().toISOString().split("T")[0];

    const saved =
        NutriStorage.get(WATER_STORAGE_KEY, null);

    if (!saved || saved.date !== today) {

        return {
            date: today,
            consumed: 0
        };

    }

    return saved;
}


// ==========================================
// Simpan data
// ==========================================

function saveWaterData(data) {

    NutriStorage.save(
        WATER_STORAGE_KEY,
        data
    );

}


// ==========================================
// Hitung target cairan
// ==========================================

function getWaterTarget() {

    const profile = getProfile();

    if (
        profile &&
        profile.weight
    ) {

        return Math.round(
            profile.weight * 30
        );

    }

    return 2000;
}


// ==========================================
// Tambah air
// ==========================================

function addWater(amount) {

    const data =
        getTodayWaterData();

    const target =
        getWaterTarget();

    data.consumed += amount;

    if (data.consumed > target) {
        data.consumed = target;
    }

    saveWaterData(data);

    renderWaterTracker();

}


// ==========================================
// Reset hari ini
// ==========================================

function resetWater() {

    const today =
        new Date().toISOString().split("T")[0];

    const data = {
        date: today,
        consumed: 0
    };

    saveWaterData(data);

    renderWaterTracker();

}


// ==========================================
// Tampilkan tracker
// ==========================================

function renderWaterTracker() {

    const data =
        getTodayWaterData();

    const target =
        getWaterTarget();

    const consumed =
        data.consumed;

    let percentage =
        Math.round(
            (consumed / target) * 100
        );

    if (percentage > 100) {
        percentage = 100;
    }


    const consumedElement =
        document.getElementById(
            "waterConsumed"
        );

    const targetElement =
        document.getElementById(
            "waterTarget"
        );

    const progressElement =
        document.getElementById(
            "waterProgress"
        );

    const percentageElement =
        document.getElementById(
            "waterPercentage"
        );


    if (consumedElement) {

        consumedElement.textContent =
            consumed + " ml";

    }


    if (targetElement) {

        targetElement.textContent =
            target + " ml";

    }


    if (progressElement) {

        progressElement.style.width =
            percentage + "%";

    }


    if (percentageElement) {

        percentageElement.textContent =
            percentage + "%";

    }

}


// ==========================================
// Jalankan saat halaman dibuka
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderWaterTracker();

    }
);