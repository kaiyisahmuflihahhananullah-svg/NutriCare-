
// ==========================================
// NUTRICARE AI — AZKADIA CHAT SYSTEM
// Conversation Memory + Local Chat History
// ==========================================

const NUTRICARE_API_URL = "http://localhost:3000/api/chat";
const CHAT_STORAGE_KEY = "nutricare_azkadia_chats";
const ACTIVE_CHAT_KEY = "nutricare_azkadia_active_chat";

let chatHistory = [];
let currentChatId = null;

const AZKADIA_WELCOME = `Halo! 👋

Aku Azkadia, asisten AI dari NutriCare.

Senang bisa menemanimu di sini!

Kamu bisa bertanya tentang apa saja, mulai dari nutrisi,
makanan, pendidikan, teknologi, pengetahuan umum,
sampai hal-hal random sehari-hari.

Nutrisi adalah keahlian utamaku, tetapi aku juga
siap membantu berbagai pertanyaan lainnya.

Yuk, mulai ngobrol! 🌱`;


// ==========================================
// STORAGE SYSTEM
// ==========================================

function getSavedChats() {
    try {
        const saved = localStorage.getItem(CHAT_STORAGE_KEY);

        if (!saved) return [];

        const chats = JSON.parse(saved);

        return Array.isArray(chats) ? chats : [];
    } catch (error) {
        console.error("Gagal membaca riwayat:", error);
        return [];
    }
}

function saveChats(chats) {
    try {
        localStorage.setItem(
            CHAT_STORAGE_KEY,
            JSON.stringify(chats)
        );

        return true;
    } catch (error) {
        console.error("Gagal menyimpan riwayat:", error);
        return false;
    }
}

function createChatId() {
    if (window.crypto?.randomUUID) {
        return window.crypto.randomUUID();
    }

    return `chat-${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 9)}`;
}


// ==========================================
// CHAT MANAGEMENT
// ==========================================

function createNewConversation() {
    const now = new Date().toISOString();

    const newChat = {
        id: createChatId(),
        title: "Percakapan baru",
        createdAt: now,
        updatedAt: now,
        messages: []
    };

    currentChatId = newChat.id;
    chatHistory = [];

    return newChat;
}

function getCurrentConversation() {
    if (!currentChatId) return null;

    return getSavedChats().find(
        chat => chat.id === currentChatId
    ) || null;
}

function saveCurrentConversation() {
    if (!currentChatId || chatHistory.length === 0) {
        return;
    }

    const chats = getSavedChats();

    const chatIndex = chats.findIndex(
        chat => chat.id === currentChatId
    );

    const existingChat = chatIndex !== -1
        ? chats[chatIndex]
        : null;

    const firstUserMessage = chatHistory.find(
        message => message.role === "user"
    );

    const title = firstUserMessage
        ? firstUserMessage.content
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 45) +
            (firstUserMessage.content.length > 45 ? "..." : "")
        : "Percakapan baru";

    const updatedChat = {
        id: currentChatId,
        title,
        createdAt: existingChat?.createdAt ||
            new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [...chatHistory]
    };

    if (chatIndex !== -1) {
        chats.splice(chatIndex, 1);
    }

    chats.unshift(updatedChat);

    if (!saveChats(chats)) {
        console.error("Percakapan gagal disimpan.");
    }

    renderChatHistory();
}


// ==========================================
// MESSAGE DISPLAY
// ==========================================

function addChatMessage(message, sender) {
    const chatMessages = document.getElementById("chatMessages");

    if (!chatMessages) return null;

    const isUser = sender === "user";

    const messageElement = document.createElement("div");
    messageElement.className = isUser
        ? "chat-message user"
        : "chat-message";

    const avatar = document.createElement("div");
    avatar.className = "chat-avatar";
    avatar.textContent = isUser ? "👤" : "🌱";

    const bubble = document.createElement("div");
    bubble.className = "chat-bubble";
    bubble.textContent = message;

    messageElement.appendChild(avatar);
    messageElement.appendChild(bubble);

    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    return bubble;
}

function showWelcomeMessage() {
    const chatMessages = document.getElementById("chatMessages");

    if (!chatMessages) return;

    chatMessages.innerHTML = "";
    addChatMessage(AZKADIA_WELCOME, "ai");
}

function renderConversation(messages) {
    const chatMessages = document.getElementById("chatMessages");

    if (!chatMessages) return;

    chatMessages.innerHTML = "";

    messages.forEach(message => {
        addChatMessage(
            message.content,
            message.role === "user" ? "user" : "ai"
        );
    });

    chatMessages.scrollTop = chatMessages.scrollHeight;
}


// ==========================================
// OPEN CONVERSATION
// ==========================================

function openConversation(chatId) {
    const selectedChat = getSavedChats().find(
        chat => chat.id === chatId
    );

    if (!selectedChat) return;

    currentChatId = selectedChat.id;
    chatHistory = [...(selectedChat.messages || [])];

    sessionStorage.setItem(ACTIVE_CHAT_KEY, currentChatId);

    renderConversation(chatHistory);
    renderChatHistory();

    const input = document.getElementById("chatInput");

    if (input) {
        input.value = "";
        input.disabled = false;
        input.focus();
    }
}


// ==========================================
// SEND MESSAGE
// ==========================================

async function sendChatMessage() {
    const input = document.getElementById("chatInput");
    const sendButton = document.getElementById("sendChatButton");

    if (!input || input.disabled) return;

    const message = input.value.trim();

    if (!message) return;

    if (message.length > 4000) {
        alert("Pesan terlalu panjang. Maksimal 4.000 karakter.");
        return;
    }

    const isNewConversation = !currentChatId;

    if (isNewConversation) {
        createNewConversation();
    }

    addChatMessage(message, "user");

   input.value = "";
input.style.height = "40px";
input.style.overflowY = "hidden";
input.disabled = true;

    if (sendButton) {
        sendButton.disabled = true;
    }

    chatHistory.push({
        role: "user",
        content: message
    });

    const loadingBubble = addChatMessage(
        "Azkadia sedang menyiapkan jawaban...",
        "ai"
    );

    try {
        const recentMessages = chatHistory.slice(-12);

        const response = await fetch(NUTRICARE_API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                messages: recentMessages
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.error || `Terjadi kesalahan (${response.status}).`
            );
        }

        if (!data.answer) {
            throw new Error("AI belum memberikan jawaban.");
        }

        loadingBubble.textContent = data.answer;

        chatHistory.push({
            role: "assistant",
            content: data.answer
        });

        saveCurrentConversation();

        sessionStorage.setItem(ACTIVE_CHAT_KEY, currentChatId);

    } catch (error) {
        console.error("Azkadia Chat:", error);

        chatHistory.pop();

        const messageElement = loadingBubble?.closest(".chat-message");

        if (messageElement) {
            messageElement.remove();
        }

        const errorMessage = error.message.includes("Failed to fetch")
            ? "Aku belum bisa terhubung ke server. Pastikan server NutriCare AI sedang berjalan."
            : `Maaf, ${error.message}`;

        addChatMessage(errorMessage, "ai");

        // Jangan menyimpan percakapan kosong akibat kegagalan API.
        if (isNewConversation && chatHistory.length === 0) {
            currentChatId = null;
            sessionStorage.removeItem(ACTIVE_CHAT_KEY);
        }

        renderChatHistory();

    } finally {
        input.disabled = false;

        if (sendButton) {
            sendButton.disabled = false;
        }

        input.focus();
    }
}


// ==========================================
// NEW CHAT
// ==========================================

function startNewChat() {
    const input = document.getElementById("chatInput");

    if (input?.disabled) return;

    currentChatId = null;
    chatHistory = [];

    sessionStorage.removeItem(ACTIVE_CHAT_KEY);

    showWelcomeMessage();
    renderChatHistory();

    if (input) {
       input.value = "";
input.style.height = "40px";
input.style.overflowY = "hidden";

}

}

// ==========================================
// DELETE CONVERSATION
// ==========================================

function deleteConversation(chatId) {
    const confirmation = confirm(
        "Hapus percakapan ini secara permanen dari riwayat?"
    );

    if (!confirmation) return;

    const chats = getSavedChats();

    const updatedChats = chats.filter(
        chat => chat.id !== chatId
    );

    if (!saveChats(updatedChats)) {
        alert("Percakapan gagal dihapus.");
        return;
    }

    if (currentChatId === chatId) {
        currentChatId = null;
        chatHistory = [];

        sessionStorage.removeItem(ACTIVE_CHAT_KEY);

        showWelcomeMessage();
    }

    renderChatHistory();
}


// ==========================================
// CHAT HISTORY DISPLAY
// ==========================================

function renderChatHistory() {
    const historyList = document.getElementById("chatHistoryList");

    if (!historyList) return;

    const chats = getSavedChats();

    const searchInput = document.getElementById("chatHistorySearch");
    const searchTerm = searchInput?.value.trim().toLowerCase() || "";

    const filteredChats = chats.filter(chat => {
        const title = (chat.title || "").toLowerCase();

        const messageContent = (chat.messages || [])
            .map(message => message.content || "")
            .join(" ")
            .toLowerCase();

        return title.includes(searchTerm) ||
            messageContent.includes(searchTerm);
    });

    historyList.innerHTML = "";

    if (chats.length === 0) {
        const emptyMessage = document.createElement("p");

        emptyMessage.className = "chat-history-empty";
        emptyMessage.textContent = "Belum ada percakapan tersimpan.";

        historyList.appendChild(emptyMessage);
        return;
    }

    if (filteredChats.length === 0) {
        const emptyMessage = document.createElement("p");

        emptyMessage.className = "chat-history-empty";
        emptyMessage.textContent = "Tidak ada percakapan yang cocok.";

        historyList.appendChild(emptyMessage);
        return;
    }

    const groups = {
        today: [],
        yesterday: [],
        recent: [],
        older: []
    };

    const now = new Date();

    const today = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate()
    );

    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    filteredChats.forEach(chat => {
        const chatDate = new Date(
            chat.updatedAt || chat.createdAt
        );

        if (Number.isNaN(chatDate.getTime())) {
            groups.older.push(chat);
            return;
        }

        const date = new Date(
            chatDate.getFullYear(),
            chatDate.getMonth(),
            chatDate.getDate()
        );

        if (date.getTime() === today.getTime()) {
            groups.today.push(chat);
        } else if (date.getTime() === yesterday.getTime()) {
            groups.yesterday.push(chat);
        } else if (
            date >= new Date(today.getTime() - 6 * 86400000)
        ) {
            groups.recent.push(chat);
        } else {
            groups.older.push(chat);
        }
    });

    const groupLabels = [
        { key: "today", label: "HARI INI" },
        { key: "yesterday", label: "KEMARIN" },
        { key: "recent", label: "7 HARI TERAKHIR" },
        { key: "older", label: "SEBELUMNYA" }
    ];

    groupLabels.forEach(group => {
        const groupChats = groups[group.key];

        if (groupChats.length === 0) return;

        const heading = document.createElement("div");
        heading.className = "chat-history-group-title";
        heading.textContent = group.label;

        historyList.appendChild(heading);

        groupChats.forEach(chat => {
            const item = document.createElement("div");
            item.className = "chat-history-item";

            if (chat.id === currentChatId) {
                item.classList.add("is-active");
            }

            const openButton = document.createElement("button");

            openButton.type = "button";
            openButton.className = "chat-history-title";
            openButton.textContent = chat.title || "Percakapan baru";
            openButton.title = chat.title || "Percakapan baru";

            openButton.addEventListener("click", () => {
                openConversation(chat.id);
            });

            const deleteButton = document.createElement("button");

            deleteButton.type = "button";
            deleteButton.className = "chat-history-delete";
            deleteButton.textContent = "⋯";
            deleteButton.title = "Hapus percakapan";
            deleteButton.setAttribute(
                "aria-label",
                "Hapus percakapan"
            );

            deleteButton.addEventListener("click", () => {
                deleteConversation(chat.id);
            });

            item.appendChild(openButton);
            item.appendChild(deleteButton);

            historyList.appendChild(item);
        });
    });
}


// ==========================================
// INITIALIZE
// ==========================================

function initializeAzkadiaChat() {
    // Bersihkan percakapan kosong dari percobaan sebelumnya.
    const chats = getSavedChats();

    const validChats = chats.filter(
        chat => Array.isArray(chat.messages) &&
            chat.messages.length > 0
    );

    if (validChats.length !== chats.length) {
        saveChats(validChats);
    }

    const lastChatId = sessionStorage.getItem(ACTIVE_CHAT_KEY);

    const lastChat = validChats.find(
        chat => chat.id === lastChatId
    );

    if (lastChat) {
        openConversation(lastChat.id);
    } else {
        currentChatId = null;
        chatHistory = [];

        sessionStorage.removeItem(ACTIVE_CHAT_KEY);

        showWelcomeMessage();
    }

    renderChatHistory();
}


// Simpan ID percakapan aktif ketika halaman ditinggalkan.
window.addEventListener("beforeunload", () => {
    if (currentChatId) {
        sessionStorage.setItem(ACTIVE_CHAT_KEY, currentChatId);
    } else {
        sessionStorage.removeItem(ACTIVE_CHAT_KEY);
    }
});


// Jalankan sistem chat.
initializeAzkadiaChat();
