// ==========================================
// NutriCare AI - Habit & Progress
// ==========================================

const HABIT_STORAGE_KEY = "nutricare_habits";


// ==========================================
// DAFTAR KEBIASAAN DEFAULT
// ==========================================

const defaultHabits = [

    {
        id: "water",
        icon: "💧",
        title: "Menjaga kecukupan cairan",
        description: "Minum secara teratur sesuai kebutuhan tubuh."
    },

    {
        id: "balancedMeal",
        icon: "🍽️",
        title: "Makan dengan beragam",
        description: "Pilih variasi makanan dari berbagai sumber."
    },

    {
        id: "activity",
        icon: "🏃",
        title: "Melakukan aktivitas fisik",
        description: "Lakukan aktivitas yang nyaman dan sesuai kemampuan."
    },

    {
        id: "sleep",
        icon: "😴",
        title: "Menjaga waktu tidur",
        description: "Usahakan memiliki waktu tidur dan bangun yang teratur."
    },

    {
        id: "rest",
        icon: "🌿",
        title: "Memberikan waktu untuk istirahat",
        description: "Luangkan waktu untuk beristirahat dan memulihkan diri."
    }

];


// ==========================================
// TANGGAL HARI INI
// ==========================================

function getTodayDate() {

    return new Date()
        .toISOString()
        .split("T")[0];

}


// ==========================================
// DATA HABIT
// ==========================================

function getHabitData() {

    const saved =
        NutriStorage.get(
            HABIT_STORAGE_KEY,
            null
        );


    if (!saved) {

        return {
            habits: defaultHabits,
            history: {}
        };

    }


    if (!saved.habits) {
        saved.habits = defaultHabits;
    }


    if (!saved.history) {
        saved.history = {};
    }


    return saved;

}


// ==========================================
// SIMPAN DATA
// ==========================================

function saveHabitData(data) {

    NutriStorage.save(
        HABIT_STORAGE_KEY,
        data
    );

}


// ==========================================
// HABIT YANG SELESAI HARI INI
// ==========================================

function getTodayCompletedHabits() {

    const data =
        getHabitData();

    const today =
        getTodayDate();


    if (!data.history[today]) {

        data.history[today] = [];

    }


    return data.history[today];

}


// ==========================================
// TOGGLE HABIT
// ==========================================

function toggleHabit(habitId) {

    const data =
        getHabitData();

    const today =
        getTodayDate();


    if (!data.history[today]) {

        data.history[today] = [];

    }


    const completed =
        data.history[today];


    const index =
        completed.indexOf(habitId);


    if (index === -1) {

        completed.push(habitId);

    } else {

        completed.splice(
            index,
            1
        );

    }


    saveHabitData(data);

    renderHabitTracker();

}


// ==========================================
// PROGRESS HARI INI
// ==========================================

function getTodayProgress() {

    const data =
        getHabitData();

    const completed =
        getTodayCompletedHabits();


    const total =
        data.habits.length;


    if (total === 0) {

        return {
            completed: 0,
            total: 0,
            percentage: 0
        };

    }


    const percentage =
        Math.round(
            (completed.length / total) * 100
        );


    return {

        completed:
            completed.length,

        total:
            total,

        percentage:
            percentage

    };

}


// ==========================================
// PROGRESS 7 HARI
// ==========================================

function getLastSevenDays() {

    const data =
        getHabitData();


    const days = [];


    for (
        let i = 6;
        i >= 0;
        i--
    ) {

        const date =
            new Date();


        date.setDate(
            date.getDate() - i
        );


        const dateString =
            date.toISOString()
                .split("T")[0];


        const completed =
            data.history[dateString] || [];


        days.push({

            date:
                dateString,

            completed:
                completed.length,

            total:
                data.habits.length

        });

    }


    return days;

}


// ==========================================
// FORMAT TANGGAL
// ==========================================

function formatShortDate(dateString) {

    const date =
        new Date(
            dateString + "T00:00:00"
        );


    return date.toLocaleDateString(
        "id-ID",
        {
            day: "numeric",
            month: "short"
        }
    );

}


// ==========================================
// RENDER HABIT LIST
// ==========================================

function renderHabitList() {

    const container =
        document.getElementById(
            "habitList"
        );


    if (!container) {
        return;
    }


    const data =
        getHabitData();


    const completed =
        getTodayCompletedHabits();


    container.innerHTML =
        data.habits
            .map(function(habit) {

                const isCompleted =
                    completed.includes(
                        habit.id
                    );


                return `

                    <div
                        class="habit-item
                        ${isCompleted ? "completed" : ""}"
                        onclick="toggleHabit('${habit.id}')"
                    >

                        <div class="habit-check">

                            ${
                                isCompleted
                                ? "✓"
                                : ""
                            }

                        </div>


                        <div class="habit-icon">

                            ${habit.icon}

                        </div>


                        <div class="habit-content">

                            <h3>
                                ${habit.title}
                            </h3>

                            <p>
                                ${habit.description}
                            </p>

                        </div>


                    </div>

                `;

            })
            .join("");

}


// ==========================================
// RENDER PROGRESS
// ==========================================

function renderTodayProgress() {

    const progress =
        getTodayProgress();


    const percentageElement =
        document.getElementById(
            "habitPercentage"
        );


    const countElement =
        document.getElementById(
            "habitCount"
        );


    const progressBar =
        document.getElementById(
            "habitProgressBar"
        );


    if (percentageElement) {

        percentageElement.textContent =
            progress.percentage + "%";

    }


    if (countElement) {

        countElement.textContent =
            progress.completed +
            " dari " +
            progress.total +
            " kebiasaan selesai";

    }


    if (progressBar) {

        progressBar.style.width =
            progress.percentage + "%";

    }

}


// ==========================================
// RENDER 7 HARI
// ==========================================

function renderSevenDayProgress() {

    const container =
        document.getElementById(
            "sevenDayProgress"
        );


    if (!container) {
        return;
    }


    const days =
        getLastSevenDays();


    container.innerHTML =
        days
            .map(function(day) {

                let percentage = 0;


                if (day.total > 0) {

                    percentage =
                        Math.round(
                            (day.completed /
                            day.total) * 100
                        );

                }


                return `

                    <div class="day-progress">

                        <div class="day-info">

                            <span>
                                ${formatShortDate(day.date)}
                            </span>

                            <strong>
                                ${day.completed}/${day.total}
                            </strong>

                        </div>


                        <div class="day-bar">

                            <div
                                class="day-bar-fill"
                                style="width: ${percentage}%"
                            ></div>

                        </div>

                    </div>

                `;

            })
            .join("");

}


// ==========================================
// RENDER SEMUA
// ==========================================

function renderHabitTracker() {

    renderHabitList();

    renderTodayProgress();

    renderSevenDayProgress();

}


// ==========================================
// RESET HARI INI
// ==========================================

function resetTodayHabits() {

    const confirmed =
        confirm(
            "Reset semua progress kebiasaan hari ini?"
        );


    if (!confirmed) {
        return;
    }


    const data =
        getHabitData();


    const today =
        getTodayDate();


    data.history[today] = [];


    saveHabitData(data);


    renderHabitTracker();

}


// ==========================================
// LOAD
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderHabitTracker();

    }
);