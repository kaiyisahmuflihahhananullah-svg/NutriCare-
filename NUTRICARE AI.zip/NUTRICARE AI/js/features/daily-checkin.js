// ==========================================
// NutriCare AI - Daily Check-in
// ==========================================

const CHECKIN_STORAGE_KEY = "nutricare_checkins";


// ==========================================
// TANGGAL HARI INI
// ==========================================

function getCheckinToday() {

    return new Date()
        .toISOString()
        .split("T")[0];

}


// ==========================================
// AMBIL SEMUA DATA CHECK-IN
// ==========================================

function getCheckinData() {

    const data =
        NutriStorage.get(
            CHECKIN_STORAGE_KEY,
            {}
        );

    return data || {};

}


// ==========================================
// SIMPAN SEMUA DATA
// ==========================================

function saveCheckinData(data) {

    NutriStorage.save(
        CHECKIN_STORAGE_KEY,
        data
    );

}


// ==========================================
// AMBIL CHECK-IN HARI INI
// ==========================================

function getTodayCheckin() {

    const data =
        getCheckinData();

    const today =
        getCheckinToday();


    return data[today] || null;

}


// ==========================================
// PILIH NILAI
// ==========================================

function selectCheckinValue(
    group,
    value
) {

    const buttons =
        document.querySelectorAll(
            `[data-group="${group}"]`
        );


    buttons.forEach(
        function(button) {

            button.classList.remove(
                "selected"
            );

        }
    );


    const selected =
        document.querySelector(
            `[data-group="${group}"][data-value="${value}"]`
        );


    if (selected) {

        selected.classList.add(
            "selected"
        );

    }

}


// ==========================================
// AMBIL NILAI YANG DIPILIH
// ==========================================

function getSelectedCheckinValue(
    group
) {

    const selected =
        document.querySelector(
            `[data-group="${group}"].selected`
        );


    if (!selected) {
        return null;
    }


    return Number(
        selected.dataset.value
    );

}


// ==========================================
// SIMPAN CHECK-IN
// ==========================================

function saveDailyCheckin() {

    const mood =
        getSelectedCheckinValue(
            "mood"
        );


    const energy =
        getSelectedCheckinValue(
            "energy"
        );


    const sleepQuality =
        getSelectedCheckinValue(
            "sleep"
        );


    const stress =
        getSelectedCheckinValue(
            "stress"
        );


    const noteElement =
        document.getElementById(
            "checkinNote"
        );


    const note =
        noteElement
            ? noteElement.value.trim()
            : "";


    if (
        !mood ||
        !energy ||
        !sleepQuality ||
        !stress
    ) {

        alert(
            "Lengkapi semua pilihan kondisi hari ini terlebih dahulu."
        );

        return;

    }


    const data =
        getCheckinData();


    const today =
        getCheckinToday();


    data[today] = {

        date:
            today,

        mood:
            mood,

        energy:
            energy,

        sleepQuality:
            sleepQuality,

        stress:
            stress,

        note:
            note,

        updatedAt:
            new Date().toISOString()

    };


    saveCheckinData(
        data
    );


    alert(
        "Daily Check-in berhasil disimpan 💚"
    );


    renderCheckinSummary();

}


// ==========================================
// LOAD CHECK-IN
// ==========================================

function loadTodayCheckin() {

    const checkin =
        getTodayCheckin();


    if (!checkin) {
        return;
    }


    selectCheckinValue(
        "mood",
        checkin.mood
    );


    selectCheckinValue(
        "energy",
        checkin.energy
    );


    selectCheckinValue(
        "sleep",
        checkin.sleepQuality
    );


    selectCheckinValue(
        "stress",
        checkin.stress
    );


    const noteElement =
        document.getElementById(
            "checkinNote"
        );


    if (noteElement) {

        noteElement.value =
            checkin.note || "";

    }


    const saveButton =
        document.getElementById(
            "saveCheckinButton"
        );


    if (saveButton) {

        saveButton.textContent =
            "✓ Perbarui Check-in";

    }

}


// ==========================================
// LABEL NILAI
// ==========================================

function getMoodLabel(value) {

    const labels = {

        1: "Kurang baik",

        2: "Sedikit kurang baik",

        3: "Biasa saja",

        4: "Cukup baik",

        5: "Sangat baik"

    };


    return labels[value] || "-";

}


function getEnergyLabel(value) {

    const labels = {

        1: "Sangat rendah",

        2: "Rendah",

        3: "Sedang",

        4: "Cukup tinggi",

        5: "Sangat tinggi"

    };


    return labels[value] || "-";

}


function getSleepLabel(value) {

    const labels = {

        1: "Kurang nyaman",

        2: "Kurang baik",

        3: "Cukup",

        4: "Baik",

        5: "Sangat baik"

    };


    return labels[value] || "-";

}


function getStressLabel(value) {

    const labels = {

        1: "Sangat rendah",

        2: "Rendah",

        3: "Sedang",

        4: "Cukup tinggi",

        5: "Tinggi"

    };


    return labels[value] || "-";

}


// ==========================================
// RENDER RINGKASAN
// ==========================================

function renderCheckinSummary() {

    const container =
        document.getElementById(
            "checkinSummary"
        );


    if (!container) {
        return;
    }


    const checkin =
        getTodayCheckin();


    if (!checkin) {

        container.innerHTML = `

            <div class="summary-empty">

                <div class="summary-empty-icon">
                    🌿
                </div>

                <h3>
                    Belum ada check-in hari ini
                </h3>

                <p>
                    Isi Daily Check-in untuk
                    mencatat kondisi harianmu.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML = `

        <div class="summary-item">

            <span>
                😊 Mood
            </span>

            <strong>
                ${getMoodLabel(checkin.mood)}
            </strong>

        </div>


        <div class="summary-item">

            <span>
                ⚡ Energi
            </span>

            <strong>
                ${getEnergyLabel(checkin.energy)}
            </strong>

        </div>


        <div class="summary-item">

            <span>
                😴 Kualitas tidur
            </span>

            <strong>
                ${getSleepLabel(checkin.sleepQuality)}
            </strong>

        </div>


        <div class="summary-item">

            <span>
                🧠 Stres
            </span>

            <strong>
                ${getStressLabel(checkin.stress)}
            </strong>

        </div>


        ${
            checkin.note
                ? `
                    <div class="summary-note">

                        <strong>
                            📝 Catatan
                        </strong>

                        <p>
                            ${escapeCheckinText(
                                checkin.note
                            )}
                        </p>

                    </div>
                `
                : ""
        }

    `;

}


// ==========================================
// RIWAYAT 7 HARI
// ==========================================

function getLastSevenCheckins() {

    const data =
        getCheckinData();


    const result = [];


    for (
        let i = 6;
        i >= 0;
        i--
    ) {

        const date =
            new Date();


        date.setDate(
            date.getDate() - i
        );


        const dateString =
            date
                .toISOString()
                .split("T")[0];


        result.push({

            date:
                dateString,

            checkin:
                data[dateString] || null

        });

    }


    return result;

}


// ==========================================
// RENDER RIWAYAT
// ==========================================

function renderCheckinHistory() {

    const container =
        document.getElementById(
            "checkinHistory"
        );


    if (!container) {
        return;
    }


    const history =
        getLastSevenCheckins();


    container.innerHTML =
        history.map(
            function(day) {

                const date =
                    new Date(
                        day.date +
                        "T00:00:00"
                    );


                const dateLabel =
                    date.toLocaleDateString(
                        "id-ID",
                        {
                            day: "numeric",
                            month: "short"
                        }
                    );


                if (!day.checkin) {

                    return `

                        <div
                            class="history-day"
                        >

                            <span>
                                ${dateLabel}
                            </span>

                            <strong>
                                —
                            </strong>

                        </div>

                    `;

                }


                return `

                    <div
                        class="history-day completed"
                    >

                        <span>
                            ${dateLabel}
                        </span>

                        <strong>
                            ✓ Selesai
                        </strong>

                    </div>

                `;

            }
        ).join("");

}


// ==========================================
// HAPUS CHECK-IN HARI INI
// ==========================================

function resetTodayCheckin() {

    const confirmed =
        confirm(
            "Hapus check-in hari ini?"
        );


    if (!confirmed) {
        return;
    }


    const data =
        getCheckinData();


    const today =
        getCheckinToday();


    delete data[today];


    saveCheckinData(
        data
    );


    location.reload();

}


// ==========================================
// AMANKAN TEKS CATATAN
// ==========================================

function escapeCheckinText(text) {

    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


// ==========================================
// INIT
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadTodayCheckin();

        renderCheckinSummary();

        renderCheckinHistory();

    }
);