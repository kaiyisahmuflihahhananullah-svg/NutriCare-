// ==========================================
// NutriCare AI - Smart Shopping List
// ==========================================

const SHOPPING_STORAGE_KEY = "nutricare_shopping";


// ==========================================
// AMBIL DATA
// ==========================================

function getShoppingData() {

    const saved = NutriStorage.get(
        SHOPPING_STORAGE_KEY,
        []
    );

    if (!Array.isArray(saved)) {
        return [];
    }

    return saved;
}


// ==========================================
// SIMPAN DATA
// ==========================================

function saveShoppingData(data) {

    NutriStorage.save(
        SHOPPING_STORAGE_KEY,
        data
    );
}


// ==========================================
// TAMBAH ITEM
// ==========================================

function addShoppingItem() {

    const nameInput =
        document.getElementById("shoppingName");

    const quantityInput =
        document.getElementById("shoppingQuantity");

    const unitInput =
        document.getElementById("shoppingUnit");

    const categoryInput =
        document.getElementById("shoppingCategory");


    if (
        !nameInput ||
        !quantityInput ||
        !unitInput ||
        !categoryInput
    ) {

        alert(
            "Form Shopping List tidak ditemukan."
        );

        return;
    }


    const name =
        nameInput.value.trim();

    const quantity =
        Number(quantityInput.value);

    const unit =
        unitInput.value;

    const category =
        categoryInput.value;


    if (!name) {

        alert(
            "Masukkan nama bahan makanan terlebih dahulu."
        );

        nameInput.focus();

        return;
    }


    if (!quantity || quantity <= 0) {

        alert(
            "Masukkan jumlah yang valid."
        );

        quantityInput.focus();

        return;
    }


    const data =
        getShoppingData();


    data.push({

        id: Date.now(),

        name: name,

        quantity: quantity,

        unit: unit,

        category: category,

        purchased: false,

        createdAt:
            new Date().toISOString()

    });


    saveShoppingData(data);


    // Kosongkan form

    nameInput.value = "";

    quantityInput.value = "";


    // Tampilkan data terbaru

    renderShoppingList();

}


// ==========================================
// TANDAI SUDAH / BELUM DIBELI
// ==========================================

function toggleShoppingItem(id) {

    const data =
        getShoppingData();


    const item =
        data.find(function(item) {

            return String(item.id) === String(id);

        });


    if (!item) {

        alert(
            "Item tidak ditemukan."
        );

        return;
    }


    item.purchased =
        !item.purchased;


    saveShoppingData(data);


    renderShoppingList();

}


// ==========================================
// EDIT ITEM
// ==========================================

function editShoppingItem(id) {

    const data =
        getShoppingData();


    const item =
        data.find(function(item) {

            return String(item.id) === String(id);

        });


    if (!item) {

        alert(
            "Item tidak ditemukan."
        );

        return;
    }


    const newName =
        prompt(
            "Ubah nama bahan:",
            item.name
        );


    if (newName === null) {
        return;
    }


    const cleanName =
        newName.trim();


    if (!cleanName) {

        alert(
            "Nama bahan tidak boleh kosong."
        );

        return;
    }


    const newQuantity =
        prompt(
            "Ubah jumlah:",
            item.quantity
        );


    if (newQuantity === null) {
        return;
    }


    const quantity =
        Number(newQuantity);


    if (!quantity || quantity <= 0) {

        alert(
            "Jumlah harus lebih dari 0."
        );

        return;
    }


    const newUnit =
        prompt(
            "Ubah satuan:",
            item.unit
        );


    if (newUnit === null) {
        return;
    }


    const cleanUnit =
        newUnit.trim();


    if (!cleanUnit) {

        alert(
            "Satuan tidak boleh kosong."
        );

        return;
    }


    const newCategory =
        prompt(
            "Ubah kategori:",
            item.category
        );


    if (newCategory === null) {
        return;
    }


    const cleanCategory =
        newCategory.trim();


    if (!cleanCategory) {

        alert(
            "Kategori tidak boleh kosong."
        );

        return;
    }


    // Simpan perubahan

    item.name =
        cleanName;

    item.quantity =
        quantity;

    item.unit =
        cleanUnit;

    item.category =
        cleanCategory;


    saveShoppingData(data);


    renderShoppingList();

}


// ==========================================
// HAPUS ITEM
// ==========================================

function deleteShoppingItem(id) {

    const confirmed =
        confirm(
            "Hapus bahan ini dari daftar belanja?"
        );


    if (!confirmed) {
        return;
    }


    let data =
        getShoppingData();


    data =
        data.filter(function(item) {

            return String(item.id) !== String(id);

        });


    saveShoppingData(data);


    renderShoppingList();

}


// ==========================================
// FILTER
// ==========================================

function filterShoppingList() {

    renderShoppingList();

}


// ==========================================
// ICON KATEGORI
// ==========================================

function getShoppingIcon(category) {

    const icons = {

        "Karbohidrat": "🍚",

        "Protein": "🥚",

        "Sayur": "🥦",

        "Buah": "🍎",

        "Susu & Olahan": "🥛",

        "Bumbu": "🧂",

        "Lainnya": "🧺"

    };


    return icons[category] || "🛒";

}


// ==========================================
// RENDER SHOPPING LIST
// ==========================================

function renderShoppingList() {

    const container =
        document.getElementById(
            "shoppingList"
        );


    const totalElement =
        document.getElementById(
            "shoppingTotal"
        );


    const remainingElement =
        document.getElementById(
            "shoppingRemaining"
        );


    const purchasedElement =
        document.getElementById(
            "shoppingPurchased"
        );


    if (!container) {
        return;
    }


    const data =
        getShoppingData();


    // ======================================
    // FILTER
    // ======================================

    const filterElement =
        document.getElementById(
            "shoppingFilter"
        );


    const selectedFilter =
        filterElement
            ? filterElement.value
            : "all";


    let filteredData =
        data;


    if (
        selectedFilter ===
        "remaining"
    ) {

        filteredData =
            data.filter(function(item) {

                return !item.purchased;

            });

    }


    if (
        selectedFilter ===
        "purchased"
    ) {

        filteredData =
            data.filter(function(item) {

                return item.purchased;

            });

    }


    // ======================================
    // STATISTIK
    // ======================================

    const total =
        data.length;


    const remaining =
        data.filter(function(item) {

            return !item.purchased;

        }).length;


    const purchased =
        data.filter(function(item) {

            return item.purchased;

        }).length;


    if (totalElement) {

        totalElement.textContent =
            total;

    }


    if (remainingElement) {

        remainingElement.textContent =
            remaining;

    }


    if (purchasedElement) {

        purchasedElement.textContent =
            purchased;

    }


    // ======================================
    // JIKA KOSONG
    // ======================================

    if (filteredData.length === 0) {

        container.innerHTML = `

            <div class="shopping-empty">

                <div class="shopping-empty-icon">
                    🛒
                </div>

                <h3>
                    Daftar belanja masih kosong
                </h3>

                <p>
                    Tambahkan bahan makanan
                    yang ingin kamu beli.
                </p>

            </div>

        `;

        return;
    }


    // ======================================
    // TAMPILKAN ITEM
    // ======================================

    container.innerHTML =
        filteredData.map(function(item) {

            const statusText =
                item.purchased
                    ? "✓ Sudah dibeli"
                    : "☐ Belum dibeli";


            const statusClass =
                item.purchased
                    ? "shopping-status purchased"
                    : "shopping-status";


            return `

                <div
                    class="shopping-item
                    ${item.purchased ? "purchased" : ""}"
                >

                    <button
                        type="button"
                        class="${statusClass}"
                        onclick="toggleShoppingItem('${item.id}')"
                    >
                        ${statusText}
                    </button>


                    <div class="shopping-item-icon">

                        ${getShoppingIcon(
                            item.category
                        )}

                    </div>


                    <div class="shopping-item-info">

                        <h3>
                            ${item.name}
                        </h3>

                        <p>
                            ${item.quantity}
                            ${item.unit}
                            ·
                            ${item.category}
                        </p>

                    </div>


                    <div class="shopping-item-actions">

                        <button
                            type="button"
                            class="shopping-edit"
                            onclick="editShoppingItem('${item.id}')"
                        >
                            ✏️
                        </button>


                        <button
                            type="button"
                            class="shopping-delete"
                            onclick="deleteShoppingItem('${item.id}')"
                        >
                            🗑️
                        </button>

                    </div>

                </div>

            `;

        }).join("");

}


// ==========================================
// AMBIL ITEM DARI PANTRY
// ==========================================

function addLowStockFromPantry() {

    const pantryData =
        NutriStorage.get(
            "nutricare_pantry",
            []
        );


    if (!Array.isArray(pantryData)) {

        alert(
            "Data Pantry tidak ditemukan."
        );

        return;
    }


    if (pantryData.length === 0) {

        alert(
            "Pantry masih kosong. Tambahkan bahan ke Pantry terlebih dahulu."
        );

        return;
    }


    const lowStockItems =
        pantryData.filter(function(item) {

            return Number(item.quantity) <= 1;

        });


    if (lowStockItems.length === 0) {

        alert(
            "Belum ada bahan Pantry yang stoknya hampir habis."
        );

        return;
    }


    const shoppingData =
        getShoppingData();


    let addedCount = 0;


    lowStockItems.forEach(function(item) {

        const alreadyExists =
            shoppingData.some(function(
                shoppingItem
            ) {

                return (
                    shoppingItem.name
                        .toLowerCase()
                    ===
                    item.name
                        .toLowerCase()
                    &&
                    !shoppingItem.purchased
                );

            });


        if (alreadyExists) {
            return;
        }


        shoppingData.push({

            id:
                Date.now() +
                Math.random(),

            name:
                item.name,

            quantity:
                item.quantity,

            unit:
                item.unit,

            category:
                item.category,

            purchased:
                false,

            createdAt:
                new Date().toISOString()

        });


        addedCount++;

    });


    saveShoppingData(
        shoppingData
    );


    renderShoppingList();


    if (addedCount > 0) {

        alert(
            addedCount +
            " bahan dari Pantry berhasil ditambahkan ke daftar belanja."
        );

    } else {

        alert(
            "Bahan yang stoknya hampir habis sudah ada di daftar belanja."
        );

    }

}


// ==========================================
// HAPUS ITEM YANG SUDAH DIBELI
// ==========================================

function clearPurchasedItems() {

    const data =
        getShoppingData();


    const purchasedItems =
        data.filter(function(item) {

            return item.purchased;

        });


    if (purchasedItems.length === 0) {

        alert(
            "Belum ada item yang ditandai sudah dibeli."
        );

        return;
    }


    const confirmed =
        confirm(
            "Hapus semua item yang sudah dibeli?"
        );


    if (!confirmed) {
        return;
    }


    const remainingItems =
        data.filter(function(item) {

            return !item.purchased;

        });


    saveShoppingData(
        remainingItems
    );


    renderShoppingList();

}


// ==========================================
// RESET SEMUA
// ==========================================

function resetShoppingList() {

    const confirmed =
        confirm(
            "Hapus seluruh daftar belanja?"
        );


    if (!confirmed) {
        return;
    }


    NutriStorage.remove(
        SHOPPING_STORAGE_KEY
    );


    renderShoppingList();

}


// ==========================================
// SAAT HALAMAN DIBUKA
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderShoppingList();

    }
);