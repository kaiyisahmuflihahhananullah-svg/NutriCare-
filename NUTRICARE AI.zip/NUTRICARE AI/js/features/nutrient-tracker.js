// ==========================================
// NutriCare AI - Nutrient Tracker
// ==========================================

const NUTRIENT_STORAGE_KEY = "nutricare_nutrient_tracker";

// ==========================================
// DATABASE MAKANAN CONTOH
// Nilai merupakan estimasi untuk prototype
// ==========================================

const nutrientFoods = [
    {
        id: "rice",
        name: "Nasi putih",
        portion: "150 g",
        icon: "🍚",
        nutrients: {
            carbs: 42,
            protein: 4,
            fiber: 1,
            calcium: 15,
            iron: 0.3,
            vitaminC: 0
        }
    },

    {
        id: "egg",
        name: "Telur",
        portion: "1 butir",
        icon: "🥚",
        nutrients: {
            carbs: 0.6,
            protein: 6,
            fiber: 0,
            calcium: 25,
            iron: 0.9,
            vitaminC: 0
        }
    },

    {
        id: "chicken",
        name: "Ayam",
        portion: "100 g",
        icon: "🍗",
        nutrients: {
            carbs: 0,
            protein: 27,
            fiber: 0,
            calcium: 15,
            iron: 1,
            vitaminC: 0
        }
    },

    {
        id: "tempe",
        name: "Tempe",
        portion: "50 g",
        icon: "🫘",
        nutrients: {
            carbs: 5,
            protein: 10,
            fiber: 2,
            calcium: 50,
            iron: 1.5,
            vitaminC: 0
        }
    },

    {
        id: "vegetables",
        name: "Sayuran campur",
        portion: "100 g",
        icon: "🥦",
        nutrients: {
            carbs: 8,
            protein: 2,
            fiber: 3,
            calcium: 40,
            iron: 1,
            vitaminC: 25
        }
    },

    {
        id: "banana",
        name: "Pisang",
        portion: "1 buah",
        icon: "🍌",
        nutrients: {
            carbs: 23,
            protein: 1,
            fiber: 3,
            calcium: 5,
            iron: 0.3,
            vitaminC: 10
        }
    },

    {
        id: "milk",
        name: "Susu",
        portion: "200 ml",
        icon: "🥛",
        nutrients: {
            carbs: 10,
            protein: 6,
            fiber: 0,
            calcium: 240,
            iron: 0,
            vitaminC: 0
        }
    },

    {
        id: "yogurt",
        name: "Yogurt",
        portion: "100 g",
        icon: "🥣",
        nutrients: {
            carbs: 5,
            protein: 4,
            fiber: 0,
            calcium: 120,
            iron: 0,
            vitaminC: 1
        }
    }
];


// ==========================================
// TANGGAL HARI INI
// ==========================================

function getNutrientToday() {

    const now = new Date();

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}


// ==========================================
// DATA HARI INI
// ==========================================

function getNutrientData() {

    const saved = NutriStorage.get(
        NUTRIENT_STORAGE_KEY,
        null
    );

    const today = getNutrientToday();

    if (!saved || saved.date !== today) {

        return {
            date: today,
            foods: []
        };
    }

    if (!saved.foods) {
        saved.foods = [];
    }

    return saved;
}


// ==========================================
// SIMPAN DATA
// ==========================================

function saveNutrientData(data) {

    NutriStorage.save(
        NUTRIENT_STORAGE_KEY,
        data
    );
}


// ==========================================
// CARI MAKANAN
// ==========================================

function getFoodById(foodId) {

    return nutrientFoods.find(
        function(food) {
            return food.id === foodId;
        }
    );
}


// ==========================================
// TAMBAH MAKANAN
// ==========================================

function addNutrientFood() {

    const select = document.getElementById(
        "nutrientFoodSelect"
    );

    if (!select) return;

    const foodId = select.value;

    if (!foodId) {

        alert("Pilih makanan terlebih dahulu.");

        return;
    }

    const food = getFoodById(foodId);

    if (!food) return;

    const data = getNutrientData();

    const existingFood = data.foods.find(
        function(item) {
            return item.foodId === foodId;
        }
    );

    if (existingFood) {

        existingFood.servings += 1;

    } else {

        data.foods.push({
            foodId: foodId,
            servings: 1
        });
    }

    saveNutrientData(data);

    select.value = "";

    renderNutrientTracker();
}


// ==========================================
// UBAH JUMLAH PORSI
// ==========================================

function changeNutrientServing(foodId, amount) {

    const data = getNutrientData();

    const item = data.foods.find(
        function(food) {
            return food.foodId === foodId;
        }
    );

    if (!item) return;

    item.servings += amount;

    if (item.servings <= 0) {

        data.foods = data.foods.filter(
            function(food) {
                return food.foodId !== foodId;
            }
        );
    }

    saveNutrientData(data);

    renderNutrientTracker();
}


// ==========================================
// HITUNG TOTAL NUTRISI
// ==========================================

function calculateNutrientTotals() {

    const data = getNutrientData();

    const totals = {
        carbs: 0,
        protein: 0,
        fiber: 0,
        calcium: 0,
        iron: 0,
        vitaminC: 0
    };

    data.foods.forEach(
        function(item) {

            const food = getFoodById(item.foodId);

            if (!food) return;

            totals.carbs +=
                food.nutrients.carbs * item.servings;

            totals.protein +=
                food.nutrients.protein * item.servings;

            totals.fiber +=
                food.nutrients.fiber * item.servings;

            totals.calcium +=
                food.nutrients.calcium * item.servings;

            totals.iron +=
                food.nutrients.iron * item.servings;

            totals.vitaminC +=
                food.nutrients.vitaminC * item.servings;
        }
    );

    return totals;
}


// ==========================================
// FORMAT ANGKA
// ==========================================

function formatNutrientNumber(value) {

    return Number(value.toFixed(1));
}


// ==========================================
// RENDER RINGKASAN NUTRISI
// ==========================================

function renderNutrientSummary() {

    const totals = calculateNutrientTotals();

    const elements = {

        carbs: document.getElementById(
            "totalCarbs"
        ),

        protein: document.getElementById(
            "totalProtein"
        ),

        fiber: document.getElementById(
            "totalFiber"
        ),

        calcium: document.getElementById(
            "totalCalcium"
        ),

        iron: document.getElementById(
            "totalIron"
        ),

        vitaminC: document.getElementById(
            "totalVitaminC"
        )
    };

    if (elements.carbs) {
        elements.carbs.textContent =
            formatNutrientNumber(totals.carbs) + " g";
    }

    if (elements.protein) {
        elements.protein.textContent =
            formatNutrientNumber(totals.protein) + " g";
    }

    if (elements.fiber) {
        elements.fiber.textContent =
            formatNutrientNumber(totals.fiber) + " g";
    }

    if (elements.calcium) {
        elements.calcium.textContent =
            formatNutrientNumber(totals.calcium) + " mg";
    }

    if (elements.iron) {
        elements.iron.textContent =
            formatNutrientNumber(totals.iron) + " mg";
    }

    if (elements.vitaminC) {
        elements.vitaminC.textContent =
            formatNutrientNumber(totals.vitaminC) + " mg";
    }
}


// ==========================================
// RENDER DAFTAR MAKANAN
// ==========================================

function renderNutrientFoodList() {

    const container = document.getElementById(
        "nutrientFoodList"
    );

    if (!container) return;

    const data = getNutrientData();

    if (data.foods.length === 0) {

        container.innerHTML = `
            <div class="nutrient-empty">
                <div class="nutrient-empty-icon">
                    🍽️
                </div>

                <h3>
                    Belum ada makanan
                </h3>

                <p>
                    Tambahkan makanan yang kamu konsumsi
                    untuk melihat catatan nutrisinya.
                </p>
            </div>
        `;

        return;
    }

    container.innerHTML = data.foods.map(
        function(item) {

            const food = getFoodById(item.foodId);

            if (!food) return "";

            return `
                <div class="nutrient-food-item">

                    <div class="nutrient-food-icon">
                        ${food.icon}
                    </div>

                    <div class="nutrient-food-info">

                        <h3>
                            ${food.name}
                        </h3>

                        <p>
                            ${food.portion}
                        </p>

                    </div>

                    <div class="nutrient-serving">

                        <button
                            onclick="changeNutrientServing('${food.id}', -1)"
                        >
                            −
                        </button>

                        <strong>
                            ${item.servings}
                        </strong>

                        <button
                            onclick="changeNutrientServing('${food.id}', 1)"
                        >
                            +
                        </button>

                    </div>

                </div>
            `;
        }
    ).join("");
}


// ==========================================
// RENDER SEMUA
// ==========================================

function renderNutrientTracker() {

    renderNutrientSummary();

    renderNutrientFoodList();
}


// ==========================================
// RESET HARI INI
// ==========================================

function resetNutrientTracker() {

    const confirmed = confirm(
        "Hapus semua catatan makanan hari ini?"
    );

    if (!confirmed) return;

    const today = getNutrientToday();

    saveNutrientData({
        date: today,
        foods: []
    });

    renderNutrientTracker();
}


// ==========================================
// ISI DROPDOWN MAKANAN
// ==========================================

function populateNutrientFoodSelect() {

    const select = document.getElementById(
        "nutrientFoodSelect"
    );

    if (!select) return;

    select.innerHTML = `
        <option value="">
            Pilih makanan...
        </option>
    `;

    nutrientFoods.forEach(
        function(food) {

            const option =
                document.createElement("option");

            option.value = food.id;

            option.textContent =
                `${food.icon} ${food.name} — ${food.portion}`;

            select.appendChild(option);
        }
    );
}


// ==========================================
// SAAT HALAMAN DIBUKA
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        populateNutrientFoodSelect();

        renderNutrientTracker();
    }
);