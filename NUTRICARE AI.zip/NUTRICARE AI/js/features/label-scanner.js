// ==========================================
// NutriCare AI - Food Label Scanner
// ==========================================

const LABEL_SCAN_STORAGE_KEY = "nutricare_label_scans";

let selectedLabelImage = "";


// ==========================================
// PREVIEW FOTO LABEL
// ==========================================

function previewLabelImage(file) {

    if (!file) return;

    const reader = new FileReader();

    reader.onload = function(event) {

        selectedLabelImage = event.target.result;

        const preview =
            document.getElementById("labelPreview");

        const placeholder =
            document.getElementById("labelPlaceholder");

        const result =
            document.getElementById("labelResult");

        if (preview) {

            preview.src = selectedLabelImage;

            preview.style.display = "block";
        }

        if (placeholder) {

            placeholder.style.display = "none";
        }

        if (result) {

            result.style.display = "none";
        }
    };

    reader.readAsDataURL(file);
}


// ==========================================
// ANALISIS LABEL
// ==========================================

function scanFoodLabel() {

    if (!selectedLabelImage) {

        alert("Pilih foto label makanan terlebih dahulu.");

        return;
    }

    const result =
        document.getElementById("labelResult");

    if (!result) return;


    // ======================================
    // DATA SIMULASI
    // ======================================

    const sampleResult = {

        productName: "Produk makanan contoh",

        servingSize: "1 porsi",

        energy: "180 kkal",

        protein: "6 g",

        carbohydrate: "28 g",

        sugar: "8 g",

        fiber: "2 g",

        sodium: "120 mg",

        ingredients:
            "Bahan utama, bahan tambahan pangan, dan perisa.",

        allergen:
            "Periksa bagian alergen pada kemasan asli.",

        note:
            "Hasil ini merupakan simulasi pembacaan label untuk prototype."
    };


    result.innerHTML = `

        <div class="result-header">

            <div>
                <span class="result-badge">
                    ✓ Label terbaca
                </span>

                <h2>
                    ${sampleResult.productName}
                </h2>
            </div>

        </div>


        <div class="label-result-grid">


            <div class="result-item">

                <span>
                    Ukuran porsi
                </span>

                <strong>
                    ${sampleResult.servingSize}
                </strong>

            </div>


            <div class="result-item">

                <span>
                    Energi
                </span>

                <strong>
                    ${sampleResult.energy}
                </strong>

            </div>


            <div class="result-item">

                <span>
                    Protein
                </span>

                <strong>
                    ${sampleResult.protein}
                </strong>

            </div>


            <div class="result-item">

                <span>
                    Karbohidrat
                </span>

                <strong>
                    ${sampleResult.carbohydrate}
                </strong>

            </div>


            <div class="result-item">

                <span>
                    Gula
                </span>

                <strong>
                    ${sampleResult.sugar}
                </strong>

            </div>


            <div class="result-item">

                <span>
                    Serat
                </span>

                <strong>
                    ${sampleResult.fiber}
                </strong>

            </div>


            <div class="result-item">

                <span>
                    Natrium
                </span>

                <strong>
                    ${sampleResult.sodium}
                </strong>

            </div>


        </div>


        <div class="label-detail">

            <h3>
                🧾 Bahan
            </h3>

            <p>
                ${sampleResult.ingredients}
            </p>

        </div>


        <div class="label-detail">

            <h3>
                ⚠️ Informasi Alergen
            </h3>

            <p>
                ${sampleResult.allergen}
            </p>

        </div>


        <div class="label-note">

            💡 ${sampleResult.note}

        </div>

    `;


    result.style.display = "block";


    saveLabelScan(sampleResult);
}


// ==========================================
// SIMPAN HASIL SCAN
// ==========================================

function saveLabelScan(result) {

    const saved =
        NutriStorage.get(
            LABEL_SCAN_STORAGE_KEY,
            []
        );

    saved.unshift({

        date: new Date().toISOString(),

        productName:
            result.productName,

        servingSize:
            result.servingSize,

        energy:
            result.energy,

        protein:
            result.protein,

        carbohydrate:
            result.carbohydrate,

        sugar:
            result.sugar,

        fiber:
            result.fiber,

        sodium:
            result.sodium

    });


    // Simpan maksimal 10 riwayat

    const limitedHistory =
        saved.slice(0, 10);


    NutriStorage.save(
        LABEL_SCAN_STORAGE_KEY,
        limitedHistory
    );
}


// ==========================================
// HAPUS FOTO
// ==========================================

function removeLabelImage() {

    selectedLabelImage = "";

    const preview =
        document.getElementById("labelPreview");

    const placeholder =
        document.getElementById("labelPlaceholder");

    const result =
        document.getElementById("labelResult");

    if (preview) {

        preview.src = "";

        preview.style.display = "none";
    }

    if (placeholder) {

        placeholder.style.display = "flex";
    }

    if (result) {

        result.style.display = "none";
    }
}


// ==========================================
// RESET RIWAYAT
// ==========================================

function resetLabelHistory() {

    const confirmed =
        confirm(
            "Hapus seluruh riwayat scan label?"
        );

    if (!confirmed) return;

    NutriStorage.remove(
        LABEL_SCAN_STORAGE_KEY
    );

    alert(
        "Riwayat scan berhasil dihapus."
    );
}