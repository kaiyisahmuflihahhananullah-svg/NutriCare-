// ==========================================
// NutriCare AI - Nutrition Recommendations
// ==========================================

function getNutritionRecommendations() {

    const profile = getProfile();

    const goal = profile.healthGoal || "";

    const activity = profile.activityLevel || "sedentary";

    return {
        goal: getNutritionGoalText(goal),
        activity: getActivityText(activity),

        carbohydrates: {
            title: "Karbohidrat",
            icon: "🍚",
            description:
                "Pilih sumber karbohidrat yang dapat menjadi bagian dari pola makan seimbang.",
            examples:
                "Nasi, kentang, ubi, jagung, oat, dan roti."
        },

        protein: {
            title: "Protein",
            icon: "🥚",
            description:
                "Usahakan ada sumber protein dalam makanan sehari-hari untuk mendukung pertumbuhan dan fungsi tubuh.",
            examples:
                "Telur, ikan, ayam, tahu, tempe, susu, dan kacang-kacangan."
        },

        vegetables: {
            title: "Sayur & Buah",
            icon: "🥬",
            description:
                "Variasikan jenis dan warna sayur serta buah untuk mendapatkan beragam zat gizi.",
            examples:
                "Bayam, wortel, brokoli, pisang, pepaya, apel, dan jeruk."
        },

        fluids: {
            title: "Cairan",
            icon: "💧",
            description:
                "Jadikan air putih sebagai pilihan utama untuk membantu memenuhi kebutuhan cairan.",
            examples:
                "Bawa botol minum agar lebih mudah mengingat untuk minum."
        },

        activity: {
            title: "Aktivitas",
            icon: "🏃",
            description:
                "Seimbangkan pola makan dengan aktivitas fisik yang sesuai dan menyenangkan.",
            examples:
                "Jalan kaki, bersepeda, olahraga ringan, atau aktivitas fisik lainnya."
        },

        rest: {
            title: "Istirahat",
            icon: "😴",
            description:
                "Tidur dan istirahat yang cukup merupakan bagian penting dari kesehatan secara keseluruhan.",
            examples:
                "Buat jadwal tidur yang teratur dan kurangi penggunaan layar menjelang tidur."
        }
    };
}


function getNutritionGoalText(goal) {

    const goals = {

        maintain:
            "Fokus pada pola makan seimbang dan kebiasaan sehat yang konsisten.",

        improve:
            "Fokus pada variasi makanan, kecukupan zat gizi, hidrasi, aktivitas, dan istirahat.",

        fitness:
            "Fokus pada makanan beragam, sumber protein, karbohidrat, cairan, aktivitas, dan pemulihan yang cukup."

    };

    return goals[goal] ||
        "Fokus pada pola makan seimbang, variasi makanan, hidrasi, aktivitas, dan istirahat yang cukup.";
}


function getActivityText(activity) {

    const activities = {

        sedentary:
            "Aktivitas harian cenderung ringan.",

        light:
            "Aktivitas harian tergolong ringan.",

        moderate:
            "Aktivitas harian tergolong sedang.",

        active:
            "Aktivitas harian cukup aktif.",

        veryActive:
            "Aktivitas harian tergolong sangat aktif."

    };

    return activities[activity] ||
        "Aktivitas belum ditentukan.";
}