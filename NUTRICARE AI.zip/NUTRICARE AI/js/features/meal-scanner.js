
/* ==========================================
   NutriCare AI - AI Meal Scanner
   Camera + Gallery + AI Vision
   Food Confirmation + Portion
========================================== */

let selectedMealImage = "";
let mealCameraStream = null;
let selectedFoodCandidate = null;
let latestMealAnalysis = null;
let confirmedMealData = null;

// ==========================================
// ELEMENTS
// ==========================================

function getMealElement(id) {
    return document.getElementById(id);
}

// ==========================================
// STATUS MESSAGE
// ==========================================

function showScannerStatus(message, type = "success") {
    const status = getMealElement("scannerStatus");

    status.textContent = message;
    status.className = "status-message";

    if (type === "error") {
        status.classList.add("error");
    }

    status.style.display = "block";
}

function hideScannerStatus() {
    getMealElement("scannerStatus").style.display = "none";
}

// ==========================================
// IMAGE PROCESSING
// ==========================================

function processMealImage(file) {
    return new Promise((resolve, reject) => {
        if (!file || !file.type.startsWith("image/")) {
            reject(new Error("File yang dipilih bukan gambar."));
            return;
        }

        if (file.size > 15 * 1024 * 1024) {
            reject(new Error("Ukuran foto maksimal 15 MB."));
            return;
        }

        const image = new Image();
        const reader = new FileReader();

        reader.onload = function(event) {
            image.onload = function() {
                const maxDimension = 1600;

                let width = image.width;
                let height = image.height;

                const scale = Math.min(
                    1,
                    maxDimension / Math.max(width, height)
                );

                width = Math.round(width * scale);
                height = Math.round(height * scale);

                const canvas = document.createElement("canvas");

                canvas.width = width;
                canvas.height = height;

                const context = canvas.getContext("2d");

                context.drawImage(
                    image,
                    0,
                    0,
                    width,
                    height
                );

                resolve(
                    canvas.toDataURL("image/jpeg", 0.82)
                );
            };

            image.onerror = function() {
                reject(new Error("Foto tidak dapat dibaca."));
            };

            image.src = event.target.result;
        };

        reader.onerror = function() {
            reject(new Error("Gagal membaca file foto."));
        };

        reader.readAsDataURL(file);
    });
}

// ==========================================
// PREVIEW PHOTO
// ==========================================

async function previewMealImage(file) {
    if (!file) return;

    try {
        hideScannerStatus();
        closeMealCamera();

        showScannerStatus("Menyiapkan foto makanan...");

        selectedMealImage = await processMealImage(file);

        getMealElement("mealPreview").src = selectedMealImage;
        getMealElement("mealPreview").style.display = "block";

        getMealElement("mealPlaceholder").style.display = "none";
        getMealElement("cameraPanel").style.display = "none";

        getMealElement("sourceActions").style.display = "none";
        getMealElement("cameraActions").style.display = "none";
        getMealElement("mainActions").style.display = "flex";

        resetMealResults();

        showScannerStatus(
            "Foto berhasil disiapkan. Kamu bisa mulai mengenali makanan."
        );

    } catch (error) {
        showScannerStatus(error.message, "error");
    }
}

// ==========================================
// CAMERA
// ==========================================

async function openMealCamera() {
    hideScannerStatus();

    if (!navigator.mediaDevices?.getUserMedia) {
        showScannerStatus(
            "Browser tidak mendukung akses kamera. Silakan gunakan galeri.",
            "error"
        );
        return;
    }

    try {
        mealCameraStream = await navigator.mediaDevices.getUserMedia({
            video: {
                facingMode: {
                    ideal: "environment"
                }
            },
            audio: false
        });

        const video = getMealElement("cameraVideo");

        video.srcObject = mealCameraStream;

        await video.play();

        getMealElement("mealPlaceholder").style.display = "none";
        getMealElement("mealPreview").style.display = "none";

        getMealElement("cameraPanel").style.display = "block";
        getMealElement("sourceActions").style.display = "none";
        getMealElement("cameraActions").style.display = "flex";
        getMealElement("mainActions").style.display = "none";

        resetMealResults();

    } catch (error) {
        console.error("Camera error:", error);

        let message = "Kamera tidak dapat dibuka.";

        if (error.name === "NotAllowedError") {
            message = "Izin kamera belum diberikan. Izinkan akses kamera melalui browser.";
        } else if (error.name === "NotFoundError") {
            message = "Kamera tidak ditemukan pada perangkat ini.";
        } else if (error.name === "NotReadableError") {
            message = "Kamera sedang digunakan aplikasi lain.";
        }

        showScannerStatus(message, "error");
    }
}

function closeMealCamera() {
    if (mealCameraStream) {
        mealCameraStream.getTracks().forEach(track => {
            track.stop();
        });

        mealCameraStream = null;
    }

    const video = getMealElement("cameraVideo");

    if (video) {
        video.srcObject = null;
    }

    const panel = getMealElement("cameraPanel");
    const actions = getMealElement("cameraActions");

    if (panel) panel.style.display = "none";
    if (actions) actions.style.display = "none";
}

// ==========================================
// CAPTURE PHOTO
// ==========================================

function captureMealPhoto() {
    const video = getMealElement("cameraVideo");
    const canvas = getMealElement("cameraCanvas");

    if (!video.videoWidth || !video.videoHeight) {
        showScannerStatus(
            "Kamera belum siap. Coba beberapa saat lagi.",
            "error"
        );
        return;
    }

    const maxDimension = 1600;

    let width = video.videoWidth;
    let height = video.videoHeight;

    const scale = Math.min(
        1,
        maxDimension / Math.max(width, height)
    );

    width = Math.round(width * scale);
    height = Math.round(height * scale);

    canvas.width = width;
    canvas.height = height;

    const context = canvas.getContext("2d");

    context.drawImage(
        video,
        0,
        0,
        width,
        height
    );

    selectedMealImage = canvas.toDataURL(
        "image/jpeg",
        0.82
    );

    getMealElement("mealPreview").src = selectedMealImage;
    getMealElement("mealPreview").style.display = "block";

    getMealElement("mealPlaceholder").style.display = "none";

    closeMealCamera();

    getMealElement("sourceActions").style.display = "none";
    getMealElement("mainActions").style.display = "flex";

    resetMealResults();

    showScannerStatus(
        "Foto berhasil diambil. Periksa fotonya sebelum analisis."
    );
}

// ==========================================
// RESET RESULTS
// ==========================================

function resetMealResults() {
    selectedFoodCandidate = null;
    latestMealAnalysis = null;
    confirmedMealData = null;

    getMealElement("scanResult").style.display = "none";
    getMealElement("candidateList").replaceChildren();

    getMealElement("confirmationPanel").style.display = "none";
    getMealElement("confirmedResult").style.display = "none";

    getMealElement("portionInput").value = "";

    const foodInput = getMealElement("confirmedFoodName");
    const componentsInput = getMealElement("confirmedComponents");

    if (foodInput) foodInput.value = "";
    if (componentsInput) componentsInput.value = "";
}

// ==========================================
// CREATE EDITABLE CONFIRMATION FIELDS
// ==========================================

function createConfirmationFields() {
    const panel = getMealElement("confirmationPanel");

    if (getMealElement("confirmedFoodName")) {
        return;
    }

    const portionLabel = getMealElement("portionInput")
        .previousElementSibling;

    const group = document.createElement("div");
    group.id = "editableFoodFields";

    group.style.marginBottom = "18px";

    const foodLabel = document.createElement("label");
    foodLabel.className = "portion-label";
    foodLabel.htmlFor = "confirmedFoodName";
    foodLabel.textContent = "Nama makanan";

    const foodInput = document.createElement("input");
    foodInput.className = "portion-input";
    foodInput.id = "confirmedFoodName";
    foodInput.type = "text";
    foodInput.maxLength = 120;
    foodInput.placeholder = "Contoh: Nasi ayam sayur";

    const componentLabel = document.createElement("label");
    componentLabel.className = "portion-label";
    componentLabel.htmlFor = "confirmedComponents";
    componentLabel.textContent = "Komponen makanan";

    const componentInput = document.createElement("textarea");
    componentInput.className = "portion-input";
    componentInput.id = "confirmedComponents";
    componentInput.rows = 3;
    componentInput.maxLength = 500;
    componentInput.placeholder =
        "Contoh: Nasi putih, ayam, wortel, buncis";

    componentInput.style.resize = "vertical";

    group.append(
        foodLabel,
        foodInput,
        componentLabel,
        componentInput
    );

    panel.insertBefore(group, portionLabel);
}


// ==========================================
// SCAN MEAL - DEMO MODE
// ==========================================


// ==========================================
// SCAN MEAL - AI VISION
// ==========================================

async function scanMeal() {
    if (!selectedMealImage) {
        showScannerStatus(
            "Ambil atau pilih foto makanan terlebih dahulu.",
            "error"
        );
        return;
    }

    const scanButton = getMealElement("scanButton");

    scanButton.disabled = true;
    scanButton.textContent = "Menganalisis Foto...";

    resetMealResults();

    showScannerStatus(
        "AI sedang mengenali makanan dari fotomu. Mohon tunggu..."
    );

    try {
        const response = await fetch(
            "http://localhost:3000/api/scan-meal",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    imageData: selectedMealImage
                })
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.error || "Gagal menganalisis foto makanan."
            );
        }

        const analysis = data.analysis;

        if (
            !analysis ||
            !Array.isArray(analysis.candidates)
        ) {
            throw new Error(
                "Format hasil analisis AI tidak sesuai."
            );
        }

        latestMealAnalysis = analysis;

        renderMealAnalysis(latestMealAnalysis);

        if (analysis.candidates.length > 0) {
            showScannerStatus(
                "Analisis AI berhasil! Pilih kandidat yang paling sesuai dengan makananmu."
            );
        }

    } catch (error) {
        console.error("Meal scanner AI error:", error);

        showScannerStatus(
            "Gagal mengenali makanan: " + error.message,
            "error"
        );

    } finally {
        scanButton.disabled = false;
        scanButton.textContent = "✨ Kenali Makanan";
    }
}



// ==========================================
// RENDER AI RESULT
// ==========================================

function renderMealAnalysis(analysis) {
    const result = getMealElement("scanResult");
    const list = getMealElement("candidateList");
    const notes = getMealElement("visualNotes");

    list.replaceChildren();

    const candidates = Array.isArray(analysis.candidates)
        ? analysis.candidates
        : [];

    if (candidates.length === 0) {
        result.style.display = "none";

        showScannerStatus(
            "AI belum menemukan makanan yang cukup jelas. Coba foto lain dengan pencahayaan lebih baik.",
            "error"
        );

        return;
    }

    candidates.forEach((candidate, index) => {
        const card = document.createElement("button");

        card.type = "button";
        card.className = "candidate-card";

        const name = document.createElement("span");
        name.className = "candidate-name";
        name.textContent =
            candidate.foodName || "Makanan tidak diketahui";

        const confidence = document.createElement("span");
        confidence.className = "candidate-confidence";
        confidence.textContent =
            "Tingkat keyakinan visual: " +
            (candidate.confidence || "belum diketahui");

        const components = document.createElement("span");
        components.className = "candidate-components";

        const componentList = Array.isArray(candidate.components)
            ? candidate.components
            : [];

        components.textContent = componentList.length
            ? "Komponen terlihat: " + componentList.join(", ")
            : "Komponen makanan belum dapat dipastikan.";

        card.append(name, confidence, components);

        card.addEventListener("click", () => {
            selectFoodCandidate(index);
        });

        list.appendChild(card);
    });

    notes.textContent =
        "Catatan visual: " +
        (analysis.visualNotes || "Tidak ada catatan tambahan.");

    result.style.display = "block";

    createConfirmationFields();

    getMealElement("confirmationPanel").style.display = "block";
}

// ==========================================
// SELECT FOOD
// ==========================================

function selectFoodCandidate(index) {
    const candidates = latestMealAnalysis?.candidates;

    if (!Array.isArray(candidates) || !candidates[index]) {
        return;
    }

    selectedFoodCandidate = candidates[index];

    const cards = getMealElement("candidateList").children;

    Array.from(cards).forEach((card, cardIndex) => {
        card.classList.toggle(
            "selected",
            cardIndex === index
        );
    });

    const foodName = getMealElement("confirmedFoodName");
    const components = getMealElement("confirmedComponents");

    foodName.value = selectedFoodCandidate.foodName || "";

    components.value = Array.isArray(selectedFoodCandidate.components)
        ? selectedFoodCandidate.components.join(", ")
        : "";

    getMealElement("confirmedResult").style.display = "none";

    showScannerStatus(
        "Pilihan makanan sudah diisi. Kamu masih bisa mengoreksinya."
    );
}

// ==========================================
// CONFIRM FOOD AND PORTION
// ==========================================

function confirmMeal() {
    if (!selectedFoodCandidate) {
        showScannerStatus(
            "Pilih salah satu kemungkinan makanan terlebih dahulu.",
            "error"
        );
        return;
    }

    const foodName = getMealElement("confirmedFoodName")
        .value.trim();

    const componentsText = getMealElement("confirmedComponents")
        .value.trim();

    const portion = getMealElement("portionInput")
        .value.trim();

    if (!foodName) {
        showScannerStatus(
            "Masukkan nama makanan terlebih dahulu.",
            "error"
        );

        getMealElement("confirmedFoodName").focus();
        return;
    }

    if (!componentsText) {
        showScannerStatus(
            "Masukkan komponen makanan yang kamu ketahui.",
            "error"
        );

        getMealElement("confirmedComponents").focus();
        return;
    }

    if (!portion) {
        showScannerStatus(
            "Masukkan perkiraan porsi makanan terlebih dahulu.",
            "error"
        );

        getMealElement("portionInput").focus();
        return;
    }

    const components = componentsText
        .split(",")
        .map(item => item.trim())
        .filter(Boolean);

    confirmedMealData = {
        foodName,
        components,
        portion,
        confirmedAt: new Date().toISOString(),
        source: "meal-scanner"
    };

    renderConfirmedMeal();

    showScannerStatus(
        "Konfirmasi berhasil. Data siap untuk tahap estimasi gizi."
    );
}

// ==========================================
// RENDER CONFIRMED MEAL
// ==========================================

function renderConfirmedMeal() {
    const confirmation = getMealElement("confirmedResult");

    confirmation.replaceChildren();

    const title = document.createElement("h4");
    title.textContent = "✓ Makanan berhasil dikonfirmasi";

    const food = document.createElement("p");
    food.textContent =
        "Nama makanan: " + confirmedMealData.foodName;

    const componentText = document.createElement("p");
    componentText.textContent =
        "Komponen: " + confirmedMealData.components.join(", ");

    const portion = document.createElement("p");
    portion.textContent =
        "Porsi: " + confirmedMealData.portion;

    const note = document.createElement("p");
    note.textContent =
        "Konfirmasi ini belum menghasilkan perhitungan nutrisi dan belum disimpan ke Nutrition Tracker.";

    confirmation.append(
        title,
        food,
        componentText,
        portion,
        note
    );

    confirmation.style.display = "block";
}

// ==========================================
// REMOVE PHOTO
// ==========================================

function removeMealImage() {
    selectedMealImage = "";

    closeMealCamera();

    getMealElement("mealPreview").src = "";
    getMealElement("mealPreview").style.display = "none";

    getMealElement("mealPlaceholder").style.display = "flex";

    getMealElement("mealInput").value = "";

    getMealElement("sourceActions").style.display = "flex";
    getMealElement("mainActions").style.display = "none";

    resetMealResults();
    hideScannerStatus();
}

// ==========================================
// FILE INPUT
// ==========================================

document.addEventListener("DOMContentLoaded", () => {
    const input = getMealElement("mealInput");

    input.addEventListener("change", async event => {
        const file = event.target.files?.[0];

        if (file) {
            await previewMealImage(file);
        }
    });

    createConfirmationFields();
});

// ==========================================
// STOP CAMERA WHEN LEAVING PAGE
// ==========================================

window.addEventListener("pagehide", () => {
    closeMealCamera();
});
