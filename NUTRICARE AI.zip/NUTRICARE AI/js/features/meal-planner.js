// ==========================================
// NutriCare AI - Meal Planner
// ==========================================

const defaultMealPlan = {

    breakfast: {
        title: "Sarapan",
        icon: "🌅",
        menu: "Nasi + telur + sayur + buah"
    },

    lunch: {
        title: "Makan Siang",
        icon: "🍱",
        menu: "Nasi + ayam/ikan + sayur"
    },

    dinner: {
        title: "Makan Malam",
        icon: "🌙",
        menu: "Nasi + tahu/tempe + sayur"
    },

    snack: {
        title: "Snack",
        icon: "🍎",
        menu: "Buah + susu atau yogurt"
    }

};


// ==========================================
// Mengambil profil pengguna
// ==========================================

function getMealPlannerProfile() {

    if (typeof getProfile === "function") {
        return getProfile();
    }

    return {
        name: "",
        foodPreferences: [],
        allergies: [],
        dislikedFoods: []
    };
}


// ==========================================
// Membuat rekomendasi berdasarkan profil
// ==========================================

function generateMealPlan() {

    const profile = getMealPlannerProfile();

    let plan = {
        breakfast: {
            title: "Sarapan",
            icon: "🌅",
            menu: "Nasi + telur + sayur + buah"
        },

        lunch: {
            title: "Makan Siang",
            icon: "🍱",
            menu: "Nasi + ayam/ikan + sayur"
        },

        dinner: {
            title: "Makan Malam",
            icon: "🌙",
            menu: "Nasi + tahu/tempe + sayur"
        },

        snack: {
            title: "Snack",
            icon: "🍎",
            menu: "Buah + susu atau yogurt"
        }
    };


    // Contoh penyesuaian berdasarkan preferensi

    const preferences =
        profile.foodPreferences || [];


    if (preferences.includes("vegetarian")) {

        plan.lunch.menu =
            "Nasi + tahu/tempe + sayuran";

        plan.dinner.menu =
            "Kentang/nasi + tahu/tempe + sayuran";

    }


    if (preferences.includes("lowSugar")) {

        plan.snack.menu =
            "Buah utuh + kacang-kacangan";

    }


    // Menyimpan meal plan

    if (
        typeof NutriStorage !== "undefined" &&
        typeof STORAGE_KEYS !== "undefined"
    ) {

        NutriStorage.save(
            STORAGE_KEYS.MEALS,
            plan
        );

    }


    return plan;
}


// ==========================================
// Mengambil meal plan yang tersimpan
// ==========================================

function getSavedMealPlan() {

    if (
        typeof NutriStorage !== "undefined" &&
        typeof STORAGE_KEYS !== "undefined"
    ) {

        return NutriStorage.get(
            STORAGE_KEYS.MEALS,
            null
        );

    }

    return null;
}


// ==========================================
// Menampilkan meal plan
// ==========================================

function renderMealPlan() {

    const container =
        document.getElementById("mealPlanContainer");

    if (!container) {
        return;
    }


    let plan = getSavedMealPlan();


    if (!plan) {
        plan = generateMealPlan();
    }


    container.innerHTML = `

        <div class="meal-card">

            <div class="meal-icon">
                ${plan.breakfast.icon}
            </div>

            <div class="meal-content">

                <h3>
                    ${plan.breakfast.title}
                </h3>

                <p>
                    ${plan.breakfast.menu}
                </p>

            </div>

        </div>


        <div class="meal-card">

            <div class="meal-icon">
                ${plan.lunch.icon}
            </div>

            <div class="meal-content">

                <h3>
                    ${plan.lunch.title}
                </h3>

                <p>
                    ${plan.lunch.menu}
                </p>

            </div>

        </div>


        <div class="meal-card">

            <div class="meal-icon">
                ${plan.dinner.icon}
            </div>

            <div class="meal-content">

                <h3>
                    ${plan.dinner.title}
                </h3>

                <p>
                    ${plan.dinner.menu}
                </p>

            </div>

        </div>


        <div class="meal-card">

            <div class="meal-icon">
                ${plan.snack.icon}
            </div>

            <div class="meal-content">

                <h3>
                    ${plan.snack.title}
                </h3>

                <p>
                    ${plan.snack.menu}
                </p>

            </div>

        </div>

    `;
}


// ==========================================
// Generate ulang
// ==========================================

function regenerateMealPlan() {

    generateMealPlan();

    renderMealPlan();

}


// ==========================================
// Jalankan saat halaman dibuka
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderMealPlan();

    }
);