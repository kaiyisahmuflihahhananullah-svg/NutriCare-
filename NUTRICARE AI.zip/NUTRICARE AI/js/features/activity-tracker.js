// ==========================================
// NutriCare AI - Activity Tracker
// ==========================================

const ACTIVITY_STORAGE_KEY = "nutricare_activity";


// ==========================================
// DATA AKTIVITAS HARI INI
// ==========================================

function getTodayActivityData() {

    const today =
        new Date()
            .toISOString()
            .split("T")[0];

    const saved =
        NutriStorage.get(
            ACTIVITY_STORAGE_KEY,
            null
        );

    if (!saved || saved.date !== today) {

        return {
            date: today,
            activities: []
        };
    }

    return saved;
}


// ==========================================
// SIMPAN DATA
// ==========================================

function saveActivityData(data) {

    NutriStorage.save(
        ACTIVITY_STORAGE_KEY,
        data
    );
}


// ==========================================
// TAMBAH AKTIVITAS
// ==========================================

function addActivity() {

    const type =
        document.getElementById(
            "activityType"
        ).value;

    const duration =
        Number(
            document.getElementById(
                "activityDuration"
            ).value
        );

    const note =
        document.getElementById(
            "activityNote"
        ).value.trim();


    if (!type) {

        alert(
            "Pilih jenis aktivitas terlebih dahulu."
        );

        return;
    }


    if (!duration || duration <= 0) {

        alert(
            "Masukkan durasi aktivitas terlebih dahulu."
        );

        return;
    }


    const data =
        getTodayActivityData();


    const activity = {

        id:
            Date.now(),

        type:
            type,

        duration:
            duration,

        note:
            note
    };


    data.activities.push(
        activity
    );


    saveActivityData(
        data
    );


    document.getElementById(
        "activityType"
    ).value = "";

    document.getElementById(
        "activityDuration"
    ).value = "";

    document.getElementById(
        "activityNote"
    ).value = "";


    renderActivityTracker();
}


// ==========================================
// HAPUS AKTIVITAS
// ==========================================

function deleteActivity(id) {

    const data =
        getTodayActivityData();


    data.activities =
        data.activities.filter(
            function(activity) {

                return activity.id !== id;

            }
        );


    saveActivityData(
        data
    );


    renderActivityTracker();
}


// ==========================================
// TOTAL DURASI
// ==========================================

function getTotalActivityMinutes() {

    const data =
        getTodayActivityData();


    return data.activities.reduce(
        function(total, activity) {

            return total +
                Number(activity.duration);

        },
        0
    );
}


// ==========================================
// LABEL AKTIVITAS
// ==========================================

function getActivityIcon(type) {

    const icons = {

        "Jalan kaki": "🚶",
        "Bersepeda": "🚴",
        "Olahraga": "🏃",
        "Peregangan": "🧘",
        "Permainan": "🏸",
        "Aktivitas ringan": "🌿",
        "Lainnya": "✨"
    };


    return icons[type] || "🏃";
}


// ==========================================
// RENDER
// ==========================================

function renderActivityTracker() {

    const data =
        getTodayActivityData();


    const total =
        getTotalActivityMinutes();


    const totalElement =
        document.getElementById(
            "activityTotal"
        );


    const listElement =
        document.getElementById(
            "activityList"
        );


    if (totalElement) {

        totalElement.textContent =
            total + " menit";
    }


    if (!listElement) {
        return;
    }


    if (data.activities.length === 0) {

        listElement.innerHTML = `
            <div class="activity-empty">
                <div class="activity-empty-icon">
                    🌱
                </div>

                <p>
                    Belum ada aktivitas yang dicatat hari ini.
                </p>

                <span>
                    Tambahkan aktivitasmu di atas.
                </span>
            </div>
        `;

        return;
    }


    listElement.innerHTML =
        data.activities
            .map(function(activity) {

                return `
                    <div class="activity-item">

                        <div class="activity-item-icon">
                            ${getActivityIcon(activity.type)}
                        </div>

                        <div class="activity-item-content">

                            <h3>
                                ${activity.type}
                            </h3>

                            <p>
                                ${activity.duration} menit
                            </p>

                            ${
                                activity.note
                                ? `
                                    <span class="activity-note">
                                        ${activity.note}
                                    </span>
                                `
                                : ""
                            }

                        </div>

                        <button
                            class="activity-delete"
                            onclick="deleteActivity(${activity.id})"
                        >
                            🗑️
                        </button>

                    </div>
                `;

            })
            .join("");
}


// ==========================================
// RESET SEMUA AKTIVITAS HARI INI
// ==========================================

function resetActivities() {

    const confirmReset =
        confirm(
            "Hapus semua aktivitas hari ini?"
        );


    if (!confirmReset) {
        return;
    }


    const today =
        new Date()
            .toISOString()
            .split("T")[0];


    saveActivityData({

        date: today,

        activities: []

    });


    renderActivityTracker();
}


// ==========================================
// INITIAL LOAD
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderActivityTracker();

    }
);