// ==========================================
// NutriCare AI - Smart Reminder
// ==========================================

const REMINDER_STORAGE_KEY = "nutricare_reminders";

const defaultReminders = [
    {
        id: "water",
        icon: "💧",
        title: "Minum Air",
        description: "Ingat untuk minum air secara teratur.",
        time: "09:00",
        enabled: true
    },
    {
        id: "meal",
        icon: "🍽️",
        title: "Waktu Makan",
        description: "Ingat untuk menikmati waktu makan dengan teratur.",
        time: "12:00",
        enabled: true
    },
    {
        id: "activity",
        icon: "🏃",
        title: "Aktivitas",
        description: "Luangkan waktu untuk bergerak dan beraktivitas.",
        time: "16:00",
        enabled: true
    },
    {
        id: "checkin",
        icon: "🌤️",
        title: "Daily Check-in",
        description: "Cek kondisi dan perasaanmu hari ini.",
        time: "19:00",
        enabled: true
    },
    {
        id: "sleep",
        icon: "😴",
        title: "Persiapan Tidur",
        description: "Mulai bersiap untuk waktu istirahat.",
        time: "21:00",
        enabled: true
    }
];


// ==========================================
// STORAGE
// ==========================================

function getReminderData() {

    const saved = NutriStorage.get(
        REMINDER_STORAGE_KEY,
        null
    );

    if (!saved) {

        NutriStorage.save(
            REMINDER_STORAGE_KEY,
            defaultReminders
        );

        return [...defaultReminders];
    }

    return saved;
}


function saveReminderData(data) {

    NutriStorage.save(
        REMINDER_STORAGE_KEY,
        data
    );
}


// ==========================================
// ADD REMINDER
// ==========================================

function addReminder() {

    const titleInput =
        document.getElementById("reminderTitle");

    const descriptionInput =
        document.getElementById("reminderDescription");

    const timeInput =
        document.getElementById("reminderTime");

    const iconInput =
        document.getElementById("reminderIcon");


    if (!titleInput || !timeInput) {
        return;
    }


    const title =
        titleInput.value.trim();

    const description =
        descriptionInput
            ? descriptionInput.value.trim()
            : "";

    const time =
        timeInput.value;

    const icon =
        iconInput
            ? iconInput.value.trim()
            : "🔔";


    if (!title) {

        alert("Masukkan nama reminder terlebih dahulu.");

        return;
    }


    if (!time) {

        alert("Pilih waktu reminder terlebih dahulu.");

        return;
    }


    const reminders =
        getReminderData();


    reminders.push({

        id:
            "custom-" +
            Date.now(),

        icon:
            icon || "🔔",

        title:
            title,

        description:
            description ||
            "Reminder pribadi NutriCare.",

        time:
            time,

        enabled:
            true

    });


    saveReminderData(reminders);


    titleInput.value = "";

    if (descriptionInput) {
        descriptionInput.value = "";
    }

    timeInput.value = "";

    if (iconInput) {
        iconInput.value = "";
    }


    renderReminders();

    alert("Reminder berhasil ditambahkan 🔔");
}


// ==========================================
// TOGGLE REMINDER
// ==========================================

function toggleReminder(id) {

    const reminders =
        getReminderData();


    const reminder =
        reminders.find(function(item) {

            return item.id === id;

        });


    if (!reminder) {
        return;
    }


    reminder.enabled =
        !reminder.enabled;


    saveReminderData(reminders);

    renderReminders();
}


// ==========================================
// DELETE REMINDER
// ==========================================

function deleteReminder(id) {

    const confirmed =
        confirm(
            "Hapus reminder ini?"
        );


    if (!confirmed) {
        return;
    }


    let reminders =
        getReminderData();


    reminders =
        reminders.filter(function(item) {

            return item.id !== id;

        });


    saveReminderData(reminders);

    renderReminders();
}


// ==========================================
// RENDER REMINDERS
// ==========================================

function renderReminders() {

    const container =
        document.getElementById(
            "reminderList"
        );


    const countElement =
        document.getElementById(
            "reminderCount"
        );


    if (!container) {
        return;
    }


    const reminders =
        getReminderData();


    if (countElement) {

        const activeCount =
            reminders.filter(function(item) {

                return item.enabled;

            }).length;


        countElement.textContent =
            activeCount +
            " reminder aktif";

    }


    if (reminders.length === 0) {

        container.innerHTML = `

            <div class="reminder-empty">

                <div class="reminder-empty-icon">
                    🔔
                </div>

                <h3>
                    Belum ada reminder
                </h3>

                <p>
                    Tambahkan reminder untuk membantu
                    menjaga rutinitas sehatmu.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        reminders
            .sort(function(a, b) {

                return a.time.localeCompare(
                    b.time
                );

            })
            .map(function(reminder) {

                return `

                    <article class="
                        reminder-item
                        ${reminder.enabled
                            ? "active"
                            : "inactive"}
                    ">

                        <div class="
                            reminder-icon
                        ">
                            ${reminder.icon}
                        </div>


                        <div class="
                            reminder-content
                        ">

                            <div class="
                                reminder-top
                            ">

                                <h3>
                                    ${reminder.title}
                                </h3>

                                <strong>
                                    ${reminder.time}
                                </strong>

                            </div>


                            <p>
                                ${reminder.description}
                            </p>


                            <span class="
                                reminder-status
                            ">

                                ${reminder.enabled
                                    ? "● Aktif"
                                    : "○ Nonaktif"}

                            </span>

                        </div>


                        <div class="
                            reminder-actions
                        ">

                            <button
                                class="
                                    reminder-toggle
                                    ${reminder.enabled
                                        ? "on"
                                        : ""}
                                "
                                onclick="
                                    toggleReminder(
                                        '${reminder.id}'
                                    )
                                "
                            >

                                ${reminder.enabled
                                    ? "Aktif"
                                    : "Nonaktif"}

                            </button>


                            <button
                                class="
                                    reminder-delete
                                "
                                onclick="
                                    deleteReminder(
                                        '${reminder.id}'
                                    )
                                "
                            >
                                🗑️
                            </button>

                        </div>

                    </article>

                `;

            })
            .join("");
}


// ==========================================
// CHECK REMINDER
// ==========================================

let lastReminderMinute = "";


function checkSmartReminder() {

    const now =
        new Date();


    const currentHour =
        String(
            now.getHours()
        ).padStart(2, "0");


    const currentMinute =
        String(
            now.getMinutes()
        ).padStart(2, "0");


    const currentTime =
        currentHour +
        ":" +
        currentMinute;


    const currentKey =
        now.toISOString().split("T")[0] +
        "-" +
        currentTime;


    if (
        currentKey ===
        lastReminderMinute
    ) {

        return;
    }


    lastReminderMinute =
        currentKey;


    const reminders =
        getReminderData();


    const dueReminders =
        reminders.filter(function(reminder) {

            return (
                reminder.enabled &&
                reminder.time === currentTime
            );

        });


    dueReminders.forEach(function(reminder) {

        showReminderToast(reminder);

    });
}


// ==========================================
// REMINDER TOAST
// ==========================================

function showReminderToast(reminder) {

    const existing =
        document.getElementById(
            "smartReminderToast"
        );


    if (existing) {
        existing.remove();
    }


    const toast =
        document.createElement("div");


    toast.id =
        "smartReminderToast";


    toast.innerHTML = `

        <div class="
            smart-reminder-toast-icon
        ">
            ${reminder.icon}
        </div>

        <div>

            <strong>
                ${reminder.title}
            </strong>

            <p>
                ${reminder.description}
            </p>

        </div>

    `;


    document.body.appendChild(toast);


    setTimeout(function() {

        toast.classList.add("show");

    }, 50);


    setTimeout(function() {

        toast.classList.remove("show");


        setTimeout(function() {

            toast.remove();

        }, 300);

    }, 5000);
}


// ==========================================
// RESET REMINDERS
// ==========================================

function resetReminders() {

    const confirmed =
        confirm(
            "Kembalikan reminder ke pengaturan awal?"
        );


    if (!confirmed) {
        return;
    }


    saveReminderData(
        [...defaultReminders]
    );


    renderReminders();

    alert(
        "Reminder berhasil dikembalikan ke pengaturan awal."
    );
}


// ==========================================
// INITIALIZE
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        renderReminders();

        checkSmartReminder();


        setInterval(
            checkSmartReminder,
            30000
        );

    }
);