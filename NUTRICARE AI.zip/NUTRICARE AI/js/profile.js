// ==========================================
// NutriCare AI - Profile System
// ==========================================


// ==========================================
// DEFAULT PROFILE
// ==========================================

function getDefaultProfile() {

    return {

        // Foto profil
        profilePhoto: "",

        // Data pribadi
        name: "",
        age: null,
        gender: "",

        // Data fisik
        weight: null,
        height: null,

        // Aktivitas
        activityLevel: "sedentary",

        // Tujuan kesehatan
        healthGoal: "",

        // Preferensi makanan
        foodPreferences: [],

        favoriteFoods: [],

        dislikedFoods: [],

        allergies: [],

        dietPattern: "",

        // Pengaturan
        reminderEnabled: true,

        notificationEnabled: true

    };

}


// ==========================================
// GET PROFILE
// ==========================================

function getProfile() {

    return NutriStorage.get(
        STORAGE_KEYS.PROFILE,
        getDefaultProfile()
    );

}


// ==========================================
// SAVE PROFILE
// ==========================================

function saveProfile(profile) {

    NutriStorage.save(
        STORAGE_KEYS.PROFILE,
        profile
    );

    return profile;

}


// ==========================================
// UPDATE PROFILE
// ==========================================

function updateProfile(updates) {

    const currentProfile = getProfile();

    const updatedProfile = {

        ...currentProfile,

        ...updates

    };

    saveProfile(updatedProfile);

    return updatedProfile;

}


// ==========================================
// RESET PROFILE
// ==========================================

function resetProfile() {

    const defaultProfile =
        getDefaultProfile();

    saveProfile(defaultProfile);

    return defaultProfile;

}


// ==========================================
// DELETE PROFILE
// ==========================================

function deleteProfile() {

    NutriStorage.remove(
        STORAGE_KEYS.PROFILE
    );

}


// ==========================================
// VALIDATE PROFILE
// ==========================================

function validateProfile(profile) {

    const errors = [];

    // Nama
    if (
        !profile.name ||
        profile.name.trim() === ""
    ) {

        errors.push(
            "Nama belum diisi."
        );

    }


    // Usia
    if (
        profile.age !== null &&
        profile.age !== "" &&
        (
            Number(profile.age) < 1 ||
            Number(profile.age) > 120
        )
    ) {

        errors.push(
            "Usia harus berada dalam rentang yang valid."
        );

    }


    // Berat badan
    if (
        profile.weight !== null &&
        profile.weight !== "" &&
        Number(profile.weight) <= 0
    ) {

        errors.push(
            "Berat badan harus lebih dari 0."
        );

    }


    // Tinggi badan
    if (
        profile.height !== null &&
        profile.height !== "" &&
        Number(profile.height) <= 0
    ) {

        errors.push(
            "Tinggi badan harus lebih dari 0."
        );

    }


    return {

        valid: errors.length === 0,

        errors: errors

    };

}


// ==========================================
// PROFILE PHOTO
// ==========================================


// Membaca file foto dari galeri/perangkat
function readProfilePhoto(file) {

    return new Promise(
        (resolve, reject) => {

            if (!file) {

                reject(
                    new Error(
                        "Tidak ada foto yang dipilih."
                    )
                );

                return;

            }


            // Pastikan file adalah gambar
            if (
                !file.type.startsWith("image/")
            ) {

                reject(
                    new Error(
                        "File yang dipilih harus berupa gambar."
                    )
                );

                return;

            }


            const reader =
                new FileReader();


            reader.onload = function(event) {

                resolve(
                    event.target.result
                );

            };


            reader.onerror = function() {

                reject(
                    new Error(
                        "Foto gagal dibaca."
                    )
                );

            };


            reader.readAsDataURL(file);

        }
    );

}


// ==========================================
// SAVE PROFILE PHOTO
// ==========================================

async function saveProfilePhoto(file) {

    try {

        const photoData =
            await readProfilePhoto(file);


        updateProfile({

            profilePhoto: photoData

        });


        return photoData;

    } catch (error) {

        console.error(
            "Gagal menyimpan foto profil:",
            error
        );

        return null;

    }

}


// ==========================================
// REMOVE PROFILE PHOTO
// ==========================================

function removeProfilePhoto() {

    updateProfile({

        profilePhoto: ""

    });

}


// ==========================================
// GET PROFILE PHOTO
// ==========================================

function getProfilePhoto() {

    const profile =
        getProfile();

    return profile.profilePhoto || "";

}


// ==========================================
// UPDATE BASIC PROFILE DATA
// ==========================================

function updateBasicProfile({

    name = "",
    age = null,
    gender = ""

} = {}) {

    return updateProfile({

        name: name.trim(),

        age:
            age === ""
                ? null
                : Number(age),

        gender: gender

    });

}


// ==========================================
// UPDATE PHYSICAL DATA
// ==========================================

function updatePhysicalProfile({

    weight = null,
    height = null,
    activityLevel = "sedentary"

} = {}) {

    return updateProfile({

        weight:
            weight === ""
                ? null
                : Number(weight),

        height:
            height === ""
                ? null
                : Number(height),

        activityLevel:
            activityLevel

    });

}


// ==========================================
// UPDATE HEALTH GOAL
// ==========================================

function updateHealthGoal(
    healthGoal
) {

    return updateProfile({

        healthGoal:
            healthGoal

    });

}


// ==========================================
// UPDATE FOOD PREFERENCES
// ==========================================

function updateFoodPreferences({

    foodPreferences = [],
    favoriteFoods = [],
    dislikedFoods = [],
    allergies = [],
    dietPattern = ""

} = {}) {

    return updateProfile({

        foodPreferences:
            foodPreferences,

        favoriteFoods:
            favoriteFoods,

        dislikedFoods:
            dislikedFoods,

        allergies:
            allergies,

        dietPattern:
            dietPattern

    });

}


// ==========================================
// UPDATE NOTIFICATION SETTINGS
// ==========================================

function updateProfileSettings({

    reminderEnabled = true,

    notificationEnabled = true

} = {}) {

    return updateProfile({

        reminderEnabled:
            Boolean(reminderEnabled),

        notificationEnabled:
            Boolean(notificationEnabled)

    });

}