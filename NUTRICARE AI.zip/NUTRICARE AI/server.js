
require("dotenv").config();

const express = require("express");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;

// Foto dikirim dalam format Base64.
// Batas foto mentah di endpoint scanner adalah 7 MB.
app.use(express.json({ limit: "12mb" }));

// ==========================================
// CORS
// ==========================================

app.use((req, res, next) => {
    const origin = req.headers.origin;

    const allowedOrigins = [
         "http://127.0.0.1:5500",
    "http://localhost:5500",
    "http://127.0.0.1:8080",
    "http://localhost:8080"
    ];

    if (allowedOrigins.includes(origin)) {
        res.setHeader("Access-Control-Allow-Origin", origin);
    }

    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") {
        return res.sendStatus(204);
    }

    next();
});

// ==========================================
// OPENAI CLIENT
// ==========================================

const client = process.env.OPENAI_API_KEY
    ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
    : null;

// ==========================================
// AZKADIA INSTRUCTIONS
// ==========================================

const AZKADIA_INSTRUCTIONS = `
Kamu adalah Azkadia, asisten AI milik NutriCare AI.

IDENTITAS:
- Nama: Azkadia.
- Peran: Personal AI Assistant dengan keahlian khusus di bidang nutrisi.
- Kepribadian: ramah, hangat, cerdas, komunikatif, dan sabar.
- Gunakan bahasa natural sesuai bahasa pengguna.

KEAHLIAN UTAMA - NUTRISI:
- Kandungan gizi makanan.
- Protein, karbohidrat, lemak, vitamin, dan mineral.
- Gizi seimbang dan variasi makanan.
- Ide menu, resep, dan bekal.
- Membaca label informasi nilai gizi.
- Memahami bahan makanan dan cara pengolahannya.
- Kebiasaan makan sehat dan realistis.

ASISTEN UMUM:
- Jawab juga pertanyaan pendidikan, teknologi, bahasa, hiburan, kreativitas, dan obrolan sehari-hari.
- Jangan memaksakan topik nutrisi ketika pengguna membicarakan hal lain.
- Jika pertanyaan kurang jelas, tanyakan satu hal yang diperlukan.

GAYA KOMUNIKASI:
- Berikan jawaban jelas dan mudah dipahami.
- Jangan mengarang fakta, angka, kutipan, atau sumber.
- Jika tidak yakin, sampaikan ketidakpastian dengan jujur.
- Jangan berpura-pura memiliki pengalaman pribadi.

KEAMANAN:
- Jangan mendiagnosis penyakit atau menggantikan tenaga medis.
- Jangan menyarankan diet ekstrem atau pembatasan makan berlebihan.
- Jangan membuat pengguna merasa bersalah atas makanan yang dikonsumsi.
- Untuk kondisi medis khusus, arahkan ke tenaga kesehatan kompeten.

TUJUAN:
Jadilah asisten yang berguna untuk berbagai kebutuhan sehari-hari,
dengan nutrisi sebagai keahlian utama NutriCare AI.
`;

// ==========================================
// HEALTH CHECK
// ==========================================

app.get("/api/health", (req, res) => {
    res.json({
        status: "ok",
        aiConfigured: Boolean(client)
    });
});

// ==========================================
// AZKADIA CHAT
// ==========================================

app.post("/api/chat", async (req, res) => {
    try {
        if (!client) {
            return res.status(503).json({
                error: "API key belum dikonfigurasi di file .env."
            });
        }

        const messages = req.body?.messages;

        if (!Array.isArray(messages) || messages.length === 0) {
            return res.status(400).json({
                error: "Riwayat percakapan tidak ditemukan."
            });
        }

        if (messages.length > 12) {
            return res.status(400).json({
                error: "Riwayat percakapan terlalu panjang."
            });
        }

        const validMessages = messages.every((item) =>
            item &&
            ["user", "assistant"].includes(item.role) &&
            typeof item.content === "string" &&
            item.content.trim().length > 0 &&
            item.content.length <= 4000
        );

        if (!validMessages) {
            return res.status(400).json({
                error: "Format pesan tidak valid."
            });
        }

        if (messages[messages.length - 1].role !== "user") {
            return res.status(400).json({
                error: "Pesan terakhir harus berasal dari pengguna."
            });
        }

        const response = await client.responses.create({
            model: "gpt-4.1-mini",
            instructions: AZKADIA_INSTRUCTIONS,
            input: messages.map((item) => ({
                role: item.role,
                content: item.content.trim()
            }))
        });

        const answer = response.output_text?.trim();

        if (!answer) {
            return res.status(502).json({
                error: "AI belum menghasilkan jawaban. Silakan coba lagi."
            });
        }

        res.json({ answer });

    } catch (error) {
        console.error("AI Chat error:", error.message);

        if (error.status === 429) {
            return res.status(429).json({
                error: "Batas penggunaan API tercapai. Periksa kuota dan billing API."
            });
        }

        res.status(500).json({
            error: "Maaf, AI sedang mengalami kendala. Silakan coba lagi."
        });
    }
});

// ==========================================
// AI MEAL SCANNER - VISION
// ==========================================

app.post("/api/scan-meal", async (req, res) => {
    try {
        if (!client) {
            return res.status(503).json({
                error: "AI Vision belum dikonfigurasi. API key belum tersedia."
            });
        }

        const imageData = req.body?.imageData;

        if (
            typeof imageData !== "string" ||
            !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(imageData)
        ) {
            return res.status(400).json({
                error: "Format foto tidak valid. Gunakan JPG, PNG, atau WEBP."
            });
        }

        const base64Data = imageData.split(",")[1];

        const imageSize = Buffer.byteLength(base64Data, "base64");

        if (imageSize > 7 * 1024 * 1024) {
            return res.status(413).json({
                error: "Ukuran foto terlalu besar. Gunakan foto maksimal 7 MB."
            });
        }

        const response = await client.responses.create({
            model: "gpt-4.1-mini",

            instructions: `
Kamu adalah AI Food Recognition untuk NutriCare AI.

Tugasmu adalah mengenali makanan dari foto.

ATURAN:
- Identifikasi makanan yang terlihat.
- Berikan maksimal 3 kemungkinan jika makanan tidak jelas.
- Sebutkan komponen makanan yang terlihat.
- Jangan mengarang bahan yang tidak terlihat.
- Jangan menebak berat makanan secara pasti.
- Jangan menghitung kalori atau kandungan gizi pada tahap ini.
- Jika foto buram atau makanan tidak dapat dikenali, katakan demikian.
- Semua hasil harus dianggap sebagai perkiraan visual.
- Pengguna akan mengonfirmasi jenis makanan dan porsinya setelah ini.

Gunakan bahasa Indonesia.

Kembalikan JSON dengan struktur:
{
  "success": true,
  "candidates": [
    {
      "foodName": "Nama makanan",
      "confidence": "tinggi, sedang, atau rendah",
      "components": ["komponen yang terlihat"]
    }
  ],
  "visualNotes": "Catatan mengenai apa yang terlihat pada foto",
  "needsConfirmation": true
}
`,

            input: [
                {
                    role: "user",
                    content: [
                        {
                            type: "input_text",
                            text: "Kenali makanan dalam foto ini. Berikan hasil sesuai format JSON."
                        },
                        {
                            type: "input_image",
                            image_url: imageData
                        }
                    ]
                }
            ],

            text: {
                format: {
                    type: "json_object"
                }
            }
        });

        const output = response.output_text?.trim();

        if (!output) {
            return res.status(502).json({
                error: "AI belum berhasil mengenali foto makanan."
            });
        }

        let analysis;

        try {
            analysis = JSON.parse(output);
        } catch {
            return res.status(502).json({
                error: "Format hasil pengenalan makanan tidak valid."
            });
        }

        res.json({
            success: true,
            analysis
        });

    } catch (error) {
        console.error("Meal Scanner error:", error.message);

        if (error.status === 429) {
            return res.status(429).json({
                error: "Batas penggunaan API tercapai. Silakan coba lagi nanti."
            });
        }

        res.status(500).json({
            error: "AI Vision mengalami kendala saat membaca foto."
        });
    }
});

// ==========================================
// START SERVER
// ==========================================

app.listen(PORT, () => {
    console.log(
        `NutriCare AI backend berjalan di http://localhost:${PORT}`
    );
});
