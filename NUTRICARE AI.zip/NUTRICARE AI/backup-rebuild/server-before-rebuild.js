require("dotenv").config();

const express = require("express");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "20kb" }));

// Izinkan website lokal mengakses backend.
app.use((req, res, next) => {
    const origin = req.headers.origin;
    const allowedOrigins = [
        "http://127.0.0.1:5500",
        "http://localhost:5500"
    ];

    if (allowedOrigins.includes(origin)) {
        res.setHeader("Access-Control-Allow-Origin", origin);
    }

    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") {
        return res.sendStatus(204);
    }

    next();
});

const client = process.env.OPENAI_API_KEY
    ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
    : null;

app.get("/api/health", (req, res) => {
    res.json({
        status: "ok",
        aiConfigured: Boolean(client)
    });
});

app.post("/api/chat", async (req, res) => {
    try {
        if (!client) {
            return res.status(503).json({
                error: "API key belum dikonfigurasi di file .env."
            });
        }

        const message = req.body?.message;

        if (typeof message !== "string" || !message.trim()) {
            return res.status(400).json({
                error: "Silakan masukkan pertanyaan terlebih dahulu."
            });
        }

        if (message.length > 4000) {
            return res.status(400).json({
                error: "Pertanyaan terlalu panjang. Maksimal 4.000 karakter."
            });
        }

        const response = await client.responses.create({
            model: "gpt-4.1-mini",
            instructions: `
Kamu adalah NutriCare AI, asisten edukasi kesehatan
dan gizi yang ramah, jelas, dan tidak menghakimi.

Panduan:
- Jawab dalam bahasa yang digunakan pengguna.
- Berikan informasi gizi berdasarkan pengetahuan ilmiah.
- Jelaskan dengan bahasa sederhana dan praktis.
- Jangan mengarang angka, sumber penelitian, atau fakta.
- Jika tidak yakin, katakan dengan jujur.
- Jangan mendiagnosis penyakit atau menggantikan tenaga medis.
- Untuk gejala serius atau kondisi darurat, sarankan
  pengguna segera meminta bantuan medis.
- Jangan menyarankan diet ekstrem, pembatasan makan
  berlebihan, atau penggunaan suplemen tanpa arahan profesional.
- Jawab pertanyaan di luar gizi secara singkat dan arahkan
  kembali ke topik kesehatan jika sesuai.
            `,
            input: message.trim()
        });

        const answer = response.output_text?.trim();

        if (!answer) {
            return res.status(502).json({
                error: "AI belum menghasilkan jawaban. Silakan coba lagi."
            });
        }

        res.json({ answer });

    } catch (error) {
        console.error("AI Chat error:", error.message);

        if (error.status === 429) {
            return res.status(429).json({
                error: "Batas penggunaan API tercapai. Periksa kuota dan billing API."
            });
        }

        res.status(500).json({
            error: "Maaf, AI sedang mengalami kendala. Silakan coba lagi."
        });
    }
});

app.listen(PORT, () => {
    console.log(`NutriCare AI backend berjalan di http://localhost:${PORT}`);
});